﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

[Serializable]
public class AiBlock { public string tool; public string sizeXZH; public string centerXYZ; public string pivotXYZ; }
[Serializable]
public class AiBlueprintData { public List<AiBlock> Option_A; public List<AiBlock> Option_B; public List<AiBlock> Option_C; }
[Serializable]
public class TempLogWrapper { public string Notice; public List<ActionLog> Current_Blocks; }

// AI_Architect에서 사용하는 쪼개기 전용 구조체 (AI_Builder에서도 동일하게 사용)


public class AI_Builder : MonoBehaviour
{
    [Header("현장 자재")]
    public GameObject hologramPrefab;

    public bool isAiHologramActive = false;
    public static bool isAiWorking = false;

    public struct AiBuildCommand
    {
        public int mode;
        public float3 startPos;
        public float3 endPos;
        public float height;
        public float exactY;
    }
    public static Queue<AiBuildCommand> buildQueue = new Queue<AiBuildCommand>();

    private List<GameObject> activeHolograms = new List<GameObject>();
    private Vector3 currentBlueprintCenter;

    void Update()
    {
        isAiWorking = isAiHologramActive;

        if (Input.GetKeyDown(KeyCode.Y)) { CancelManualDrag(); LoadAndSpawnHolograms("Option_A"); }
        if (Input.GetKeyDown(KeyCode.U)) { CancelManualDrag(); LoadAndSpawnHolograms("Option_B"); }
        if (Input.GetKeyDown(KeyCode.I)) { CancelManualDrag(); LoadAndSpawnHolograms("Option_C"); }
        if (Input.GetKeyDown(KeyCode.L)) { CancelManualDrag(); LoadCurrentTempLog(); }
        if (Input.GetKeyDown(KeyCode.R)) { CancelManualDrag(); CancelHolograms(); }

        if (isAiHologramActive)
        {
            if (Input.GetMouseButtonDown(1))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out RaycastHit hit)) MoveHologramsTo(hit.point);
            }
            if (Input.GetKeyDown(KeyCode.G)) ConfirmAiBuild();
            if (Input.GetKeyDown(KeyCode.Escape)) CancelHolograms();
        }
    }

    private void LoadCurrentTempLog()
    {
        CancelHolograms();
        string tempPath = Path.Combine(Application.dataPath, "../BuildingLogs/temp/Temp_Current_Building.json");
        if (!File.Exists(tempPath)) return;
        try
        {
            string jsonRaw = File.ReadAllText(tempPath);
            TempLogWrapper tempData = JsonUtility.FromJson<TempLogWrapper>(jsonRaw);
            if (tempData != null && tempData.Current_Blocks != null) SpawnHologramsFromActionLogs(tempData.Current_Blocks);
        }
        catch (Exception e) { Debug.LogError(e.Message); }
    }

    private void LoadAndSpawnHolograms(string optionName)
    {
        CancelHolograms();

        // 1. "Option_A" -> "option_A.json" 형태로 파일명 변환하여 경로 찾기
        string optionFileName = optionName.Replace("Option", "option") + ".json";
        string targetPath = Path.Combine(Application.dataPath, "ai_designs", optionFileName);

        if (!File.Exists(targetPath))
        {
            Debug.LogWarning($"⚠️ [AI] 옵션 파일을 찾을 수 없습니다: {targetPath}");
            return;
        }

        string json = File.ReadAllText(targetPath);

        SplitTempData tempLog = JsonUtility.FromJson<SplitTempData>(json);
        if (tempLog == null || tempLog.Current_Blocks == null || tempLog.Current_Blocks.Count == 0) return;

        List<AiBlock> target = tempLog.Current_Blocks;

        List<ActionLog> convertedLogs = new List<ActionLog>();
        foreach (var block in target)
        {
            string finalCenter = block.centerXYZ;

            if (string.IsNullOrEmpty(finalCenter) && !string.IsNullOrEmpty(block.pivotXYZ))
            {
                float[] sz = ParseFloatArray(block.sizeXZH);
                float[] pv = ParseFloatArray(block.pivotXYZ);
                if (sz != null && pv != null)
                {
                    // 🚨 복사 버그 방지용 띄어쓰기 [ 0 ], [ 1 ], [ 2 ] 적용
                    float cX = pv[0] + (sz[0] / 2f);
                    float cY = pv[1];
                    float cZ = pv[2] + (sz[1] / 2f);
                    finalCenter = $"[{cX:F2}, {cY:F2}, {cZ:F2}]";
                }
            }

            convertedLogs.Add(new ActionLog
            {
                tool = block.tool,
                sizeXZH = block.sizeXZH,
                centerXYZ = finalCenter
            });
        }

        SpawnHologramsFromActionLogs(convertedLogs);
    }

    private void SpawnHologramsFromActionLogs(List<ActionLog> logs)
    {
        float minX = float.MaxValue, maxX = float.MinValue, minZ = float.MaxValue, maxZ = float.MinValue;
        foreach (ActionLog log in logs)
        {
            float[] szArr = ParseFloatArray(log.sizeXZH);
            float[] cpArr = ParseFloatArray(log.centerXYZ);
            if (szArr == null || cpArr == null) continue;

            // 🚨 복사 버그 방지용 띄어쓰기 적용
            if (szArr[0] <= 3.1f && szArr[1] <= 3.1f) continue;

            float pX = cpArr[0];
            float pY = (cpArr[1] - 1.5f) + (szArr[2] * 3.0f / 2f);
            float pZ = cpArr[2];

            GameObject holo = Instantiate(hologramPrefab, new Vector3(pX, pY, pZ), Quaternion.identity);
            float scaleX = (float)Math.Round(szArr[0] / 3.0f) * 3.0f;
            float scaleZ = (float)Math.Round(szArr[1] / 3.0f) * 3.0f;
            float scaleY = szArr[2] * 3.0f;

            holo.transform.localScale = new Vector3(scaleX < 3.0f ? 3.0f : scaleX, scaleY, scaleZ < 3.0f ? 3.0f : scaleZ);
            holo.name = log.tool;
            activeHolograms.Add(holo);
            minX = Math.Min(minX, pX); maxX = Math.Max(maxX, pX);
            minZ = Math.Min(minZ, pZ); maxZ = Math.Max(maxZ, pZ);
        }
        if (activeHolograms.Count > 0)
        {
            currentBlueprintCenter = new Vector3((minX + maxX) / 2f, 0f, (minZ + maxZ) / 2f);
            isAiHologramActive = true;
            UpdateHologramHeightVisuals();
        }
    }

    private void ConfirmAiBuild()
    {
        float blockSize = 3.0f;
        float blueprintLowestY = float.MaxValue;
        foreach (GameObject h in activeHolograms) { float bY = h.transform.position.y - (h.transform.localScale.y / 2f); if (bY < blueprintLowestY) blueprintLowestY = bY; }

        float globalHighestY = 0f;
        var em = World.DefaultGameObjectInjectionWorld.EntityManager;
        var physicsQuery = em.CreateEntityQuery(typeof(Unity.Physics.PhysicsWorldSingleton));
        if (!physicsQuery.IsEmpty)
        {
            var physicsWorld = physicsQuery.GetSingleton<Unity.Physics.PhysicsWorldSingleton>().PhysicsWorld;
            foreach (GameObject holo in activeHolograms)
            {
                Vector3 size = holo.transform.localScale;
                Vector3 pos = holo.transform.position;
                Vector3 startCorner = pos - (size / 2f);
                int xCount = Mathf.RoundToInt(size.x / blockSize);
                int zCount = Mathf.RoundToInt(size.z / blockSize);

                for (int x = 0; x < xCount; x++)
                {
                    for (int z = 0; z < zCount; z++)
                    {
                        float3[] scanOffsets = new float3[] { new float3(0, 0, 0), new float3(1.4f, 0, 0), new float3(-1.4f, 0, 0), new float3(0, 0, 1.4f), new float3(0, 0, -1.4f) };
                        foreach (var off in scanOffsets)
                        {
                            float3 rStart = new float3(Mathf.Round((startCorner.x + x * blockSize) / 3f) * 3f + 1.5f + off.x, 500f, Mathf.Round((startCorner.z + z * blockSize) / 3f) * 3f + 1.5f + off.z);
                            Unity.Physics.RaycastInput input = new Unity.Physics.RaycastInput { Start = rStart, End = rStart - new float3(0, 1000f, 0), Filter = Unity.Physics.CollisionFilter.Default };
                            if (physicsWorld.CastRay(input, out Unity.Physics.RaycastHit hit))
                            {
                                float sY = Mathf.Round(hit.Position.y / blockSize) * blockSize;
                                if (sY > globalHighestY) globalHighestY = sY;
                            }
                        }
                    }
                }
            }
        }

        float shiftY = globalHighestY - blueprintLowestY;

        foreach (GameObject holo in activeHolograms)
        {
            Vector3 size = holo.transform.localScale;
            Vector3 pos = holo.transform.position;
            Vector3 startCorner = pos - (size / 2f);

            int mode = 1;
            string toolName = holo.name;
            if (toolName.Contains("1_Solid")) mode = 1;
            else if (toolName.Contains("2_Empty")) mode = 2;
            else if (toolName.Contains("3_Circ")) mode = 3;
            else if (toolName.Contains("4_Pyra")) mode = 4;
            else if (toolName.Contains("5_Cone")) mode = 5;

            float3 sPos = new float3(Mathf.Round(startCorner.x / blockSize) * blockSize, 0, Mathf.Round(startCorner.z / blockSize) * blockSize);
            float3 ePos = new float3(sPos.x + size.x - blockSize, 0, sPos.z + size.z - blockSize);
            float h = Mathf.Round(size.y / blockSize);

            buildQueue.Enqueue(new AiBuildCommand
            {
                mode = mode,
                startPos = sPos,
                endPos = ePos,
                height = h,
                exactY = startCorner.y + shiftY
            });
        }
        CancelHolograms();
    }

    private void MoveHologramsTo(Vector3 targetPos)
    {
        float snapX = (float)Math.Round(targetPos.x / 3.0f) * 3.0f;
        float snapZ = (float)Math.Round(targetPos.z / 3.0f) * 3.0f;
        Vector3 newCenter = new Vector3(snapX, 0f, snapZ);
        Vector3 offset = newCenter - currentBlueprintCenter;
        foreach (GameObject holo in activeHolograms) holo.transform.position += new Vector3(offset.x, 0f, offset.z);
        currentBlueprintCenter = newCenter;
        UpdateHologramHeightVisuals();
    }

    private void UpdateHologramHeightVisuals()
    {
        var em = World.DefaultGameObjectInjectionWorld.EntityManager;
        var physicsQuery = em.CreateEntityQuery(typeof(Unity.Physics.PhysicsWorldSingleton));
        if (physicsQuery.IsEmpty) return;
        var physicsWorld = physicsQuery.GetSingleton<Unity.Physics.PhysicsWorldSingleton>().PhysicsWorld;

        float blockSize = 3.0f;
        float blueprintLowestY = float.MaxValue;
        foreach (GameObject h in activeHolograms) { float bY = h.transform.position.y - (h.transform.localScale.y / 2f); if (bY < blueprintLowestY) blueprintLowestY = bY; }

        float globalHighestY = 0f;
        foreach (GameObject holo in activeHolograms)
        {
            Vector3 size = holo.transform.localScale;
            Vector3 pos = holo.transform.position;
            Vector3 startCorner = pos - (size / 2f);
            startCorner.x = Mathf.Round(startCorner.x / blockSize) * blockSize;
            startCorner.z = Mathf.Round(startCorner.z / blockSize) * blockSize;

            string toolName = holo.name.Replace("(Clone)", "").Trim();
            int xCount = Mathf.RoundToInt(size.x / blockSize);
            int zCount = Mathf.RoundToInt(size.z / blockSize);
            int baseRadiusX = (xCount - 1) / 2;
            int baseRadiusZ = (zCount - 1) / 2;

            for (int x = 0; x < xCount; x++)
            {
                for (int z = 0; z < zCount; z++)
                {
                    int origX = x - baseRadiusX; int origZ = z - baseRadiusZ;
                    float dist = Mathf.Sqrt(origX * origX + origZ * origZ);
                    bool inside = true;

                    if (toolName.Contains("2_Empty_Frame")) { bool isWall = (x == 0 || x == xCount - 1 || z == 0 || z == zCount - 1); if (!isWall) inside = false; }
                    else if (toolName.Contains("3_Circular_Pattern")) { inside = (dist <= baseRadiusX + 0.5f); }
                    else if (toolName.Contains("4_Pyramid")) { if (Mathf.Abs(origX) > baseRadiusX || Mathf.Abs(origZ) > baseRadiusZ) inside = false; }
                    else if (toolName.Contains("5_Cone")) { if (dist > baseRadiusX + 0.5f) inside = false; }

                    if (!inside) continue;

                    float3[] scanOffsets = new float3[] { new float3(0, 0, 0), new float3(1.4f, 0, 0), new float3(-1.4f, 0, 0), new float3(0, 0, 1.4f), new float3(0, 0, -1.4f) };
                    foreach (var off in scanOffsets)
                    {
                        float3 rStart = new float3(Mathf.Round((startCorner.x + x * blockSize) / 3f) * 3f + 1.5f + off.x, 500f, Mathf.Round((startCorner.z + z * blockSize) / 3f) * 3f + 1.5f + off.z);
                        Unity.Physics.RaycastInput input = new Unity.Physics.RaycastInput { Start = rStart, End = rStart - new float3(0, 1000f, 0), Filter = Unity.Physics.CollisionFilter.Default };
                        if (physicsWorld.CastRay(input, out Unity.Physics.RaycastHit hit))
                        {
                            float sY = Mathf.Round(hit.Position.y / blockSize) * blockSize;
                            if (sY > globalHighestY) globalHighestY = sY;
                        }
                    }
                }
            }
        }

        float shiftY = globalHighestY - blueprintLowestY;
        if (Mathf.Abs(shiftY) > 0.01f) { foreach (GameObject holo in activeHolograms) { holo.transform.position += new Vector3(0, shiftY, 0); } }
    }

    private void CancelHolograms() { foreach (var h in activeHolograms) if (h) Destroy(h); activeHolograms.Clear(); isAiHologramActive = false; isAiWorking = false; }
    private void CancelManualDrag() { var dc = FindFirstObjectByType<SimulationDragController>(); if (dc) dc.CancelDrag(); }
    private float[] ParseFloatArray(string r) { try { return r.Replace("[", "").Replace("]", "").Split(',').Select(s => float.Parse(s.Trim())).ToArray(); } catch { return null; } }
}