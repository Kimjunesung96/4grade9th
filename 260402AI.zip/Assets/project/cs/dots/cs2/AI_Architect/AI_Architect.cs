﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

// TEMP 구조와 똑같이 쪼개서 저장하기 위한 전용 클래스
[System.Serializable]
public class SplitTempData
{
    public string Notice;
    public List<AiBlock> Current_Blocks;
}

public class AI_Architect : MonoBehaviour
{
    // 🚨 십장님의 구글 제미나이 API 키 (외부 공유 시 반드시 삭제!)
    [Header("Google Gemini API 설정")]
    public string apiKey = "카톡봐라";

    private string[] apiEndpoints = new string[]
    {
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent"
    };

    // ==========================================================
    // 1. [AI 설계 규칙]
    // ==========================================================
    private string GetConstructionManual()
    {
        return @"
[AI ARCHITECT - BLOCK PLACEMENT RULES]
You design 3D voxel structures for a physics-based building game.
Each block is 3.0 x 3.0 x 3.0 meters.

== COORDINATE SYSTEM ==
Each structure entry uses:
  - pivotXYZ : [X, Y, Z] world position of the structure's START CORNER (bottom-left-front)
               X and Z must be multiples of 3.0. Y must be -1.5 (floor 1), 1.5 (floor 2), 4.5 (floor 3).
  - sizeXZH  : [totalWidthX, totalDepthZ, floorCount]
               totalWidthX and totalDepthZ are total length in meters (multiples of 3.0).
               floorCount is number of floors (integer).
  - tool     : ""1_Solid_Wall"" (fills entire volume) or ""2_Empty_Frame"" (outer shell only)

== REAL EXAMPLES FROM THIS PROJECT ==
  {""tool"":""2_Empty_Frame"", ""sizeXZH"":""[57.0, 81.0, 5]"", ""pivotXYZ"":""[-13.50, -1.50, 58.50]""}
  {""tool"":""1_Solid_Wall"",  ""sizeXZH"":""[3.0,  3.0,  5]"", ""pivotXYZ"":""[10.50, -1.50, 49.50]""}
  {""tool"":""2_Empty_Frame"", ""sizeXZH"":""[24.0, 39.0, 5]"", ""pivotXYZ"":""[-12.00,-1.50, 64.50]""}

== TOKEN ECONOMY ==
Describe large areas as ONE entry. Do NOT list individual 3x3 blocks separately.

== OUTPUT — raw JSON only, no markdown, no explanation ==
{
  ""Option_A"": [ {""tool"":""2_Empty_Frame"", ""sizeXZH"":""[W, D, H]"", ""pivotXYZ"":""[X, Y, Z]""} ],
  ""Option_B"": [ {""tool"":""1_Solid_Wall"",  ""sizeXZH"":""[W, D, H]"", ""pivotXYZ"":""[X, Y, Z]""} ],
  ""Option_C"": [ {""tool"":""2_Empty_Frame"", ""sizeXZH"":""[W, D, H]"", ""pivotXYZ"":""[X, Y, Z]""},
                 {""tool"":""1_Solid_Wall"",  ""sizeXZH"":""[3.0, 3.0, H]"", ""pivotXYZ"":""[X, Y, Z]""} ]
}

== 3 OPTIONS (PHYSICS & STABILITY FOCUS) ==
All options must be designed to withstand gravity with minimal shaking when physics are activated.

Option_A (Minimalist) : Use the absolute minimum number of blocks to preserve the original design. Minor swaying is acceptable.
Option_B (Max Reinforcement) : Use the maximum number of blocks (Solid_Walls) to heavily reinforce the structure. Zero swaying is required.
Option_C (Balanced) : Optimal balance between block usage and structural stability.
";
    }
    // ==========================================================
    // 2. [주문 접수]
    // ==========================================================
    public void OrderBlueprintFromAI(string userPrompt)
    {
        StartCoroutine(CallGemini(userPrompt));
    }

    // ==========================================================
    // 3. [Gemini 호출]
    // ==========================================================
    private IEnumerator CallGemini(string userPrompt)
    {
        string tempPath = Path.Combine(Application.dataPath, "temp", "Temp_Current_Building.json");
        string buildingState = File.Exists(tempPath)
            ? File.ReadAllText(tempPath)
            : "No previous blocks. New construction.";

        if (File.Exists(tempPath)) Debug.Log("📄 [AI] Temp 장부 확보!");
        else Debug.LogWarning("⚠️ [AI] Temp 없음. 새 건물로 간주.");

        string full = GetConstructionManual()
            + "\n\n[CURRENT BUILDING STATE]\n" + buildingState
            + "\n\n[USER ORDER]\n" + userPrompt;

        string safe = full.Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
        byte[] body = Encoding.UTF8.GetBytes(
            "{\"contents\":[{\"parts\":[{\"text\":\"" + safe + "\"}]}]}");

        bool ok = false;
        for (int i = 0; i < apiEndpoints.Length; i++)
        {
            using (var req = new UnityWebRequest(apiEndpoints[i] + "?key=" + apiKey, "POST"))
            {
                req.uploadHandler = new UploadHandlerRaw(body);
                req.downloadHandler = new DownloadHandlerBuffer();
                req.SetRequestHeader("Content-Type", "application/json");
                yield return req.SendWebRequest();

                if (req.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("✅ [AI] 도면 수신!");
                    SaveBlueprint(req.downloadHandler.text);
                    ok = true; break;
                }
                Debug.LogWarning($"⚠️ [AI] {i + 1}번 채널 실패: {req.error}");
            }
        }
        if (!ok) Debug.LogError("🚨 [AI] 전 채널 실패!");
    }

    // ==========================================================
    // 4. [저장] 데이터 분할 및 히스토리 누적 저장
    // ==========================================================
    private void SaveBlueprint(string raw)
    {
        string json = ExtractInnerJson(raw);
        if (string.IsNullOrEmpty(json)) { Debug.LogError("🚨 JSON 추출 실패!\n" + raw); return; }

        // 1. HISTORY 폴더에 원본 데이터 타임스탬프 누적 저장
        string historyDir = Path.Combine(Application.dataPath, "ai_designs/HISTORY");
        if (!Directory.Exists(historyDir)) Directory.CreateDirectory(historyDir);

        string timestamp = System.DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string historyPath = Path.Combine(historyDir, $"Gemini_Blueprint_{timestamp}.json");
        File.WriteAllText(historyPath, json);
        Debug.Log($"💾 [AI] 원본 HISTORY 저장 완료: {historyPath}");

        // 2. 원본 데이터 파싱
        AiBlueprintData rawData = JsonUtility.FromJson<AiBlueprintData>(json);
        if (rawData == null) return;

        // 3. TEMP 구조로 각각 3개로 쪼개기
        SplitTempData tempOptionA = new SplitTempData { Notice = "History_Option_A", Current_Blocks = rawData.Option_A };
        SplitTempData tempOptionB = new SplitTempData { Notice = "History_Option_B", Current_Blocks = rawData.Option_B };
        SplitTempData tempOptionC = new SplitTempData { Notice = "History_Option_C", Current_Blocks = rawData.Option_C };

        // 4. ai_designs 폴더 바로 아래에 3개의 파일로 최신화 덮어쓰기
        string targetDir = Path.Combine(Application.dataPath, "ai_designs");
        if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);

        File.WriteAllText(Path.Combine(targetDir, "option_A.json"), JsonUtility.ToJson(tempOptionA, true));
        File.WriteAllText(Path.Combine(targetDir, "option_B.json"), JsonUtility.ToJson(tempOptionB, true));
        File.WriteAllText(Path.Combine(targetDir, "option_C.json"), JsonUtility.ToJson(tempOptionC, true));

        // (말썽을 일으키는 AssetDatabase.Refresh() 삭제 완료)

        Debug.Log("✂️ [AI] 원본 데이터를 TEMP 구조로 3등분하여 ai_designs 폴더에 최신화 완료했습니다!");
    }

    // Gemini candidates 래퍼 + 마크다운 펜스 → 순수 Blueprint JSON 추출
    private string ExtractInnerJson(string raw)
    {
        string candidate = raw;
        int textIdx = raw.IndexOf("\"text\":");
        if (textIdx >= 0)
        {
            int i = textIdx + 7;
            while (i < raw.Length && raw[i] != '"') i++;
            if (i < raw.Length && raw[i] == '"')
            {
                var sb = new System.Text.StringBuilder();
                i++;
                while (i < raw.Length)
                {
                    char c = raw[i];
                    if (c == '\\' && i + 1 < raw.Length)
                    {
                        char n = raw[i + 1];
                        if (n == '"') { sb.Append('"'); i += 2; }
                        else if (n == 'n') { sb.Append('\n'); i += 2; }
                        else if (n == 'r') { sb.Append('\r'); i += 2; }
                        else if (n == '\\') { sb.Append('\\'); i += 2; }
                        else { sb.Append(c); i++; }
                    }
                    else if (c == '"') break;
                    else { sb.Append(c); i++; }
                }
                candidate = sb.ToString().Trim();
            }
        }

        if (candidate.Contains("```"))
        {
            int fStart = candidate.IndexOf("```");
            int jStart = candidate.IndexOf('\n', fStart) + 1;
            int fEnd = candidate.LastIndexOf("```");
            if (jStart > 0 && fEnd > jStart)
                candidate = candidate.Substring(jStart, fEnd - jStart).Trim();
        }

        int s = candidate.IndexOf('{');
        int e = candidate.LastIndexOf('}');
        if (s >= 0 && e > s)
            return candidate.Substring(s, e - s + 1);

        return null;
    }

    // ==========================================================
    // 5. [T키 트리거]
    // ==========================================================
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            Debug.Log("📡 [AI] T키 — 도면 발주!");
            OrderBlueprintFromAI("현재 1층 구조를 파악하고, 2층에 어울리는 구조 3가지 옵션을 설계해라.");
        }
    }
}