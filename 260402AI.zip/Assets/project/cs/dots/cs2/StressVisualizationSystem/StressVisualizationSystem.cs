﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Rendering;
using UnityEngine;
using System.IO;
using System;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;

// ⭐ 스트레스 초기화를 위한 초경량 Job
[BurstCompile]
public partial struct ResetStressJob : IJobEntity
{
    public void Execute(ref BlockStress stress)
    {
        stress.TargetStress = 0f;
    }
}

// ⭐ 조인트 응력을 멀티코어로 미친듯이 빠르게 계산하는 Job
[BurstCompile]
public partial struct CalculateJointStressJob : IJobEntity
{
    [ReadOnly] public ComponentLookup<LocalTransform> TransformLookup;
    public ComponentLookup<BlockStress> StressLookup;
    public bool IsWeightScanMode;

    public void Execute(in PhysicsConstrainedBodyPair pair, in PhysicsJoint joint)
    {
        Entity entityA = pair.EntityA;
        Entity entityB = pair.EntityB;

        if (TransformLookup.HasComponent(entityA) && TransformLookup.HasComponent(entityB))
        {
            var transA = TransformLookup[entityA];
            var transB = TransformLookup[entityB];

            float3 pivotA = math.transform(new RigidTransform(transA.Rotation, transA.Position), joint.BodyAFromJoint.Position);
            float3 pivotB = math.transform(new RigidTransform(transB.Rotation, transB.Position), joint.BodyBFromJoint.Position);
            float3 deltaDisplacement = pivotA - pivotB;

            float jointStressResult = 0f;

            if (IsWeightScanMode)
            {
                float axialStiffness = 15.0f;
                jointStressResult = math.abs(deltaDisplacement.y) * axialStiffness;
            }
            else
            {
                float shearStiffness = 10.0f;
                float bendingStiffness = 15.0f;
                float dotProduct = math.abs(math.dot(transA.Rotation.value, transB.Rotation.value));
                float angleDiff = 2.0f * math.acos(math.clamp(dotProduct, -1f, 1f));
                float bendingStress = angleDiff * bendingStiffness;
                float shearStress = math.length(new float2(deltaDisplacement.x, deltaDisplacement.z)) * shearStiffness;

                jointStressResult = bendingStress + shearStress;
            }

            if (StressLookup.HasComponent(entityA))
            {
                var stressA = StressLookup[entityA];
                stressA.TargetStress += jointStressResult;
                StressLookup[entityA] = stressA;
            }
            if (StressLookup.HasComponent(entityB))
            {
                var stressB = StressLookup[entityB];
                stressB.TargetStress += jointStressResult;
                StressLookup[entityB] = stressB;
            }
        }
    }
}

// ⭐ 외부 하중 및 지진을 멀티코어로 적용하는 Job
[BurstCompile]
public partial struct ApplyExternalLoadJob : IJobEntity
{
    public bool IsWeightScanMode;
    public float DeltaTime;
    public float QuakeX;
    public float QuakeZ;
    public float BaseWeight;
    public float DynamicSensitivity;

    public void Execute(in LocalTransform transform, ref BlockStress stress, ref PhysicsVelocity velRW)
    {
        float additionalStress = 0f;

        if (IsWeightScanMode)
        {
            additionalStress = BaseWeight;
        }
        else
        {
            velRW.Linear += new float3(QuakeX, 0, QuakeZ) * DeltaTime;
            additionalStress = math.lengthsq(velRW.Linear) * DynamicSensitivity;
        }
        stress.TargetStress += additionalStress;
    }
}

// ⭐ 평균치 계산을 위한 Job
[BurstCompile]
public partial struct SmoothStressJob : IJobEntity
{
    public float DeltaTime;
    public float SmoothSpeed;

    public void Execute(ref BlockStress stress)
    {
        stress.SmoothedStress = math.lerp(stress.SmoothedStress, stress.TargetStress, DeltaTime * SmoothSpeed);
    }
}


[UpdateInGroup(typeof(SimulationSystemGroup))]
[UpdateAfter(typeof(FixedStepSimulationSystemGroup))]
public partial struct StressVisualizationSystem : ISystem
{
    private float scanTimer;
    private bool isScanning;
    private bool needsColorUpdate;
    private bool isWeightScanMode;

    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<BlockStress>();
    }

    public void OnUpdate(ref SystemState state)
    {
        // 1. 입력 감지부 (V / B)
        if (Input.GetKeyDown(KeyCode.V))
        {
            scanTimer = 5.0f;
            isScanning = true;
            isWeightScanMode = true;
            needsColorUpdate = false;

            foreach (var color in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>>())
                color.ValueRW.Value = new float4(1f, 1f, 1f, 1f);

            Debug.Log("⚖️ [무게 진단 (리얼 모드)] 5초간 실제 관절의 수직 압축량을 정밀 분석합니다...");
        }

        if (Input.GetKeyDown(KeyCode.B))
        {
            scanTimer = 5.0f;
            isScanning = true;
            isWeightScanMode = false;
            needsColorUpdate = false;

            foreach (var color in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>>())
                color.ValueRW.Value = new float4(1f, 1f, 1f, 1f);

            Debug.Log("🌪️ [진동대 시험] 5초간 인공 지진을 발생시켜 구조물의 비틀림을 분석합니다...");
        }

        // 2. 타이머 체크
        if (isScanning)
        {
            scanTimer -= SystemAPI.Time.DeltaTime;
            if (scanTimer <= 0f)
            {
                isScanning = false;
                needsColorUpdate = true;
                Debug.Log("✅ [스캔 완료] 데이터를 엑셀로 추출하고 색상을 렌더링합니다!");
            }
        }

        // ⭐ 3. 셔터 내리기!
        if (!isScanning && !needsColorUpdate) return;


        // =========================================================
        // ⚙️ [정밀 해석 모드] 멀티코어 Job System 가동!
        // =========================================================
        if (isScanning)
        {
            state.Dependency = new ResetStressJob().ScheduleParallel(state.Dependency);

            var transformLookup = SystemAPI.GetComponentLookup<LocalTransform>(true);
            var stressLookup = SystemAPI.GetComponentLookup<BlockStress>(false);

            var jointJob = new CalculateJointStressJob
            {
                TransformLookup = transformLookup,
                StressLookup = stressLookup,
                IsWeightScanMode = isWeightScanMode
            };
            state.Dependency = jointJob.Schedule(state.Dependency);

            float time = (float)SystemAPI.Time.ElapsedTime;
            float quakePower = 5.0f;

            var externalLoadJob = new ApplyExternalLoadJob
            {
                IsWeightScanMode = isWeightScanMode,
                DeltaTime = SystemAPI.Time.DeltaTime,
                QuakeX = !isWeightScanMode ? math.sin(time * 35f) * quakePower : 0f,
                QuakeZ = !isWeightScanMode ? math.cos(time * 28f) * quakePower : 0f,
                BaseWeight = 1.0f,
                DynamicSensitivity = 0.5f
            };
            state.Dependency = externalLoadJob.ScheduleParallel(state.Dependency);

            var smoothJob = new SmoothStressJob
            {
                DeltaTime = SystemAPI.Time.DeltaTime,
                SmoothSpeed = 3f
            };
            state.Dependency = smoothJob.ScheduleParallel(state.Dependency);
        }

        // =========================================================
        // 🎨 [진단 완료] 렌더링 & CSV 리포트 분할 출력 (All / Stress)
        // =========================================================
        if (needsColorUpdate)
        {
            state.Dependency.Complete();

            float yieldLimit = isWeightScanMode ? 5.0f : 8.0f;
            string reportType = isWeightScanMode ? "WEIGHT" : "SHAKE";
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

            // ⭐ 1. 폴더 경로 셋팅 (StressBlock 안에 All, danger 폴더를 계층형으로!)
            string mainDir = Path.Combine(Application.dataPath, "StressBlock");
            string allDir = Path.Combine(mainDir, "All");
            string dangerDir = Path.Combine(mainDir, "danger");

            if (!Directory.Exists(mainDir)) Directory.CreateDirectory(mainDir);
            if (!Directory.Exists(allDir)) Directory.CreateDirectory(allDir);
            if (!Directory.Exists(dangerDir)) Directory.CreateDirectory(dangerDir);

            // ⭐ 2. 저장할 파일 3개의 경로 셋팅
            string currentStressPath = Path.Combine(mainDir, "CurrentStress.csv");
            string allFilePath = Path.Combine(allDir, $"{reportType}_All_{timestamp}.csv");
            string stressFilePath = Path.Combine(dangerDir, $"{reportType}_StressOnly_{timestamp}.csv");

            // ⭐ 3. 3개의 파일을 동시에 열어서 씁니다
            using (StreamWriter allWriter = new StreamWriter(allFilePath))
            using (StreamWriter stressWriter = new StreamWriter(stressFilePath))
            using (StreamWriter currentWriter = new StreamWriter(currentStressPath))
            {
                string header = $"BlockID,PosX,PosY,PosZ,{reportType}_Stress,RiskLevel";
                allWriter.WriteLine(header);
                stressWriter.WriteLine(header);
                currentWriter.WriteLine(header);

                int blockCount = 0;
                foreach (var (stress, color, transform) in SystemAPI.Query<RefRO<BlockStress>, RefRW<URPMaterialPropertyBaseColor>, RefRO<LocalTransform>>())
                {
                    float currentStress = stress.ValueRO.SmoothedStress;
                    float3 pos = transform.ValueRO.Position;
                    float t = math.clamp(currentStress / yieldLimit, 0f, 1f);

                    if (isWeightScanMode) color.ValueRW.Value = new float4(1f, 1f - t, 1f - t, 1f);
                    else color.ValueRW.Value = new float4(1f, 1f - t, 1f, 1f);

                    string risk = t >= 0.8f ? "DANGER" : (t >= 0.5f ? "WARNING" : "SAFE");
                    string lineData = $"{blockCount},{pos.x:F2},{pos.y:F2},{pos.z:F2},{currentStress:F2},{risk}";

                    // (1) 전체 기록용 파일
                    allWriter.WriteLine(lineData);

                    // (2) 위험군(WARNING 이상)
                    if (t >= 0.5f)
                    {
                        stressWriter.WriteLine(lineData);
                        currentWriter.WriteLine(lineData);
                    }
                    blockCount++;
                }
            }

            Debug.Log($"📁 스트레스 데이터 저장 완료!\n- 최신 갱신: {currentStressPath}\n- 전체 히스토리: {allFilePath}\n- 위험군 히스토리: {stressFilePath}");
            needsColorUpdate = false;
        }
    }
}