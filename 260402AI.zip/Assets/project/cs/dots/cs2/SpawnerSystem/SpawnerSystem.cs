﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

public struct GhostBlockTag : IComponentData { }

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct SpawnerSystem : ISystem
{
    private float3 dragStartPos;
    private float3 dragEndPos;
    private int currentBuildMode;
    private float guideHeight;
    private bool isGuideActive;
    private int nextStructureID;

    private bool isCenterMoved;
    private float3 customCenterPos;

    private NativeList<BlobAssetReference<Unity.Physics.Collider>> _createdColliders;

    private string GetToolName(int mode)
    {
        switch (mode)
        {
            case 0: return "1_Solid_Wall";
            case 1: return "1_Solid_Wall";
            case 2: return "2_Empty_Frame";
            case 3: return "3_Circular_Pattern";
            case 4: return "4_Pyramid";
            case 5: return "5_Cone";
            default: return "Unknown_Tool";
        }
    }

    public void OnCreate(ref SystemState state)
    {
        currentBuildMode = 1;
        guideHeight = 1f;
        isGuideActive = false;
        nextStructureID = 1;
        isCenterMoved = false;
        customCenterPos = float3.zero;
        _createdColliders = new NativeList<BlobAssetReference<Unity.Physics.Collider>>(Allocator.Persistent);
    }

    public void OnDestroy(ref SystemState state)
    {
        if (_createdColliders.IsCreated)
        {
            foreach (var col in _createdColliders) { if (col.IsCreated) col.Dispose(); }
            _createdColliders.Dispose();
        }
    }

    public void OnUpdate(ref SystemState state)
    {
        if (!UnityEngine.Application.isPlaying || Camera.main == null) return;

        if (!SystemAPI.HasSingleton<BuilderStateData>()) return;
        var builderState = SystemAPI.GetSingletonRW<BuilderStateData>();

        if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsSingleton)) return;

        SpawnerData spawnerData = default;
        bool hasSpawner = false;
        foreach (var data in SystemAPI.Query<RefRO<SpawnerData>>())
        {
            spawnerData = data.ValueRO;
            hasSpawner = true;
            break;
        }
        if (!hasSpawner) return;

        PhysicsWorld physicsWorld = physicsSingleton.PhysicsWorld;

        if (Input.mouseScrollDelta.y != 0)
        {
            builderState.ValueRW.GuideHeight += Input.mouseScrollDelta.y;
            if (builderState.ValueRW.GuideHeight < 1f) builderState.ValueRW.GuideHeight = 1f;
        }

        if (Input.GetKeyDown(KeyCode.Alpha1)) { builderState.ValueRW.CurrentMode = 1; }
        if (Input.GetKeyDown(KeyCode.Alpha2)) { builderState.ValueRW.CurrentMode = 2; }
        if (Input.GetKeyDown(KeyCode.Alpha3)) { builderState.ValueRW.CurrentMode = 3; }
        if (Input.GetKeyDown(KeyCode.Alpha4)) { builderState.ValueRW.CurrentMode = 4; }
        if (Input.GetKeyDown(KeyCode.Alpha5)) { builderState.ValueRW.CurrentMode = 5; }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.SaveToMaster();
                Debug.Log("⭐⭐⭐ 십장님! 마스터 도면집(Master Blueprint)에 영구 박제 완료!! ⭐⭐⭐");
            }
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.OnPressRKey();
                Debug.Log("🪓 [현장 철거] R키 작동! Temp 서류를 파쇄하고 새 챕터를 시작합니다!");
            }
        }

        currentBuildMode = builderState.ValueRO.CurrentMode;
        guideHeight = builderState.ValueRO.GuideHeight;
        dragStartPos = builderState.ValueRO.GuideStartPos;
        dragEndPos = builderState.ValueRO.GuideEndPos;

        if (Input.GetMouseButtonDown(1))
        {
            UnityEngine.Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastInput rayInput = new RaycastInput { Start = ray.origin, End = ray.origin + ray.direction * 500f, Filter = CollisionFilter.Default };
            if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
            {
                customCenterPos = hit.Position;
                isCenterMoved = true;
            }
        }

        if (Input.GetMouseButtonDown(0)) isCenterMoved = false;

        float3 defaultCenter = new float3((dragStartPos.x + dragEndPos.x) / 2f, 0, (dragStartPos.z + dragEndPos.z) / 2f);
        float3 finalCenter = isCenterMoved ? new float3(customCenterPos.x, 0, customCenterPos.z) : defaultCenter;
        float3 centerOffset = finalCenter - defaultCenter;

        float3 actualStartPos = dragStartPos + centerOffset;
        float3 actualEndPos = dragEndPos + centerOffset;

        float blockSize = 3.0f;

        actualStartPos.x = (float)System.Math.Round(actualStartPos.x / blockSize) * blockSize;
        actualStartPos.z = (float)System.Math.Round(actualStartPos.z / blockSize) * blockSize;
        actualEndPos.x = (float)System.Math.Round(actualEndPos.x / blockSize) * blockSize;
        actualEndPos.z = (float)System.Math.Round(actualEndPos.z / blockSize) * blockSize;
        finalCenter.x = (float)System.Math.Round(finalCenter.x / blockSize) * blockSize;
        finalCenter.z = (float)System.Math.Round(finalCenter.z / blockSize) * blockSize;

        isGuideActive = (math.lengthsq(actualStartPos) > 0.001f || math.lengthsq(actualEndPos) > 0.001f) && actualStartPos.x > -10000f;

        var aiBuilder = UnityEngine.Object.FindFirstObjectByType<AI_Builder>();
        if (aiBuilder != null && aiBuilder.isAiHologramActive)
        {
            isGuideActive = false;
        }

        bool isFKeyPressed = Input.GetKeyDown(KeyCode.F);
        bool isGKeyPressed = Input.GetKeyDown(KeyCode.G);

        // 🚨🚨 [핵심: AI 자동 타설 오더 접수 시스템] 🚨🚨
        // AI가 주문서를 넣었으면 가짜로 G키를 눌러서 십장님 시스템을 속입니다!
        if (AI_Builder.buildQueue != null && AI_Builder.buildQueue.Count > 0)
        {
            var cmd = AI_Builder.buildQueue.Dequeue();
            actualStartPos = cmd.startPos;
            actualEndPos = cmd.endPos;
            currentBuildMode = cmd.mode;
            guideHeight = cmd.height;
            actualStartPos.y = cmd.exactY; // AI가 겹치지 않게 계산한 완벽한 높이!
            actualEndPos.y = cmd.exactY;
            isGuideActive = true;
            isGKeyPressed = true;
            isFKeyPressed = false;
        }

        if (isGuideActive)
        {
            float previewY = actualStartPos.y;
            Entity tempEntity = Entity.Null;
            bool tempHit = false;
            CheckRay(physicsWorld, finalCenter.x, finalCenter.z, ref previewY, ref tempEntity, ref tempHit);

            float snappedHighestY = (float)System.Math.Round(previewY / blockSize) * blockSize;

            float3 drawStartPos = actualStartPos;
            float3 drawEndPos = actualEndPos;
            drawStartPos.y = math.max(actualStartPos.y, snappedHighestY);
            drawEndPos.y = math.max(actualEndPos.y, snappedHighestY);

            DrawGuideWireframe(drawStartPos, drawEndPos, guideHeight, currentBuildMode, blockSize);
        }

        if (isGuideActive && (isFKeyPressed || isGKeyPressed))
        {
            bool isGhost = isFKeyPressed;

            var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
            foreach (var (ghostTag, entity) in SystemAPI.Query<RefRO<GhostBlockTag>>().WithEntityAccess())
            {
                ecb.DestroyEntity(entity);
            }

            float highestY = -9999f;
            Entity hitEntity = Entity.Null;
            bool hitAnything = false;

            float3 startXZ = new float3(actualStartPos.x, 0, actualStartPos.z);
            float3 endXZ = new float3(actualEndPos.x, 0, actualEndPos.z);
            float distance = math.distance(startXZ, endXZ);

            float halfSize = blockSize / 2f;

            if (currentBuildMode == 1)
            {
                float3 mode1Start = startXZ + new float3(halfSize, 0, halfSize);
                float3 mode1End = endXZ + new float3(halfSize, 0, halfSize);
                float dist1 = math.distance(mode1Start, mode1End);
                float3 dir = dist1 < 0.1f ? new float3(1, 0, 0) : math.normalize(mode1End - mode1Start);
                int steps = (int)math.max(1, math.round(dist1 / blockSize));
                for (int i = 0; i <= steps; i++)
                {
                    float3 p = mode1Start + dir * (i * (dist1 / math.max(1, steps)));
                    CheckRay(physicsWorld, p.x, p.z, ref highestY, ref hitEntity, ref hitAnything);
                }
            }
            else if (currentBuildMode == 2 || currentBuildMode == 4)
            {
                float minX = math.min(startXZ.x, endXZ.x); float maxX = math.max(startXZ.x, endXZ.x);
                float minZ = math.min(startXZ.z, endXZ.z); float maxZ = math.max(startXZ.z, endXZ.z);
                for (float x = minX; x <= maxX + 0.1f; x += blockSize)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += blockSize)
                    {
                        if (currentBuildMode == 2)
                        {
                            if (x > minX + (blockSize * 0.5f) && x < maxX - (blockSize * 0.5f) && z > minZ + (blockSize * 0.5f) && z < maxZ - (blockSize * 0.5f)) continue;
                        }
                        CheckRay(physicsWorld, x + halfSize, z + halfSize, ref highestY, ref hitEntity, ref hitAnything);
                    }
                }
            }
            else if (currentBuildMode == 3 || currentBuildMode == 5)
            {
                float radius = distance / 2.0f;
                float3 center = (startXZ + endXZ) / 2.0f;
                int baseRadiusCount = (int)math.floor(radius / blockSize);

                for (int x = -baseRadiusCount; x <= baseRadiusCount; x++)
                {
                    for (int z = -baseRadiusCount; z <= baseRadiusCount; z++)
                    {
                        if (math.sqrt(x * x + z * z) <= baseRadiusCount + 0.5f)
                        {
                            float checkX = center.x + (x * blockSize);
                            float checkZ = center.z + (z * blockSize);
                            CheckRay(physicsWorld, checkX, checkZ, ref highestY, ref hitEntity, ref hitAnything);
                        }
                    }
                }
            }

            if (hitAnything)
            {
                float finalBuildY = math.max(highestY, actualStartPos.y);

                if (LogManager.Instance != null)
                {
                    string toolName = GetToolName(currentBuildMode);
                    int height = (int)math.round(guideHeight);
                    string actionStr = isGhost ? "Key_F" : "Key_G";
                    string statusStr = isGhost ? "Preview_Hologram" : "Build_Complete";

                    float sizeX = math.abs(actualEndPos.x - actualStartPos.x) + blockSize;
                    float sizeZ = math.abs(actualEndPos.z - actualStartPos.z) + blockSize;

                    float calcCenterX = (actualStartPos.x + actualEndPos.x) / 2f;
                    float calcCenterZ = (actualStartPos.z + actualEndPos.z) / 2f;

                    float trueCenterX = math.floor(calcCenterX / blockSize) * blockSize + (blockSize / 2f);
                    float trueCenterY = finalBuildY + (blockSize / 2f);
                    float trueCenterZ = math.floor(calcCenterZ / blockSize) * blockSize + (blockSize / 2f);

                    string centerStr = $"[{trueCenterX:F1}, {trueCenterY:F1}, {trueCenterZ:F1}]";

                    LogManager.Instance.AddLog(toolName, height, actionStr, statusStr, centerStr, sizeX, sizeZ);
                }

                ExecuteBuild(ref state, spawnerData, actualStartPos, actualEndPos, finalBuildY, hitEntity, isGhost);

                if (!isGhost) isGuideActive = false;
            }
        }
    }

    private void ExecuteBuild(ref SystemState state, SpawnerData data, float3 actualStart, float3 actualEnd, float targetY, Entity hitEntity, bool isGhost)
    {
        bool hitExistingBlock = SystemAPI.HasComponent<BlockTag>(hitEntity);
        float3 hitEntityPos = hitExistingBlock ? SystemAPI.GetComponent<LocalTransform>(hitEntity).Position : float3.zero;

        switch (currentBuildMode)
        {
            case 1: BuildSolidWall(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 2: BuildEmptyFrame(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 3: BuildCircularPattern(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 4: BuildPyramid(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 5: BuildCone(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
        }

        if (!isGhost) nextStructureID++;
    }

    private void CheckRay(PhysicsWorld physicsWorld, float x, float z, ref float highestY, ref Entity hitEntity, ref bool hitAnything)
    {
        float3 rayPos = new float3(x, 100f, z);
        RaycastInput rayInput = new RaycastInput { Start = rayPos, End = rayPos + new float3(0, -200f, 0), Filter = CollisionFilter.Default };
        if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
        {
            hitAnything = true;
            if (hit.Position.y > highestY) { highestY = hit.Position.y; hitEntity = hit.Entity; }
        }
    }

    private void DrawGuideWireframe(float3 start, float3 end, float heightParam, int mode, float blockSize)
    {
        Color color = Color.green;
        float floorHeight = blockSize;

        if (mode == 1 || mode == 2)
        {
            float minX = math.min(start.x, end.x);
            float maxX = math.max(start.x, end.x) + blockSize;
            float minZ = math.min(start.z, end.z);
            float maxZ = math.max(start.z, end.z) + blockSize;

            float minY = start.y;
            float maxY = start.y + (heightParam * floorHeight);

            Vector3 p1 = new Vector3(minX, minY, minZ);
            Vector3 p2 = new Vector3(maxX, minY, minZ);
            Vector3 p3 = new Vector3(maxX, minY, maxZ);
            Vector3 p4 = new Vector3(minX, minY, maxZ);

            Debug.DrawLine(p1, p2, color); Debug.DrawLine(p2, p3, color);
            Debug.DrawLine(p3, p4, color); Debug.DrawLine(p4, p1, color);

            if (heightParam > 0)
            {
                Vector3 t1 = new Vector3(minX, maxY, minZ);
                Vector3 t2 = new Vector3(maxX, maxY, minZ);
                Vector3 t3 = new Vector3(maxX, maxY, maxZ);
                Vector3 t4 = new Vector3(minX, maxY, maxZ);

                Debug.DrawLine(t1, t2, color); Debug.DrawLine(t2, t3, color);
                Debug.DrawLine(t3, t4, color); Debug.DrawLine(t4, t1, color);

                Debug.DrawLine(p1, t1, color); Debug.DrawLine(p2, t2, color);
                Debug.DrawLine(p3, t3, color); Debug.DrawLine(p4, t4, color);
            }
        }
        else if (mode == 3 || mode == 4 || mode == 5)
        {
            float3 center = (start + end) / 2f;
            center.x += (blockSize / 2f);
            center.z += (blockSize / 2f);

            float radius = (math.distance(start, end) / 2f) + (blockSize / 2f);

            float minY = start.y;
            float maxY = start.y + (heightParam * floorHeight);

            int segments = 24; float angleStep = (2f * math.PI) / segments;
            Vector3 prev = center + new float3(radius, 0, 0);
            prev.y = minY;

            for (int i = 1; i <= segments; i++)
            {
                Vector3 next = center + new float3(math.cos(i * angleStep) * radius, 0, math.sin(i * angleStep) * radius);
                next.y = minY;
                Debug.DrawLine(prev, next, color);
                prev = next;
            }
            if (heightParam > 0)
            {
                Debug.DrawLine(new Vector3(center.x, minY, center.z), new Vector3(center.x, maxY, center.z), color);
            }
        }
    }

    private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));
        ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f)));
    }
}