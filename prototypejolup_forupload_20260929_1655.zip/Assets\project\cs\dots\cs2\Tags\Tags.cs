using Unity.Entities;

// 1. 이 엔티티가 '블록'임을 알려주는 꼬리표
public struct BlockTag : IComponentData { }

// 2. 이 엔티티가 '조인트'임을 알려주는 꼬리표
public struct JointTag : IComponentData { }

// 3. (보너스) 나중에 파괴 시스템 만들 때 쓸 꼬리표
public struct DestroyTag : IComponentData { }

// 4. M모드에서 발사된 프리팹임을 표시 (M모드 끝날 때 이 태그 붙은 것들만 정리해서 지움)
public struct ShotProjectileTag : IComponentData { }

public struct StructureID : IComponentData
{
    public float Value; // 같은 값 = 같은 덩어리(하나의 객체)
}