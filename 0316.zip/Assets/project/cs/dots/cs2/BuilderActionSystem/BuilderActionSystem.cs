﻿using Unity.Entities;
using UnityEngine;

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct BuilderActionSystem : ISystem
{
    public void OnUpdate(ref SystemState state)
    {
        var builderState = SystemAPI.GetSingleton<BuilderStateData>();
        var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);

        // [Enter 키]: 가이드 확정 및 건설 실행
        if (Input.GetKeyDown(KeyCode.Return) && builderState.CurrentMode >= 1 && builderState.CurrentMode <= 6)
        {
            Debug.Log($"[건설 확정] {builderState.CurrentMode}번 구조물 생성!");
            // 여기에 각 모드별 블록 Instantiate 및 Physics Joint 연결 로직 호출
        }

        // [H 키]: 0번 모드에서 선택된 블록 보호(Lock) 토글
        if (builderState.CurrentMode == 0 && Input.GetKeyDown(KeyCode.H))
        {
            foreach (var (selected, entity) in SystemAPI.Query<RefRO<SelectedTag>>().WithEntityAccess())
            {
                if (SystemAPI.HasComponent<ProtectedTag>(entity))
                {
                    ecb.RemoveComponent<ProtectedTag>(entity);
                    Debug.Log("보호 해제됨");
                }
                else
                {
                    ecb.AddComponent<ProtectedTag>(entity);
                    Debug.Log("보호 설정됨 (R키 면역)");
                }
            }
        }

        // [Delete 키]: 0번 모드에서 선택된 블록 즉시 삭제
        if (builderState.CurrentMode == 0 && Input.GetKeyDown(KeyCode.Delete))
        {
            foreach (var (selected, entity) in SystemAPI.Query<RefRO<SelectedTag>>().WithEntityAccess())
            {
                ecb.DestroyEntity(entity);
            }
            Debug.Log("선택된 객체 삭제 완료");
        }

        // [R 키]: 대청소 (ProtectedTag 없는 모든 블록 삭제)
        if (Input.GetKeyDown(KeyCode.R))
        {
            foreach (var (block, entity) in SystemAPI.Query<RefRO<BlockTag>>().WithEntityAccess())
            {
                if (!SystemAPI.HasComponent<ProtectedTag>(entity))
                {
                    ecb.DestroyEntity(entity);
                }
            }
            Debug.Log("🧹 대청소 완료! (보호된 객체 제외)");
        }

        ecb.Playback(state.EntityManager);
        ecb.Dispose();
    }
}