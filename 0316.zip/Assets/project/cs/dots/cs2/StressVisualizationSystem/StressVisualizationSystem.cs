﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Rendering;

[UpdateInGroup(typeof(SimulationSystemGroup))]
[UpdateAfter(typeof(FixedStepSimulationSystemGroup))] // 물리 연산이 끝난 직후에 계산하여 오차를 가장 정확히 측정
public partial struct StressVisualizationSystem : ISystem
{
    public void OnUpdate(ref SystemState state)
    {
        state.Dependency.Complete();
        // 1. 매 프레임 모든 블록의 목표 스트레스 수치만 초기화 (SmoothedStress는 유지)
        foreach (var stress in SystemAPI.Query<RefRW<BlockStress>>())
        {
            stress.ValueRW.TargetStress = 0f;
        }

        // 2. 물리 조인트를 순회하며 조인트가 벌어진 정도(물리적 오차)를 계산
        var transformLookup = SystemAPI.GetComponentLookup<LocalTransform>(true);
        var stressLookup = SystemAPI.GetComponentLookup<BlockStress>(false);

        foreach (var (pair, joint) in SystemAPI.Query<RefRO<PhysicsConstrainedBodyPair>, RefRO<PhysicsJoint>>())
        {
            Entity entityA = pair.ValueRO.EntityA;
            Entity entityB = pair.ValueRO.EntityB;

            if (transformLookup.HasComponent(entityA) && transformLookup.HasComponent(entityB))
            {
                var transA = transformLookup[entityA];
                var transB = transformLookup[entityB];

                // 조인트가 붙잡고 있으려는 양쪽 피벗의 현재 월드 좌표 계산 (.Position 사용)
                float3 pivotA = math.transform(new RigidTransform(transA.Rotation, transA.Position), joint.ValueRO.BodyAFromJoint.Position);
                float3 pivotB = math.transform(new RigidTransform(transB.Rotation, transB.Position), joint.ValueRO.BodyBFromJoint.Position);

                // 피벗 사이의 거리가 곧 물리 엔진이 겪고 있는 '스트레스(벌어짐)' 입니다.
                float currentStress = math.distance(pivotA, pivotB);

                // 양쪽 블록에 스트레스 누적 더하기
                if (stressLookup.HasComponent(entityA))
                {
                    var s = stressLookup[entityA];
                    s.TargetStress += currentStress;
                    stressLookup[entityA] = s;
                }
                if (stressLookup.HasComponent(entityB))
                {
                    var s = stressLookup[entityB];
                    s.TargetStress += currentStress;
                    stressLookup[entityB] = s;
                }
            }
        }

        // 3. 누적된 스트레스를 바탕으로 색상 변환 (부드러운 전환 적용)
        // 💡 팁: 블록이 너무 쉽게 빨개지면 maxStress를 높이고, 잘 안 빨개지면 낮추세요.
        float maxStress = 0.5f;
        float dt = SystemAPI.Time.DeltaTime;
        float smoothSpeed = 10f; // 숫자가 작을수록 색상이 더 천천히(끈적하게) 변합니다.

        foreach (var (stress, color) in SystemAPI.Query<RefRW<BlockStress>, RefRW<URPMaterialPropertyBaseColor>>())
        {
            // 목표 스트레스 값으로 서서히 이동 (Lerp)
            stress.ValueRW.SmoothedStress = math.lerp(stress.ValueRO.SmoothedStress, stress.ValueRO.TargetStress, dt * smoothSpeed);

            // 화면에는 부드러워진 스트레스 값을 기준으로 색상 표시
            float t = math.clamp(stress.ValueRO.SmoothedStress / maxStress, 0f, 1f);

            // R(빨강)은 1로 유지하고, G와 B를 깎아서 점점 붉은색이 되도록 보간 (t가 0이면 흰색, 1이면 빨간색)
            color.ValueRW.Value = new float4(1f, 1f - t, 1f - t, 1f);
        }
    }
}