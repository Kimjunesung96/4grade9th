﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

public partial struct SpawnerSystem
{
    // 거대 판자(바닥/천장) 생성 함수
    private Entity CreateGiantPlate(ref EntityCommandBuffer ecb, SpawnerData data, float3 pos, float width, float depth, int structureID, bool isFoundation)
    {
        var instance = ecb.Instantiate(data.Prefab);
        float height = 1.0f;

        ecb.SetComponent(instance, LocalTransform.FromPosition(pos));
        ecb.AddComponent(instance, new PostTransformMatrix { Value = float4x4.Scale(width, height, depth) });

        // 물리 콜라이더 (내력벽 위에 물리적으로 얹히도록 깎지 않고 꽉 채움)
        BlobAssetReference<Unity.Physics.Collider> plateCollider = Unity.Physics.BoxCollider.Create(new BoxGeometry
        {
            Center = float3.zero,
            Orientation = quaternion.identity,
            Size = new float3(width, height, depth),
            BevelRadius = 0.05f
        });
        ecb.SetComponent(instance, new PhysicsCollider { Value = plateCollider });

        if (isFoundation)
        {
            // 바닥은 무적(Kinematic)
            ecb.SetComponent(instance, Unity.Physics.PhysicsMass.CreateKinematic(plateCollider.Value.MassProperties));
        }
        else
        {
            // 천장은 가볍게(50.0f) 설정하여 벽에 무리를 주지 않음
            float lightMass = 50.0f;
            PhysicsMass newMass = Unity.Physics.PhysicsMass.CreateDynamic(plateCollider.Value.MassProperties, lightMass);
            ecb.SetComponent(instance, newMass);
        }

        ecb.AddComponent<BlockTag>(instance);
        ecb.AddComponent<BlockStress>(instance);
        ecb.AddComponent(instance, new StructureID { Value = structureID });
        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = new float4(0.2f, 0.2f, 0.2f, 1) });

        return instance;
    }

    private void BuildEmptyFrame(ref SystemState state, SpawnerData data, float3 start, float3 end, float targetY, Entity hitEntity, float3 hitEntityPos, int structureID)
    {
        var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
        float blockSize = 3.0f;
        float halfSize = blockSize / 2.0f;
        float margin = 0.05f;

        int widthCount = (int)math.max(1, math.round(math.abs(end.x - start.x) / blockSize));
        int depthCount = (int)math.max(1, math.round(math.abs(end.z - start.z) / blockSize));
        int heightCount = (int)math.max(1, math.round(guideHeight));
        float3 startCorner = new float3(math.min(start.x, end.x), 0f, math.min(start.z, end.z));

        float realWidth = widthCount * blockSize;
        float realDepth = depthCount * blockSize;

        float3 centerXZ = new float3(startCorner.x + (realWidth / 2f) - halfSize, 0, startCorner.z + (realDepth / 2f) - halfSize);
        float plateHeight = 1.0f;

        // 1. 바닥 판 생성 및 고정
        float3 bottomPos = new float3(centerXZ.x, targetY - (plateHeight / 2f), centerXZ.z);
        Entity bottomPlate = CreateGiantPlate(ref ecb, data, bottomPos, realWidth, realDepth, structureID, true);
        if (hitEntity != Entity.Null) CreateIndestructibleJoint(ref ecb, hitEntity, bottomPlate, bottomPos - hitEntityPos);

        // 2. 천장 판 생성
        float3 topPos = new float3(centerXZ.x, targetY + (heightCount * blockSize) + (plateHeight / 2f), centerXZ.z);
        Entity topPlate = CreateGiantPlate(ref ecb, data, topPos, realWidth, realDepth, structureID, false);

        NativeArray<Entity> grid = new NativeArray<Entity>(widthCount * heightCount * depthCount, Allocator.Temp);
        for (int i = 0; i < grid.Length; i++) grid[i] = Entity.Null;
        int GetIndex(int x, int h, int z) => x + (h * widthCount * depthCount) + (z * widthCount);

        // 3. 벽 블록 생성 및 하중 분산 조인트 연결
        for (int h = 0; h < heightCount; h++)
        {
            for (int x = 0; x < widthCount; x++)
            {
                for (int z = 0; z < depthCount; z++)
                {
                    if (x == 0 || x == widthCount - 1 || z == 0 || z == depthCount - 1)
                    {
                        float3 pos = new float3(startCorner.x + (x * blockSize) + halfSize, targetY + halfSize + (h * blockSize), startCorner.z + (z * blockSize) + halfSize);
                        var instance = ecb.Instantiate(data.Prefab);
                        ecb.SetComponent(instance, LocalTransform.FromPositionRotationScale(pos, quaternion.identity, blockSize - margin));
                        ecb.AddComponent<BlockTag>(instance);
                        ecb.AddComponent<BlockStress>(instance);
                        ecb.AddComponent(instance, new StructureID { Value = structureID });
                        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = new float4(1, 1, 1, 1) });

                        grid[GetIndex(x, h, z)] = instance;

                        // ⭐ 회원님의 핵심 오더 반영: "내력벽들이 힘을 받게 하라"
                        bool isCorner = (x == 0 && z == 0) || (x == widthCount - 1 && z == 0) || (x == 0 && z == depthCount - 1) || (x == widthCount - 1 && z == depthCount - 1);

                        // 바닥(닻)은 안정성을 위해 모서리 4개만 꽉 잡아줍니다.
                        if (h == 0 && isCorner) CreateIndestructibleJoint(ref ecb, bottomPlate, instance, pos - bottomPos);

                        // 천장은 "모든 최상단 블록"에 조인트를 연결합니다. 
                        // 이제 조인트가 분산되어 독박 쓰지 않고, 모든 내력벽이 천장을 '함께' 지탱합니다.
                        if (h == heightCount - 1)
                        {
                            CreateIndestructibleJoint(ref ecb, instance, topPlate, topPos - pos);
                        }
                    }
                }
            }
        }

        // 4. 벽 블록 간 격자 용접 (벽 자체가 무너지지 않게 지탱)
        for (int h = 0; h < heightCount; h++)
        {
            for (int x = 0; x < widthCount; x++)
            {
                for (int z = 0; z < depthCount; z++)
                {
                    Entity current = grid[GetIndex(x, h, z)];
                    if (current == Entity.Null) continue;

                    if (x < widthCount - 1 && grid[GetIndex(x + 1, h, z)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x + 1, h, z)], new float3(blockSize, 0, 0));
                    if (z < depthCount - 1 && grid[GetIndex(x, h, z + 1)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x, h, z + 1)], new float3(0, 0, blockSize));
                    if (h < heightCount - 1 && grid[GetIndex(x, h + 1, z)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x, h + 1, z)], new float3(0, blockSize, 0));
                }
            }
        }
        grid.Dispose();
    }
}