﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

public partial struct SpawnerSystem
{
    private void BuildCircularPattern(ref SystemState state, SpawnerData data, float3 startPos, float3 endPos, float targetY, Entity hitEntity, float3 hitEntityPos, int structureID)
    {
        var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
        float blockSize = 3.0f;
        float halfSize = blockSize / 2.0f;

        // ⭐ 난리부르스 해결 1: 블록끼리 비비적대지 않게 미세한 틈(마진)을 줍니다!
        float margin = 0.05f;

        float3 startXZ = new float3(startPos.x, 0, startPos.z);
        float3 endXZ = new float3(endPos.x, 0, endPos.z);
        float radius = math.distance(startXZ, endXZ) / 2.0f;
        float3 realCenter = (startXZ + endXZ) / 2.0f;

        if (radius < blockSize) return;

        float circumference = 2.0f * math.PI * radius;
        int pillarCount = math.max(4, Mathf.RoundToInt(circumference / (blockSize * 1.1f)));
        float angleStep = (2.0f * math.PI) / pillarCount;
        int floors = (int)math.max(1, math.round(guideHeight));

        float plateHeight = 1.0f;
        float realWidth = (radius * 2) + blockSize;
        float3 bottomPos = new float3(realCenter.x, targetY - (plateHeight / 2f), realCenter.z);

        Entity bottomPlate = CreateGiantPlate(ref ecb, data, bottomPos, realWidth, realWidth, structureID, true);

        if (hitEntity != Entity.Null) CreateIndestructibleJoint(ref ecb, hitEntity, bottomPlate, bottomPos - hitEntityPos);

        NativeArray<Entity> ring = new NativeArray<Entity>(pillarCount * floors, Allocator.Temp);
        int GetRingIndex(int p, int f) => p + (f * pillarCount);

        for (int y = 0; y < floors; y++)
        {
            for (int i = 0; i < pillarCount; i++)
            {
                float angle = i * angleStep;
                float3 forwardDir = new float3(math.cos(angle), 0f, math.sin(angle));
                float3 pos = realCenter + forwardDir * radius;
                pos.y = targetY + halfSize + (y * blockSize);
                quaternion rot = quaternion.LookRotationSafe(forwardDir, math.up());

                var pillar = ecb.Instantiate(data.Prefab);

                // ⭐ 난리부르스 해결 1 적용: 크기를 살짝(blockSize - margin) 깎아서 소환!
                ecb.SetComponent(pillar, LocalTransform.FromPositionRotationScale(pos, rot, blockSize - margin));

                ecb.AddComponent<BlockTag>(pillar);
                ecb.AddComponent<BlockStress>(pillar);
                ecb.AddComponent(pillar, new StructureID { Value = structureID });
                ecb.AddComponent(pillar, new URPMaterialPropertyBaseColor { Value = new float4(1, 1, 1, 1) });

                ring[GetRingIndex(i, y)] = pillar;

                // ⭐ 난리부르스 해결 2 (회원님 아이디어): 바닥 닻을 4방향에서 8방향(/ 8)으로 두 배 늘림!
                bool isAnchor = (i % (math.max(1, pillarCount / 8)) == 0);
                if (y == 0 && isAnchor) CreateIndestructibleJoint(ref ecb, bottomPlate, pillar, pos - bottomPos);
            }
        }

        for (int y = 0; y < floors; y++)
        {
            for (int i = 0; i < pillarCount; i++)
            {
                Entity current = ring[GetRingIndex(i, y)];
                Entity nextHorizontal = ring[GetRingIndex((i + 1) % pillarCount, y)];

                float currentAngle = i * angleStep;
                float nextAngle = ((i + 1) % pillarCount) * angleStep;

                float3 currentDir = new float3(math.cos(currentAngle), 0f, math.sin(currentAngle));
                float3 nextDir = new float3(math.cos(nextAngle), 0f, math.sin(nextAngle));

                float3 currentPos = realCenter + currentDir * radius;
                float3 nextPos = realCenter + nextDir * radius;

                float3 horizontalOffset = nextPos - currentPos;
                CreateIndestructibleJoint(ref ecb, current, nextHorizontal, horizontalOffset);

                if (y < floors - 1)
                {
                    Entity nextVertical = ring[GetRingIndex(i, y + 1)];
                    CreateIndestructibleJoint(ref ecb, current, nextVertical, new float3(0, blockSize, 0));
                }
            }
        }
        ring.Dispose();
    }
}