﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Collections;
using Unity.Rendering;

public partial struct SpawnerSystem
{
    private void BuildSolidWall(ref SystemState state, SpawnerData data, float3 start, float3 end, float targetY, Entity hitEntity, float3 hitEntityPos, int structureID)
    {
        var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);

        float blockSize = 3.0f;
        float halfSize = blockSize / 2.0f;
        float margin = 0.05f;

        float3 startXZ = new float3(start.x, 0, start.z);
        float3 endXZ = new float3(end.x, 0, end.z);
        float distance = math.distance(startXZ, endXZ);

        float3 direction = distance < 0.1f ? new float3(1, 0, 0) : math.normalize(endXZ - startXZ);

        int blockCount = (int)math.max(1, math.round(distance / blockSize));
        int heightCount = (int)math.max(1, math.round(guideHeight));

        NativeArray<Entity> grid = new NativeArray<Entity>(blockCount * heightCount, Allocator.Temp);

        for (int i = 0; i < blockCount; i++)
        {
            for (int h = 0; h < heightCount; h++)
            {
                var instance = ecb.Instantiate(data.Prefab);
                float3 pos = startXZ + (direction * (i * blockSize));
                pos.y = targetY + halfSize + (h * blockSize);

                ecb.SetComponent(instance, LocalTransform.FromPositionRotationScale(pos, quaternion.identity, blockSize - margin));
                ecb.AddComponent<BlockTag>(instance);
                ecb.AddComponent<BlockStress>(instance);
                ecb.AddComponent(instance, new StructureID { Value = structureID });
                ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = new float4(1, 1, 1, 1) });

                grid[i * heightCount + h] = instance;

                // ⭐ 4.5f(1.5칸) 이내로 가까이 붙어있는 블록끼리만 용접! 멀면 무시!
                if (h == 0 && hitEntity != Entity.Null && math.distance(pos, hitEntityPos) < blockSize * 1.5f)
                {
                    CreateIndestructibleJoint(ref ecb, hitEntity, instance, pos - hitEntityPos);
                }
            }
        }

        for (int i = 0; i < blockCount; i++)
        {
            for (int h = 0; h < heightCount; h++)
            {
                Entity current = grid[i * heightCount + h];
                if (i < blockCount - 1)
                    CreateIndestructibleJoint(ref ecb, current, grid[(i + 1) * heightCount + h], direction * blockSize);
                if (h < heightCount - 1)
                    CreateIndestructibleJoint(ref ecb, current, grid[i * heightCount + (h + 1)], new float3(0, blockSize, 0));
            }
        }
        grid.Dispose();
    }
}