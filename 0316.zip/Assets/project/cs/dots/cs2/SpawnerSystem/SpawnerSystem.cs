﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct SpawnerSystem : ISystem
{
    private bool isDragging;
    private float3 dragStartPos;
    private float3 dragEndPos;

    private int currentBuildMode;
    private float guideHeight;
    private bool isGuideActive;
    private int nextStructureID;

    public void OnCreate(ref SystemState state)
    {
        currentBuildMode = 1;
        guideHeight = 1f;
        isGuideActive = false;
        nextStructureID = 1;
    }

    public void OnUpdate(ref SystemState state)
    {
        if (!UnityEngine.Application.isPlaying) return;
        if (Camera.main == null) return;
        if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsSingleton)) return;

        SpawnerData spawnerData = default;
        bool hasSpawner = false;
        foreach (var data in SystemAPI.Query<RefRO<SpawnerData>>())
        {
            spawnerData = data.ValueRO;
            hasSpawner = true;
            break;
        }

        if (!hasSpawner) return;

        PhysicsWorld physicsWorld = physicsSingleton.PhysicsWorld;
        UnityEngine.Plane buildPlane = new UnityEngine.Plane(Vector3.up, Vector3.zero);
        UnityEngine.Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Input.GetKeyDown(KeyCode.Alpha1)) { currentBuildMode = 1; isGuideActive = false; Debug.Log($"[모드 변경] 1번: 수직 벽 (현재 층수: {guideHeight})"); }
        if (Input.GetKeyDown(KeyCode.Alpha2)) { currentBuildMode = 2; isGuideActive = false; Debug.Log($"[모드 변경] 2번: 수평 프레임 (현재 층수: {guideHeight})"); }
        if (Input.GetKeyDown(KeyCode.Alpha3)) { currentBuildMode = 3; isGuideActive = false; Debug.Log($"[모드 변경] 3번: 수평 원형 (현재 층수: {guideHeight})"); }
        if (Input.GetKeyDown(KeyCode.Alpha4)) { currentBuildMode = 4; isGuideActive = false; Debug.Log($"[모드 변경] 4번: 피라미드 (현재 층수: {guideHeight})"); }
        if (Input.GetKeyDown(KeyCode.Alpha5)) { currentBuildMode = 5; isGuideActive = false; Debug.Log($"[모드 변경] 5번: 원뿔 (현재 층수: {guideHeight})"); }
        if (Input.GetKeyDown(KeyCode.Alpha6)) { currentBuildMode = 6; isGuideActive = false; Debug.Log($"[모드 변경] 6번: 모터 (현재 층수: {guideHeight})"); }

        if (Input.mouseScrollDelta.y != 0)
        {
            guideHeight += Input.mouseScrollDelta.y;
            if (guideHeight < 1f) guideHeight = 1f;
            Debug.Log($"[층수 조절] 현재 층수: {guideHeight}층 (모드: {currentBuildMode}번)");
        }

        if (Input.GetMouseButtonDown(0))
        {
            if (buildPlane.Raycast(mouseRay, out float enter))
            {
                dragStartPos = mouseRay.GetPoint(enter);
                isDragging = true;
                isGuideActive = false;
            }
        }
        else if (Input.GetMouseButton(0) && isDragging)
        {
            if (buildPlane.Raycast(mouseRay, out float enter)) dragEndPos = mouseRay.GetPoint(enter);
        }
        else if (Input.GetMouseButtonUp(0) && isDragging)
        {
            isDragging = false;
            isGuideActive = true;
        }

        if (isDragging || isGuideActive) DrawGuideWireframe(dragStartPos, dragEndPos, guideHeight, currentBuildMode);

        if (isGuideActive && Input.GetKeyDown(KeyCode.Space))
        {
            float highestY = -9999f;
            Entity hitEntity = Entity.Null;
            bool hitAnything = false;
            float blockSize = 3.0f;

            float3 startXZ = new float3(dragStartPos.x, 0, dragStartPos.z);
            float3 endXZ = new float3(dragEndPos.x, 0, dragEndPos.z);
            float distance = math.distance(startXZ, endXZ);

            // ⭐ 거대한 박스 대신, 짓는 모양을 따라가며 정밀하게 스캔합니다! (허공 띄우기 버그 완벽 차단)
            if (currentBuildMode == 1)
            {
                float3 dir = distance < 0.1f ? new float3(1, 0, 0) : math.normalize(endXZ - startXZ);
                int steps = (int)math.max(1, math.round(distance / (blockSize * 0.5f)));
                for (int i = 0; i <= steps; i++)
                {
                    float3 p = startXZ + dir * (i * (distance / math.max(1, steps)));
                    CheckRay(physicsWorld, p.x, p.z, ref highestY, ref hitEntity, ref hitAnything);
                }
            }
            else if (currentBuildMode == 2 || currentBuildMode == 4)
            {
                float minX = math.min(startXZ.x, endXZ.x); float maxX = math.max(startXZ.x, endXZ.x);
                float minZ = math.min(startXZ.z, endXZ.z); float maxZ = math.max(startXZ.z, endXZ.z);
                for (float x = minX; x <= maxX + 0.1f; x += 1.0f)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += 1.0f)
                    {
                        if (currentBuildMode == 2)
                        {
                            if (x > minX + 1.5f && x < maxX - 1.5f && z > minZ + 1.5f && z < maxZ - 1.5f) continue;
                        }
                        CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                    }
                }
            }
            else if (currentBuildMode == 3 || currentBuildMode == 5)
            {
                float radius = distance / 2.0f;
                float3 center = (startXZ + endXZ) / 2.0f;
                float minX = center.x - radius; float maxX = center.x + radius;
                float minZ = center.z - radius; float maxZ = center.z + radius;
                for (float x = minX; x <= maxX + 0.1f; x += 1.0f)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += 1.0f)
                    {
                        float distSq = math.distancesq(new float3(x, 0, z), center);
                        if (distSq <= radius * radius)
                        {
                            if (currentBuildMode == 3 && distSq < (radius - 1.5f) * (radius - 1.5f)) continue;
                            CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                        }
                    }
                }
            }
            else if (currentBuildMode == 6) CheckRay(physicsWorld, startXZ.x, startXZ.z, ref highestY, ref hitEntity, ref hitAnything);

            if (hitAnything)
            {
                bool hitExistingBlock = SystemAPI.HasComponent<BlockTag>(hitEntity);
                float3 hitEntityPos = float3.zero;
                if (hitExistingBlock) hitEntityPos = SystemAPI.GetComponent<LocalTransform>(hitEntity).Position;

                if (currentBuildMode == 1) BuildSolidWall(ref state, spawnerData, dragStartPos, dragEndPos, highestY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID);
                else if (currentBuildMode == 2) BuildEmptyFrame(ref state, spawnerData, dragStartPos, dragEndPos, highestY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID);
                else if (currentBuildMode == 3) BuildCircularPattern(ref state, spawnerData, dragStartPos, dragEndPos, highestY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID);
                else if (currentBuildMode == 4) BuildPyramid(ref state, spawnerData, dragStartPos, dragEndPos, highestY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID);
                else if (currentBuildMode == 5) BuildCone(ref state, spawnerData, dragStartPos, dragEndPos, highestY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID);
                else if (currentBuildMode == 6) BuildMotorPlate(ref state, spawnerData, dragStartPos, highestY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID);

                nextStructureID++;
                isGuideActive = false;
            }
        }
    }

    // ⭐ 레이캐스트 유틸리티 함수
    private void CheckRay(PhysicsWorld physicsWorld, float x, float z, ref float highestY, ref Entity hitEntity, ref bool hitAnything)
    {
        float3 rayPos = new float3(x, 100f, z);
        RaycastInput rayInput = new RaycastInput { Start = rayPos, End = rayPos + new float3(0, -200f, 0), Filter = CollisionFilter.Default };
        if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
        {
            hitAnything = true;
            if (hit.Position.y > highestY) { highestY = hit.Position.y; hitEntity = hit.Entity; }
        }
    }

    private void DrawGuideWireframe(float3 start, float3 end, float heightParam, int mode)
    {
        Color color = isGuideActive ? Color.green : Color.yellow;
        float blockSize = 3.0f;
        float h = heightParam * blockSize;

        float3 startXZ = new float3(start.x, start.y, start.z);
        float3 endXZ = new float3(end.x, start.y, end.z);
        float3 center = (startXZ + endXZ) / 2f;
        float radius = math.distance(startXZ, endXZ) / 2f;

        if (mode == 1 || mode == 2)
        {
            Vector3 p1 = new Vector3(start.x, start.y, start.z); Vector3 p2 = new Vector3(end.x, start.y, start.z);
            Vector3 p3 = new Vector3(end.x, start.y, end.z); Vector3 p4 = new Vector3(start.x, start.y, end.z);

            Debug.DrawLine(p1, p2, color); Debug.DrawLine(p2, p3, color); Debug.DrawLine(p3, p4, color); Debug.DrawLine(p4, p1, color);
            if (heightParam > 1)
            {
                Vector3 t1 = p1 + Vector3.up * h; Vector3 t2 = p2 + Vector3.up * h; Vector3 t3 = p3 + Vector3.up * h; Vector3 t4 = p4 + Vector3.up * h;
                Debug.DrawLine(t1, t2, color); Debug.DrawLine(t2, t3, color); Debug.DrawLine(t3, t4, color); Debug.DrawLine(t4, t1, color);
                Debug.DrawLine(p1, t1, color); Debug.DrawLine(p2, t2, color); Debug.DrawLine(p3, t3, color); Debug.DrawLine(p4, t4, color);
            }
        }
        else if (mode == 3 || mode == 4 || mode == 5)
        {
            int segments = 24; float angleStep = (2f * math.PI) / segments;
            Vector3 prevPoint = center + new float3(math.cos(0), 0, math.sin(0)) * radius;

            for (int i = 1; i <= segments; i++)
            {
                float angle = i * angleStep;
                Vector3 nextPoint = center + new float3(math.cos(angle), 0, math.sin(angle)) * radius;
                Debug.DrawLine(prevPoint, nextPoint, color);
                prevPoint = nextPoint;
            }
            if (heightParam > 1)
            {
                Vector3 topPoint = center + new float3(0, h, 0);
                Debug.DrawLine(center + new float3(radius, 0, 0), topPoint, color); Debug.DrawLine(center + new float3(-radius, 0, 0), topPoint, color);
                Debug.DrawLine(center + new float3(0, 0, radius), topPoint, color); Debug.DrawLine(center + new float3(0, 0, -radius), topPoint, color);
            }
        }
        else if (mode == 6) Debug.DrawRay(start, Vector3.up * blockSize, color);
    }

    private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, false));

        RigidTransform frameA = new RigidTransform(quaternion.identity, offsetToB * 0.5f);
        RigidTransform frameB = new RigidTransform(quaternion.identity, -offsetToB * 0.5f);
        ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(frameA, frameB));
    }
}