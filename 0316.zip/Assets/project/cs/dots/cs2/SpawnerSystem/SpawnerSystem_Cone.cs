﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Collections;
using Unity.Rendering;

public partial struct SpawnerSystem
{
    private void BuildCone(ref SystemState state, SpawnerData data, float3 startPos, float3 endPos, float targetY, Entity hitEntity, float3 hitEntityPos, int structureID)
    {
        var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
        float blockSize = 3.0f;
        float margin = 0.05f;

        float3 startXZ = new float3(startPos.x, 0, startPos.z);
        float3 endXZ = new float3(endPos.x, 0, endPos.z);
        float radius = math.distance(startXZ, endXZ) / 2.0f;
        float3 center = (startXZ + endXZ) / 2.0f;

        int baseRadiusCount = (int)math.floor(radius / blockSize);
        int floors = Mathf.Max(1, Mathf.RoundToInt(guideHeight));

        int maxGridSize = (baseRadiusCount * 2) + 1;
        NativeArray<Entity> grid = new NativeArray<Entity>(maxGridSize * floors * maxGridSize, Allocator.Temp);
        for (int i = 0; i < grid.Length; i++) grid[i] = Entity.Null;

        int GetIndex(int px, int py, int pz) => px + (py * maxGridSize * maxGridSize) + (pz * maxGridSize);

        for (int y = 0; y < floors; y++)
        {
            int currentRadius = floors == 1 ? baseRadiusCount : (int)math.floor(math.lerp(baseRadiusCount, 0, (float)y / (floors - 1)));
            int nextRadius = y < floors - 1 ? (int)math.floor(math.lerp(baseRadiusCount, 0, (float)(y + 1) / (floors - 1))) : -1;

            for (int x = -currentRadius; x <= currentRadius; x++)
            {
                for (int z = -currentRadius; z <= currentRadius; z++)
                {
                    // ⭐ 구멍 송송 뚫리던 버그 해결: 확실한 루트 계산으로 틈새 봉쇄!
                    float dist = math.sqrt(x * x + z * z);

                    if (dist <= currentRadius + 0.5f && dist >= nextRadius - 0.5f)
                    {
                        float3 pos = center + new float3(x * blockSize, targetY + (y * blockSize) + (blockSize / 2f), z * blockSize);
                        var instance = ecb.Instantiate(data.Prefab);
                        ecb.SetComponent(instance, LocalTransform.FromPositionRotationScale(pos, quaternion.identity, blockSize - margin));
                        ecb.AddComponent<BlockTag>(instance);
                        ecb.AddComponent<BlockStress>(instance);
                        ecb.AddComponent(instance, new StructureID { Value = structureID });
                        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = new float4(1, 1, 1, 1) });

                        grid[GetIndex(x + baseRadiusCount, y, z + baseRadiusCount)] = instance;

                        if (y == 0 && hitEntity != Entity.Null && math.distance(pos, hitEntityPos) < blockSize * 1.5f)
                        {
                            CreateIndestructibleJoint(ref ecb, hitEntity, instance, pos - hitEntityPos);
                        }
                    }
                }
            }
        }

        // ⭐ 스트레스 없는 쾌적한 조인트 연결
        for (int y = 0; y < floors; y++)
        {
            for (int x = 0; x < maxGridSize; x++)
            {
                for (int z = 0; z < maxGridSize; z++)
                {
                    Entity current = grid[GetIndex(x, y, z)];
                    if (current == Entity.Null) continue;

                    if (x < maxGridSize - 1 && grid[GetIndex(x + 1, y, z)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x + 1, y, z)], new float3(blockSize, 0, 0));
                    if (z < maxGridSize - 1 && grid[GetIndex(x, y, z + 1)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x, y, z + 1)], new float3(0, 0, blockSize));

                    if (x < maxGridSize - 1 && z < maxGridSize - 1 && grid[GetIndex(x + 1, y, z + 1)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x + 1, y, z + 1)], new float3(blockSize, 0, blockSize));
                    if (x > 0 && z < maxGridSize - 1 && grid[GetIndex(x - 1, y, z + 1)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x - 1, y, z + 1)], new float3(-blockSize, 0, blockSize));

                    if (y < floors - 1 && grid[GetIndex(x, y + 1, z)] != Entity.Null)
                        CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x, y + 1, z)], new float3(0, blockSize, 0));
                }
            }
        }
        grid.Dispose();
    }
}