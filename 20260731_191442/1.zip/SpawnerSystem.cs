﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;
using Unity.Burst;
using System.IO;
using System.Text;
using System.Linq;

public struct GhostBlockTag : IComponentData { }

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct SpawnerSystem : ISystem
{
    public static System.Collections.Generic.List<float3> ExternalBlueprintData = new System.Collections.Generic.List<float3>();

    public static System.Collections.Generic.List<string> blueprintMaterials = new System.Collections.Generic.List<string>();

    public static bool isOMode = false;
    public static bool isLMode = false;
    public static bool isUMode = false;
    
    // ⭐ [신규 마법] 0,0,0 절대 좌표 고정 모드 (홀로그램 이동 금지)
    public static bool isAbsolutePositionMode = false;
    public static string targetLoadFile = "Reinforcement_Plan.csv";

    public static bool isManualModeEnabled = true;
    public static bool isAimMoveEnabled = true;
    public static bool isHeightScrollEnabled = true;
    public static bool isPreviewFEnabled = true;
    public static bool isBuildGEnabled = true;
    public static bool isClearREnabled = true;

    public static float backupIDToQuery = -1f;

    private float3 dragStartPos;
    private float3 dragEndPos;
    private float currentBuildMode;
    private float guideHeight;
    private bool isGuideActive;
    private float nextStructureID;
    private bool isCenterMoved;
    private float3 customCenterPos;
    private NativeList<BlobAssetReference<Unity.Physics.Collider>> _createdColliders;
    private bool isYMode;

    private NativeList<float4> blueprintOffsets;
    public static float loadDelayTimer;
    private bool pendingJointCleanup;

    private struct TempSpawnData
    {
        public float3 Pos;
        public float IsReinforce;
        public string MatName;
    }

    private string GetToolName(float mode)
    {
        if (math.abs(mode - 1f) < 0.01f) return "1_Solid_Wall";
        else if (math.abs(mode - 2f) < 0.01f) return "2_Empty_Frame";
        else if (math.abs(mode - 3f) < 0.01f) return "3_Circular_Pattern";
        else if (math.abs(mode - 4f) < 0.01f) return "4_Pyramid";
        else if (math.abs(mode - 5f) < 0.01f) return "5_Cone";
        else return "Unknown_Tool";
    }

public void OnCreate(ref SystemState state)
    {
        currentBuildMode = 1f; guideHeight = 1f; isGuideActive = false; nextStructureID = 1f;
        isCenterMoved = false; customCenterPos = float3.zero;
        _createdColliders = new NativeList<BlobAssetReference<Unity.Physics.Collider>>(Allocator.Persistent);
        isYMode = false;
        blueprintOffsets = new NativeList<float4>(Allocator.Persistent);
        loadDelayTimer = 0f; isOMode = false; isLMode = false; isUMode = false; backupIDToQuery = -1f;
        isAbsolutePositionMode = false;

        blueprintMaterials.Clear();

        Time.fixedDeltaTime = 0.05f;
        Time.maximumDeltaTime = 0.1f; 
    }

    public void OnDestroy(ref SystemState state)
    {
        if (_createdColliders.IsCreated) { foreach (var col in _createdColliders) { if (col.IsCreated) col.Dispose(); } _createdColliders.Dispose(); }
        if (blueprintOffsets.IsCreated) blueprintOffsets.Dispose();
    }

public void OnUpdate(ref SystemState state)
    {
        if (!UnityEngine.Application.isPlaying || Camera.main == null) return;
GuideWireframeRenderer.ResetPool();
        if (pendingJointCleanup)
        {
            RemoveDuplicateJoints(ref state);
            pendingJointCleanup = false;
        }

        if (!SystemAPI.HasSingleton<BuilderStateData>()) return;
        var builderState = SystemAPI.GetSingletonRW<BuilderStateData>();
        
        if (SystemAPI.HasSingleton<PhysicsStep>())
        {
            var physicsStep = SystemAPI.GetSingletonRW<PhysicsStep>();
            physicsStep.ValueRW.SolverIterationCount = 2;
        }

        if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsSingleton)) return;
        SpawnerData spawnerData = default;
        bool hasSpawner = false;
        foreach (var data in SystemAPI.Query<RefRO<SpawnerData>>()) { spawnerData = data.ValueRO; hasSpawner = true; break; }
        if (!hasSpawner) return;

        PhysicsWorld physicsWorld = physicsSingleton.PhysicsWorld;

       if (backupIDToQuery > -1f)
        {
            SaveLastBuildingSnapshot(state.EntityManager);
            backupIDToQuery = -1f;
        }

        if (isClearREnabled && Input.GetKeyDown(KeyCode.R)) { 
            if (LogManager.Instance != null) LogManager.Instance.OnPressRKey(); 
            isCenterMoved = false; 
            isAbsolutePositionMode = false; // R 누르면 마법도 해제
        }

        bool isBMode = VibrationTestSystem.IsBModeActive; bool isNMode = ShockwaveTestSystem.IsNModeActive;
        bool isAnySpecialMode = isOMode || isLMode || isYMode || isUMode;

        if (isAimMoveEnabled && !isBMode && !isNMode)
        {
            if (Input.GetMouseButtonDown(1))
            {
                UnityEngine.Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastInput rayInput = new RaycastInput { Start = ray.origin, End = ray.origin + ray.direction * 500f, Filter = CollisionFilter.Default };
                if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
                {
                    customCenterPos = hit.Position;
                    isCenterMoved = true;
                }
            }
        }

        if (!isBMode && !isNMode && !isAnySpecialMode)
        {
            if (isHeightScrollEnabled && Input.mouseScrollDelta.y != 0f) { builderState.ValueRW.GuideHeight += Input.mouseScrollDelta.y; if (builderState.ValueRW.GuideHeight < 1f) builderState.ValueRW.GuideHeight = 1f; }
            if (Input.GetMouseButtonDown(0)) isCenterMoved = false;

            if (isManualModeEnabled)
            {
                if (Input.GetKeyDown(KeyCode.Alpha1)) builderState.ValueRW.CurrentMode = 1;
                if (Input.GetKeyDown(KeyCode.Alpha2)) builderState.ValueRW.CurrentMode = 2;
                if (Input.GetKeyDown(KeyCode.Alpha3)) builderState.ValueRW.CurrentMode = 3;
                if (Input.GetKeyDown(KeyCode.Alpha4)) builderState.ValueRW.CurrentMode = 4;
                if (Input.GetKeyDown(KeyCode.Alpha5)) builderState.ValueRW.CurrentMode = 5;
            }
        }

        if (Input.GetKeyDown(KeyCode.Return)) { if (LogManager.Instance != null) LogManager.Instance.SaveToMaster(); }

        currentBuildMode = (float)builderState.ValueRO.CurrentMode; guideHeight = builderState.ValueRO.GuideHeight; dragStartPos = builderState.ValueRO.GuideStartPos; dragEndPos = builderState.ValueRO.GuideEndPos;

        bool isFKeyPressed = isPreviewFEnabled && !isBMode && !isNMode && Input.GetKeyDown(KeyCode.F);
        bool isGKeyPressed = isBuildGEnabled && !isBMode && !isNMode && Input.GetKeyDown(KeyCode.G);

        bool isAnyBlueprintMode = isOMode || isLMode || isUMode;
        bool triggerSpecialGhost = (isAnyBlueprintMode || isYMode) && (isFKeyPressed || (isAimMoveEnabled && Input.GetMouseButtonDown(1)));
        bool triggerSpecialReal = (isAnyBlueprintMode || isYMode) && isGKeyPressed;

        if (triggerSpecialGhost || triggerSpecialReal)
        {
            float countF = isYMode ? (float)blueprintOffsets.Length : (float)ExternalBlueprintData.Count;
            if (countF > 0f)
            {
                var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
                foreach (var (ghostTag, entity) in SystemAPI.Query<RefRO<GhostBlockTag>>().WithEntityAccess()) { ecb.DestroyEntity(entity); }

                float3 baseCenter = new float3(math.round((customCenterPos.x - 1.5f) / 3.0f) * 3.0f + 1.5f, 0f, math.round((customCenterPos.z - 1.5f) / 3.0f) * 3.0f + 1.5f);
                
                // ⭐ [마법 발동] 절대 좌표 모드일 땐 마우스(baseCenter)를 무시하고 무조건 (0,0,0) 적용!
                if (isYMode && isAbsolutePositionMode)
                {
                    baseCenter = float3.zero;
                }

                var gridMap = new NativeHashMap<int3, Entity>((int)countF, Allocator.Temp);
                var posMap = new NativeHashMap<Entity, float3>((int)countF, Allocator.Temp);
                var matNameMap = new NativeHashMap<Entity, FixedString32Bytes>((int)countF, Allocator.Temp); // ⭐ 스폰 직후(플레이백 전)라 컴포넌트 조회가 안 되므로 재질명을 따로 추적

                for (int i = 0; i < (int)countF; i++)
                {
                    float3 posOffset;
                    bool isReinforceBlock = false;

                    if (isYMode)
                    {
                        float4 data = blueprintOffsets.ElementAt(i);
                        posOffset = new float3(data.x, data.y, data.z);
                        isReinforceBlock = data.w > 0.5f;
                    }
                    else
                    {
                        posOffset = ExternalBlueprintData.ElementAt(i);
                    }

                    float3 finalPos = baseCenter + posOffset;

                    var instance = ecb.Instantiate(spawnerData.Prefab);
                    ecb.SetComponent(instance, LocalTransform.FromPositionRotationScale(finalPos, quaternion.identity, 2.95f));

                    string matName = "Concrete";
                    if (isYMode && i < blueprintMaterials.Count)
                    {
                        matName = blueprintMaterials.ElementAt(i);
                    }
                    else
                    {
                        matName = isReinforceBlock ? "Steel" : "Concrete";
                    }

                    ecb.AddComponent(instance, new BlockMaterial { MaterialName = matName });
                    matNameMap.TryAdd(instance, new FixedString32Bytes(matName));

                    float hp = isReinforceBlock ? 2000f : 1000f;
                    float def = isReinforceBlock ? 600f : 400f;
                    float4 bColor = isReinforceBlock ? new float4(0.2f, 0.5f, 1.0f, 1f) : new float4(0.7f, 0.7f, 0.7f, 1f);

                    if (MaterialDataManager.Instance != null && MaterialDataManager.Instance.MaterialDict.TryGetValue(matName, out var spec))
                    {
                        hp = spec.BaseHP;
                        def = math.min(spec.Tensile, spec.Compressive);
                        bColor = new float4(spec.Color.r, spec.Color.g, spec.Color.b, spec.Color.a);
                    }
                    else
                    {
                        if (matName.Contains("Steel")) bColor = new float4(0.2f, 0.5f, 1.0f, 1.0f);
                        else if (matName.Contains("Wood") || matName.Contains("Timber")) bColor = new float4(0.6f, 0.4f, 0.2f, 1.0f);
                        else if (matName.Contains("Brick")) bColor = new float4(0.8f, 0.3f, 0.2f, 1.0f);
                    }

                    if (triggerSpecialGhost)
                    {
                        ecb.AddComponent<GhostBlockTag>(instance);
                        ecb.RemoveComponent<PhysicsCollider>(instance);
                        ecb.RemoveComponent<PhysicsVelocity>(instance);
                        ecb.RemoveComponent<PhysicsMass>(instance);

                        bColor.w = isReinforceBlock ? 0.8f : 0.4f;
                        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = bColor });
                    }
                    else
                    {
                        ecb.AddComponent<BlockTag>(instance);
                        ecb.AddComponent<BlockStress>(instance);
                        ecb.AddComponent(instance, new StructureID { Value = (int)nextStructureID });

                        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = bColor });

                        if (finalPos.y <= 2.0f) { PhysicsMass m = SystemAPI.GetComponent<PhysicsMass>(spawnerData.Prefab); m.InverseMass = 0f; m.InverseInertia = float3.zero; ecb.SetComponent(instance, m); }

                        int3 key = new int3((int)math.floor(finalPos.x / 3f + 0.5f), (int)math.floor(finalPos.y / 3f + 0.5f), (int)math.floor(finalPos.z / 3f + 0.5f));
                        gridMap.TryAdd(key, instance);
                        posMap.TryAdd(instance, finalPos);

                        if (isYMode)
                        {
                            var bpManager = UnityEngine.Object.FindFirstObjectByType<BlueprintManager>();
                            if (bpManager != null) { 
                                string id = bpManager.VectorToID(new UnityEngine.Vector3(finalPos.x, finalPos.y, finalPos.z)); 
                                string properTool = isReinforceBlock ? "Reinforcement" : "Existing"; 
                                bpManager.AddReinforcementBlock(id, properTool, new UnityEngine.Vector3(finalPos.x, finalPos.y, finalPos.z)); 
                            }
                        }
                    }
                }
                
                if (triggerSpecialReal)
                {
                    var keys = gridMap.GetKeyArray(Allocator.Temp);
                    int3[] gridDirs = { new int3(1, 0, 0), new int3(0, 1, 0), new int3(0, 0, 1) };
                    float3[] internalDirs = { math.right(), math.up(), math.forward() };
                    float3[] allDirs = { math.up(), math.down(), math.left(), math.right(), math.forward(), math.back() };

                    foreach (var key in keys)
                    {
                        Entity cur = gridMap[key]; float3 curPos = posMap[cur];
                        for (int d = 0; d < 3; d++) { if (gridMap.TryGetValue(key + gridDirs[d], out Entity neighbor)) CreateMaterialJoint(ref ecb, ref state, matNameMap, cur, neighbor, internalDirs[d] * 3.0f); }
                        
                        foreach (var anchorDir in allDirs) { 
                            RaycastInput ray = new RaycastInput { Start = curPos, End = curPos + anchorDir * 2.0f, Filter = CollisionFilter.Default }; 
                            if (physicsWorld.CastRay(ray, out Unity.Physics.RaycastHit hit)) { 
                                if (hit.Entity != Entity.Null && !posMap.ContainsKey(hit.Entity) && SystemAPI.HasComponent<BlockTag>(hit.Entity)) { 
                                    float3 hitPos = SystemAPI.GetComponent<LocalTransform>(hit.Entity).Position; 
                                    CreateMaterialJoint(ref ecb, ref state, matNameMap, hit.Entity, cur, curPos - hitPos); 
                                } 
                            } 
                        }
                    }
                    keys.Dispose();

                    if (isYMode)
                    {
                        var bpManager = UnityEngine.Object.FindFirstObjectByType<BlueprintManager>();
                        if (bpManager != null) bpManager.SaveBlueprint();

                        blueprintOffsets.Clear();
                        blueprintMaterials.Clear(); 
                        isYMode = false;
                        
                        // ⭐ 타설 완료 후 씬의 상태 갱신 + 마법 해제
                        backupIDToQuery = 1f; 
                        isAbsolutePositionMode = false;
                        UnityEngine.Debug.Log("🏗️ [타설 완료] 지점에 오차 없이 융합되었습니다!");
                    }
                    else
                    {
                        ExternalBlueprintData.Clear();
                        isOMode = false;
                        isLMode = false;
                        isUMode = false;
                    }

                    nextStructureID += 1f;
                    pendingJointCleanup = true;
                }
                gridMap.Dispose(); posMap.Dispose(); matNameMap.Dispose();
                return;
            }
        }

        if (Input.GetKeyDown(KeyCode.Y))
        {
            if (BudgetUIManager.Instance != null)
                BudgetUIManager.Instance.OnYKeyPressed();
        }

        if (loadDelayTimer > 0f)
        {
            loadDelayTimer -= 1f;
            if (loadDelayTimer <= 0f)
            {
                // 🚀 매니저가 명령한 파일(보강재 or 복구용 원본)만 딱 읽어옵니다.
                string readPath = Path.Combine(Application.dataPath, "StressBlock", targetLoadFile);
                
                if (File.Exists(readPath))
                {
                    string[] linesArray = File.ReadAllLines(readPath);
                    float minX = 99999f, minZ = 99999f, maxX = -99999f, maxZ = -99999f;

                    System.Collections.Generic.List<TempSpawnData> tempList = new System.Collections.Generic.List<TempSpawnData>();

                    for (int i = 1; i < linesArray.Length; i++)
                    {
                        string[] cols = linesArray[i].Split(',');

                        if (cols.Length >= 12)
                        {
                            string[] idParts = cols[0].Split('_');
                            if (idParts.Length >= 3)
                            {
                                float px = float.Parse(idParts[0]) / 10f;
                                float pz = float.Parse(idParts[1]) / 10f;
                                float py = float.Parse(idParts[2]) / 10f;
                                
                                float x = math.floor((px - 1.5f) / 3.0f + 0.5f) * 3.0f + 1.5f;
                                float z = math.floor((pz - 1.5f) / 3.0f + 0.5f) * 3.0f + 1.5f;
                                float y = math.floor((py - 1.5f) / 3.0f + 0.5f) * 3.0f + 1.5f;

                                float isReinforce = cols[10] == "Reinforcement" ? 1f : 0f;
                                string readMat = cols[7].Replace("\0", "").Trim();

                                tempList.Add(new TempSpawnData { Pos = new float3(x, y, z), IsReinforce = isReinforce, MatName = readMat });

                                if (x < minX) minX = x; if (x > maxX) maxX = x;
                                if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
                            }
                        }
                    }
                    
                    if (tempList.Count > 0)
                    {
                        isYMode = true;
                        blueprintOffsets.Clear();
                        blueprintMaterials.Clear();

                        tempList.Sort((a, b) => a.Pos.y.CompareTo(b.Pos.y));

                        float centerX = 0f; float centerZ = 0f;
                        
                        // ⭐ [마법 발동] 절대 좌표 모드가 아닐 때만 마우스 중심점(Centering)을 계산!
                        if (!isAbsolutePositionMode)
                        {
                            centerX = math.round(((minX + maxX) / 2f - 1.5f) / 3.0f) * 3.0f + 1.5f;
                            centerZ = math.round(((minZ + maxZ) / 2f - 1.5f) / 3.0f) * 3.0f + 1.5f;
                        }

                        customCenterPos = new float3(centerX, 0f, centerZ);
                        isCenterMoved = true;

                        foreach (var data in tempList)
                        {
                            blueprintOffsets.Add(new float4(data.Pos.x - centerX, data.Pos.y, data.Pos.z - centerZ, data.IsReinforce));
                            blueprintMaterials.Add(data.MatName);
                        }
                        UnityEngine.Debug.Log($"📦 [배달 완료] {targetLoadFile} 로드 완료! (F로 미리보기, G로 확정)");
                    }
                }
            }
        }

        if (isYMode && !isBMode)
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                for (int i = 0; i < blueprintOffsets.Length; i++)
                {
                    float4 offset = blueprintOffsets.ElementAt(i);
                    blueprintOffsets[i] = new float4(-offset.z, offset.y, offset.x, offset.w);
                }
            }
            if (Input.GetKeyDown(KeyCode.E))
            {
                for (int i = 0; i < blueprintOffsets.Length; i++)
                {
                    float4 offset = blueprintOffsets.ElementAt(i);
                    blueprintOffsets[i] = new float4(offset.z, offset.y, -offset.x, offset.w);
                }
            }
        }

        float3 defaultCenter = new float3((dragStartPos.x + dragEndPos.x) / 2f, 0f, (dragStartPos.z + dragEndPos.z) / 2f);
        float3 finalCenter = isCenterMoved ? new float3(customCenterPos.x, 0f, customCenterPos.z) : defaultCenter;
        float3 centerOffset = finalCenter - defaultCenter;
        float3 actualStartPos = dragStartPos + centerOffset; float3 actualEndPos = dragEndPos + centerOffset;
        float blockSize = 3.0f;

        actualStartPos.x = (float)System.Math.Round((actualStartPos.x - 1.5f) / blockSize) * blockSize + 1.5f;
        actualStartPos.z = (float)System.Math.Round((actualStartPos.z - 1.5f) / blockSize) * blockSize + 1.5f;
        float rawEndX = dragEndPos.x + centerOffset.x; float rawEndZ = dragEndPos.z + centerOffset.z;
        float diffX = rawEndX - actualStartPos.x; float diffZ = rawEndZ - actualStartPos.z;
        actualEndPos.x = actualStartPos.x + ((float)System.Math.Round(diffX / blockSize) * blockSize); actualEndPos.z = actualStartPos.z + ((float)System.Math.Round(diffZ / blockSize) * blockSize);

        finalCenter.x = (float)System.Math.Round((finalCenter.x - 1.5f) / blockSize) * blockSize + 1.5f;
        finalCenter.z = (float)System.Math.Round((finalCenter.z - 1.5f) / blockSize) * blockSize + 1.5f;

        isGuideActive = (math.lengthsq(actualStartPos) > 0.001f || math.lengthsq(actualEndPos) > 0.001f) && actualStartPos.x > -10000f;
        var aiBuilder = UnityEngine.Object.FindFirstObjectByType<AI_Builder>();
        if (aiBuilder != null && aiBuilder.isAiHologramActive) { isGuideActive = false; }

        if (isGuideActive)
        {
            float previewY = actualStartPos.y; Entity tempEntity = Entity.Null; bool tempHit = false;
            CheckRay(physicsWorld, finalCenter.x, finalCenter.z, blockSize, ref previewY, ref tempEntity, ref tempHit);
            float snappedHighestY = (float)System.Math.Round(previewY / blockSize) * blockSize;
            float3 drawStartPos = actualStartPos; float3 drawEndPos = actualEndPos;
            drawStartPos.y = math.max(actualStartPos.y, snappedHighestY); drawEndPos.y = math.max(actualEndPos.y, snappedHighestY);
            DrawGuideWireframe(drawStartPos, drawEndPos, guideHeight, currentBuildMode, blockSize);
        }

        if (isGuideActive && (isFKeyPressed || isGKeyPressed))
        {
            bool isGhost = isFKeyPressed;
            var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
            foreach (var (ghostTag, entity) in SystemAPI.Query<RefRO<GhostBlockTag>>().WithEntityAccess()) { ecb.DestroyEntity(entity); }

            float highestY = -9999f; Entity hitEntity = Entity.Null; bool hitAnything = false;
            float3 startXZ = new float3(actualStartPos.x, 0f, actualStartPos.z); float3 endXZ = new float3(actualEndPos.x, 0f, actualEndPos.z);
            float distance = math.distance(startXZ, endXZ); float halfSize = blockSize / 2f;

            if (math.abs(currentBuildMode - 1f) < 0.01f) { float3 mode1Start = startXZ + new float3(halfSize, 0f, halfSize); float3 mode1End = endXZ + new float3(halfSize, 0f, halfSize); float dist1 = math.distance(mode1Start, mode1End); float3 dir = dist1 < 0.1f ? new float3(1f, 0f, 0f) : math.normalize(mode1End - mode1Start); float steps = math.max(1f, math.round(dist1 / blockSize)); for (float i = 0f; i <= steps; i += 1f) { float3 p = mode1Start + dir * (i * (dist1 / math.max(1f, steps))); CheckRay(physicsWorld, p.x, p.z, blockSize, ref highestY, ref hitEntity, ref hitAnything); } }
            else if (math.abs(currentBuildMode - 2f) < 0.01f || math.abs(currentBuildMode - 4f) < 0.01f) { float minX = math.min(startXZ.x, endXZ.x); float maxX = math.max(startXZ.x, endXZ.x); float minZ = math.min(startXZ.z, endXZ.z); float maxZ = math.max(startXZ.z, endXZ.z); for (float x = minX; x <= maxX + 0.1f; x += blockSize) { for (float z = minZ; z <= maxZ + 0.1f; z += blockSize) { if (math.abs(currentBuildMode - 2f) < 0.01f) { if (x > minX + (blockSize * 0.5f) && x < maxX - (blockSize * 0.5f) && z > minZ + (blockSize * 0.5f) && z < maxZ - (blockSize * 0.5f)) continue; } CheckRay(physicsWorld, x + halfSize, z + halfSize, blockSize, ref highestY, ref hitEntity, ref hitAnything); } } }
            else if (math.abs(currentBuildMode - 3f) < 0.01f || math.abs(currentBuildMode - 5f) < 0.01f) { float radius = distance / 2.0f; float3 center = (startXZ + endXZ) / 2.0f; float baseRadiusCount = math.floor(radius / blockSize); for (float x = -baseRadiusCount; x <= baseRadiusCount; x += 1f) { for (float z = -baseRadiusCount; z <= baseRadiusCount; z += 1f) { if (math.sqrt(x * x + z * z) <= baseRadiusCount + 0.5f) { CheckRay(physicsWorld, center.x + (x * blockSize), center.z + (z * blockSize), blockSize, ref highestY, ref hitEntity, ref hitAnything); } } } }

            if (hitAnything)
            {
                float finalBuildY = math.round((math.max(highestY, actualStartPos.y) - 1.5f) / 3.0f) * 3.0f + 1.5f;
                if (LogManager.Instance != null) { string toolName = GetToolName(currentBuildMode); string centerStr = $"[{(actualStartPos.x + actualEndPos.x) / 2f:F1}, {finalBuildY:F1}, {(actualStartPos.z + actualEndPos.z) / 2f:F1}]"; LogManager.Instance.AddLog(toolName, (int)math.round(guideHeight), isGhost ? "Key_F" : "Key_G", isGhost ? "Preview" : "Build", centerStr, 0f, 0f); }
                ExecuteBuild(ref state, spawnerData, actualStartPos, actualEndPos, finalBuildY, hitEntity, isGhost);

                if (!isGhost)
                {
                    backupIDToQuery = 1f;
                    isGuideActive = false;
                    pendingJointCleanup = true;
                }
            }
        }
    }

    // ⭐ [증발 버그 수정] 원래 backupIDToQuery 예약 처리 안에 있던 로직을 그대로 뽑아낸 것.
    // BudgetUIManager 등 다른 MonoBehaviour에서, 씬의 BlockTag 엔티티를 파괴하기 "직전"에
    // 이 함수를 먼저 호출해서 마지막으로 지은 블록까지 확실히 Last_Building.csv에 반영되게 한다.
    // (예약만 걸어두고 -1f로 취소해버리면, 그 사이에 씬을 지워버리는 코드가 먼저 실행돼서
    //  방금 G로 지은 마지막 블록이 원본 장부에 한 번도 기록되지 못한 채 영원히 사라짐)
    public static void SaveLastBuildingSnapshot(EntityManager em)
    {
        StringBuilder originalOnlyCsv = new StringBuilder();
        originalOnlyCsv.AppendLine("BlockID,PosX,PosY,PosZ,Stress,RiskLevel,Prescription,Material,Tensile,Compressive,Tool,Type");
        bool found = false;

        var toolMap = new System.Collections.Generic.Dictionary<string, string>();
        // ⭐ 버그 수정: 이 매서드가 씬의 BlockMaterial 컴포넌트에서 재질을 그대로 가져와 버려서
        // ApplyMaterialsToScene()이 방금 CSV에 새로 계산해둔 재질(저렴/고급 모드)이 통째로 무시되고
        // 옛 재질로 덮어써지고 있었음. CSV에 이미 있는 블록은 그 재질을 그대로 쓰고,
        // CSV에 아직 없는 신규 블록(방금 G로 지은 것)만 씬 컴포넌트에서 재질을 가져온다.
        var matMap = new System.Collections.Generic.Dictionary<string, string>();
        string currentPath = Path.Combine(Application.dataPath, "StressBlock", "CurrentStress.csv");

        // 🚀 건물 전체에서 보강재가 하나라도 있는지 전수 조사! (신분 세탁 원천 차단)
        bool isBuildingReinforced = false;

        if (File.Exists(currentPath))
        {
            var oldLines = File.ReadAllLines(currentPath);
            for (int i = 1; i < oldLines.Length; i++)
            {
                var c = oldLines[i].Split(',');
                if (c.Length >= 12)
                {
                    toolMap[c[0]] = c[10];
                    matMap[c[0]] = c[7];
                    if (c[10] == "Reinforcement") isBuildingReinforced = true;
                }
            }
        }

        var query = em.CreateEntityQuery(ComponentType.ReadOnly<LocalTransform>(), ComponentType.ReadOnly<BlockMaterial>(), ComponentType.ReadOnly<BlockTag>());
        var transforms = query.ToComponentDataArray<LocalTransform>(Allocator.Temp);
        var mats = query.ToComponentDataArray<BlockMaterial>(Allocator.Temp);
        var entities = query.ToEntityArray(Allocator.Temp);

        for (int i = 0; i < transforms.Length; i++)
        {
            // ⭐ [구멍 버그 근본 수정] ID 계산은 반드시 "안 흔들리는" 좌표로 해야 함.
            //    CurrentStress.csv / Reinforcement_Plan.csv는 이미 StressVisualizationSystem의
            //    OriginalPosition(스폰 시 한 번만 캡처되는 고정 좌표)으로 ID를 계산하는데,
            //    여기(Last_Building.csv)만 실시간 LocalTransform.Position(스프링 조인트로 처질 수 있는 값)으로
            //    ID를 계산하고 있었음. 스폰 직후라 OriginalPosition이 아직 없는 블록만 LocalTransform으로 대체.
            float3 pos = em.HasComponent<OriginalPosition>(entities[i])
                ? em.GetComponentData<OriginalPosition>(entities[i]).Value
                : transforms[i].Position;
            float px = math.floor((pos.x - 1.5f) / 3.0f + 0.5f) * 3.0f + 1.5f;
            float py = math.floor((pos.y - 1.5f) / 3.0f + 0.5f) * 3.0f + 1.5f;
            float pz = math.floor((pos.z - 1.5f) / 3.0f + 0.5f) * 3.0f + 1.5f;

            string typeStr = py > 1.5f ? "Wall" : "Floor";

            float ix = math.round(px * 10f);
            float iy = math.round(py * 10f);
            float iz = math.round(pz * 10f);
            string strX = (ix < 0f ? "-" : "0") + math.abs(ix).ToString("000");
            string strZ = (iz < 0f ? "-" : "0") + math.abs(iz).ToString("000");
            string strY = (iy < 0f ? "-" : "0") + math.abs(iy).ToString("000");
            string realId = $"{strX}_{strZ}_{strY}";

            string toolTag = "Existing";
            if (isBuildingReinforced)
            {
                toolTag = toolMap.ContainsKey(realId) ? toolMap[realId] : "Existing";
            }

            string matName = matMap.ContainsKey(realId) ? matMap[realId] : mats[i].MaterialName.ToString().Replace("\0", "").Trim();

            string lineData = realId + "," +
                              px.ToString("F2") + "," +
                              py.ToString("F2") + "," +
                              pz.ToString("F2") + "," +
                              "0.00,Safe,N," + matName + ",0.0,0.0," + toolTag + "," + typeStr;

            found = true;
            if (toolTag != "Reinforcement") originalOnlyCsv.AppendLine(lineData);
        }

        transforms.Dispose();
        mats.Dispose();
        entities.Dispose();

        if (found)
        {
            string path = Path.Combine(Application.dataPath, "StressBlock", "Last_Building.csv");
            if (!Directory.Exists(Path.GetDirectoryName(path))) Directory.CreateDirectory(Path.GetDirectoryName(path));
            // 동기 쓰기: 호출자가 이 함수에서 리턴받는 즉시 디스크 반영이 끝나있음을 보장.
            File.WriteAllText(path, originalOnlyCsv.ToString());
        }
    }

    private void ExecuteBuild(ref SystemState state, SpawnerData data, float3 actualStart, float3 actualEnd, float targetY, Entity hitEntity, bool isGhost)
    {
        bool hitExistingBlock = SystemAPI.HasComponent<BlockTag>(hitEntity); float3 hitEntityPos = hitExistingBlock ? SystemAPI.GetComponent<LocalTransform>(hitEntity).Position : float3.zero;
        if (math.abs(currentBuildMode - 1f) < 0.01f) BuildSolidWall(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, (int)nextStructureID, isGhost);
        else if (math.abs(currentBuildMode - 2f) < 0.01f) BuildEmptyFrame(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, (int)nextStructureID, isGhost);
        else if (math.abs(currentBuildMode - 3f) < 0.01f) BuildCircularPattern(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, (int)nextStructureID, isGhost);
        else if (math.abs(currentBuildMode - 4f) < 0.01f) BuildPyramid(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, (int)nextStructureID, isGhost);
        else if (math.abs(currentBuildMode - 5f) < 0.01f) BuildCone(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, (int)nextStructureID, isGhost);
        if (!isGhost) nextStructureID += 1f;
    }

    private void CheckRay(PhysicsWorld physicsWorld, float x, float z, float blockSize, ref float highestY, ref Entity hitEntity, ref bool hitAnything)
    {
        float half = (blockSize / 2f) * 0.95f; float gridSize = 5f; float step = (half * 2f) / (gridSize - 1f);
        for (float i = 0f; i < gridSize; i += 1f) { for (float j = 0f; j < gridSize; j += 1f) { float px = (x - half) + (i * step); float pz = (z - half) + (j * step); float3 p = new float3(px, 100f, pz); RaycastInput rayInput = new RaycastInput { Start = p, End = p + new float3(0f, -200f, 0f), Filter = CollisionFilter.Default }; if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit)) { hitAnything = true; float snappedY = math.round((hit.Position.y - 1.5f) / 3.0f) * 3.0f + 1.5f; if (snappedY > highestY) { highestY = snappedY; hitEntity = hit.Entity; } } } }
    }

   private void DrawGuideWireframe(float3 start, float3 end, float heightParam, float mode, float blockSize)
    {
        Color color = Color.green; float floorHeight = blockSize;
        if (math.abs(mode - 1f) < 0.01f || math.abs(mode - 2f) < 0.01f) { 
            float minX = math.min(start.x, end.x); float maxX = math.max(start.x, end.x) + blockSize; float minZ = math.min(start.z, end.z); float maxZ = math.max(start.z, end.z) + blockSize; float minY = start.y; float maxY = start.y + (heightParam * floorHeight); 
            Vector3 p1 = new Vector3(minX, minY, minZ); Vector3 p2 = new Vector3(maxX, minY, minZ); Vector3 p3 = new Vector3(maxX, minY, maxZ); Vector3 p4 = new Vector3(minX, minY, maxZ); 
            
            // ⭐ Debug.DrawLine을 모두 GuideWireframeRenderer.DrawLine으로 변경
            GuideWireframeRenderer.DrawLine(p1, p2, color); GuideWireframeRenderer.DrawLine(p2, p3, color); GuideWireframeRenderer.DrawLine(p3, p4, color); GuideWireframeRenderer.DrawLine(p4, p1, color); 
            if (heightParam > 0f) { 
                Vector3 t1 = new Vector3(minX, maxY, minZ); Vector3 t2 = new Vector3(maxX, maxY, minZ); Vector3 t3 = new Vector3(maxX, maxY, maxZ); Vector3 t4 = new Vector3(minX, maxY, maxZ); 
                GuideWireframeRenderer.DrawLine(t1, t2, color); GuideWireframeRenderer.DrawLine(t2, t3, color); GuideWireframeRenderer.DrawLine(t3, t4, color); GuideWireframeRenderer.DrawLine(t4, t1, color); 
                GuideWireframeRenderer.DrawLine(p1, t1, color); GuideWireframeRenderer.DrawLine(p2, t2, color); GuideWireframeRenderer.DrawLine(p3, t3, color); GuideWireframeRenderer.DrawLine(p4, t4, color); 
            } 
        }
        else if (math.abs(mode - 3f) < 0.01f || math.abs(mode - 4f) < 0.01f || math.abs(mode - 5f) < 0.01f) { 
            float3 center = (start + end) / 2f; center.x += (blockSize / 2f); center.z += (blockSize / 2f); float radius = (math.distance(start, end) / 2f) + (blockSize / 2f); float minY = start.y; float maxY = start.y + (heightParam * floorHeight); float segments = 24f; float angleStep = (2f * math.PI) / segments; 
            Vector3 prev = center + new float3(radius, 0f, 0f); prev.y = minY; 
            for (float i = 1f; i <= segments; i += 1f) { 
                Vector3 next = center + new float3(math.cos(i * angleStep) * radius, 0f, math.sin(i * angleStep) * radius); next.y = minY; 
                GuideWireframeRenderer.DrawLine(prev, next, color); prev = next; 
            } 
            if (heightParam > 0f) GuideWireframeRenderer.DrawLine(new Vector3(center.x, minY, center.z), new Vector3(center.x, maxY, center.z), color); 
        }
    }

private void RemoveDuplicateJoints(ref SystemState state)
{
    var seenPairs = new NativeHashSet<int2>(50000, Allocator.Temp);
    var ecb = new EntityCommandBuffer(Allocator.Temp);

        foreach (var (pair, entity) in SystemAPI.Query<RefRO<PhysicsConstrainedBodyPair>>()
            .WithAll<JointTag>().WithEntityAccess())
        {
            int idA = pair.ValueRO.EntityA.Index;
            int idB = pair.ValueRO.EntityB.Index;

            int2 key = idA < idB ? new int2(idA, idB) : new int2(idB, idA);

            if (!seenPairs.Add(key))
            {
                ecb.DestroyEntity(entity);
            }
        }

        ecb.Playback(state.EntityManager);
        ecb.Dispose();
        seenPairs.Dispose();
    }
    private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity(); ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex()); ecb.AddComponent<JointTag>(jointEntity); ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true)); ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f)));
    }

    // ⭐ [재질별 스프링 조인트] 스폰 직후(아직 ecb 플레이백 전이라 실체 없는) 엔티티와
    //    이미 존재하는 실체 엔티티가 섞여서 들어올 수 있어, matNameMap(신규 스폰분) →
    //    state.EntityManager의 BlockMaterial(기존 실체분) 순서로 재질명을 찾는다.
    private void CreateMaterialJoint(ref EntityCommandBuffer ecb, ref SystemState state, NativeHashMap<Entity, FixedString32Bytes> matNameMap, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));

        var joint = PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f));

        GetSpringParams(ref state, matNameMap, entityA, out float freqA, out float dampA);
        GetSpringParams(ref state, matNameMap, entityB, out float freqB, out float dampB);
        float freq = (freqA + freqB) * 0.5f;
        float damp = (dampA + dampB) * 0.5f;

        var constraints = joint.GetConstraints();
        for (int i = 0; i < constraints.Length; i++)
        {
            var c = constraints[i];
            if (c.Type == ConstraintType.Linear)
            {
                c.SpringFrequency = freq;
                c.DampingRatio = damp;
            }
            constraints[i] = c;
        }
        joint.SetConstraints(constraints);

        ecb.AddComponent(jointEntity, joint);
    }

    // ⭐ 재질명 → 스프링값. MaterialPropertyInitSystem과 동일 공식(Bending/10 clamp, IsBrittle 기반 감쇠)을
    //    MaterialDataManager.MaterialDict에서 직접 조회해 재사용. (fallback: 강체에 가까운 값)
    private void GetSpringParams(ref SystemState state, NativeHashMap<Entity, FixedString32Bytes> matNameMap, Entity entity, out float freq, out float damp)
    {
        freq = 30f; damp = 0.3f;

        FixedString32Bytes matName = default;
        bool found = false;

        if (matNameMap.IsCreated && matNameMap.TryGetValue(entity, out FixedString32Bytes nameFromSpawn))
        {
            matName = nameFromSpawn; found = true;
        }
        else if (state.EntityManager.HasComponent<BlockMaterial>(entity))
        {
            var bm = state.EntityManager.GetComponentData<BlockMaterial>(entity);
            if (bm.SpringFrequency > 0f) { freq = bm.SpringFrequency; damp = bm.SpringDamping; return; }
            matName = bm.MaterialName; found = true;
        }

        if (found && MaterialDataManager.Instance != null && MaterialDataManager.Instance.MaterialDict.TryGetValue(matName.ToString(), out var spec))
        {
            freq = math.clamp(spec.Bending / 10f, 5f, 60f);
            damp = spec.IsBrittle ? 0.05f : 0.6f;
        }
    }
}
public static class GuideWireframeRenderer
{
    private static System.Collections.Generic.List<UnityEngine.LineRenderer> linePool = new System.Collections.Generic.List<UnityEngine.LineRenderer>();
    private static int activeLineCount = 0;
    private static UnityEngine.Material lineMat;

    public static void ResetPool()
    {
        activeLineCount = 0;
        for (int i = 0; i < linePool.Count; i++)
        {
            if (linePool[i] != null) linePool[i].gameObject.SetActive(false);
        }
    }

    public static void DrawLine(UnityEngine.Vector3 start, UnityEngine.Vector3 end, UnityEngine.Color color)
    {
        if (lineMat == null)
        {
            // ⭐ 유니티 빌드 코어에 박혀있어 절대 삭제되지 않는 내장 셰이더 사용
            UnityEngine.Shader hiddenShader = UnityEngine.Shader.Find("Hidden/Internal-Colored");
            if (hiddenShader != null)
            {
                lineMat = new UnityEngine.Material(hiddenShader);
                // ⭐ 벽이나 땅에 파묻혀도 무조건 보이게 투시(Always) 모드 적용
                lineMat.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Always);
            }
        }

        UnityEngine.LineRenderer lr;
        if (activeLineCount < linePool.Count)
        {
            lr = linePool[activeLineCount];
            if (lr == null)
            {
                linePool.RemoveAt(activeLineCount);
                DrawLine(start, end, color);
                return;
            }
        }
        else
        {
            UnityEngine.GameObject go = new UnityEngine.GameObject("GuideLine_" + activeLineCount);
            lr = go.AddComponent<UnityEngine.LineRenderer>();
            
            // 셰이더를 못 찾더라도 에러 뿜고 멈추는 일 없이, 핑크색 에러 선이라도 그리도록 방어!
            if (lineMat != null) lr.material = lineMat; 
            
            lr.startWidth = 0.08f;
            lr.endWidth = 0.08f;
            lr.positionCount = 2;
            lr.useWorldSpace = true;
            linePool.Add(lr);
        }

        lr.gameObject.SetActive(true);
        lr.SetPosition(0, start);
        lr.SetPosition(1, end);
        
        lr.startColor = color;
        lr.endColor = color;

        activeLineCount++;
    }
}