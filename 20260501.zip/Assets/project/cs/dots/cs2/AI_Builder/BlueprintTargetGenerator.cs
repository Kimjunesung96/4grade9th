﻿using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Unity.Mathematics;
#if UNITY_EDITOR
using UnityEditor;
#endif

public class BlueprintTargetGenerator : MonoBehaviour
{
    private List<float3> currentScannedData = new List<float3>();
    private Color32[] currentPixels;
    private float texWidth = 0f;
    private float texHeight = 0f;
    private bool hasValidImage = false;

    // ⭐ 건물의 층수를 기록하는 변수 추가
    private float currentFloorCount = 1f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.O))
        {
            OpenAndCacheImage();
            SpawnerSystem.isOMode = true;
            SpawnerSystem.isLMode = false;
        }

        if (Input.GetKeyDown(KeyCode.L))
        {
            SpawnerSystem.isLMode = true;
            SpawnerSystem.isOMode = false;
            Debug.Log("📂 [L 모드 활성화] 탐색기 없이 로컬 도면을 로드합니다. 숫자 1[High] 또는 2[Low]를 누르세요.");
        }

        if (SpawnerSystem.isLMode && !SpawnerSystem.isOMode)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1)) LoadDirect("House_Plan_High.csv", "1단계[High] 도면");
            if (Input.GetKeyDown(KeyCode.Alpha2)) LoadDirect("House_Plan_Low.csv", "2단계[Low] 도면");
        }

        if (SpawnerSystem.isOMode && hasValidImage)
        {
            HandleNumericLimitInput();

            float scroll = Input.mouseScrollDelta.y;

            // ⭐ 1. 휠 방향 인식 버그 수정 (부호에 따라 층수 조절)
            if (scroll > 0.01f)
            {
                currentFloorCount += 1f;
                ApplyOffsetAndLoad(currentScannedData);
                Debug.Log($"🏢 [휠 UP] 건물이 1층 추가되었습니다! 현재 총 [{currentFloorCount}층] 장전 완료.");
            }
            else if (scroll < -0.01f)
            {
                currentFloorCount = math.max(1f, currentFloorCount - 1f);
                ApplyOffsetAndLoad(currentScannedData);
                Debug.Log($"🏢 [휠 DOWN] 제일 윗층을 지웠습니다! 현재 총 [{currentFloorCount}층] 장전 완료.");
            }
        }
    }

    private void OpenAndCacheImage()
    {
#if UNITY_EDITOR
        string path = EditorUtility.OpenFilePanel("도면 이미지 선택", "", "png,jpg,jpeg");
        
        if (!string.IsNullOrEmpty(path))
        {
            byte[] bytes = File.ReadAllBytes(path);
            Texture2D tex = new Texture2D(2, 2);
            tex.LoadImage(bytes);
            
            currentPixels = tex.GetPixels32();
            texWidth = (float)tex.width;
            texHeight = (float)tex.height;
            hasValidImage = true;

            Destroy(tex);

            Debug.Log("🔍 컬러 마커 도면 장전 완료! 이제 숫자키[1~0]를 눌러 블록 리밋을 설정하세요. [1=1000개 ~ 0=10000개]");
        }
#else
        Debug.LogWarning("파일 다이얼로그는 에디터 전용입니다.");
#endif
    }

    private void HandleNumericLimitInput()
    {
        float targetLimit = -1f;

        if (Input.GetKeyDown(KeyCode.Alpha1)) targetLimit = 1000f;
        else if (Input.GetKeyDown(KeyCode.Alpha2)) targetLimit = 2000f;
        else if (Input.GetKeyDown(KeyCode.Alpha3)) targetLimit = 3000f;
        else if (Input.GetKeyDown(KeyCode.Alpha4)) targetLimit = 4000f;
        else if (Input.GetKeyDown(KeyCode.Alpha5)) targetLimit = 5000f;
        else if (Input.GetKeyDown(KeyCode.Alpha6)) targetLimit = 6000f;
        else if (Input.GetKeyDown(KeyCode.Alpha7)) targetLimit = 7000f;
        else if (Input.GetKeyDown(KeyCode.Alpha8)) targetLimit = 8000f;
        else if (Input.GetKeyDown(KeyCode.Alpha9)) targetLimit = 9000f;
        else if (Input.GetKeyDown(KeyCode.Alpha0)) targetLimit = 10000f;

        if (targetLimit > 0f)
        {
            Debug.Log($"⚙️ 목표 리밋 {targetLimit}개로 도면 렌더링 중...");
            var rawList = SearchUnderLimit(currentPixels, texWidth, texHeight, targetLimit);

            float dupCount = 0f;
            currentScannedData = RemoveDuplicates(rawList, out dupCount);

            // 숫자키를 누를 때마다 층수를 1층으로 초기화
            currentFloorCount = 1f;
            ApplyOffsetAndLoad(currentScannedData);

            Debug.Log($"✅ [타설 준비 완료] 실제 블록: {currentScannedData.Count}개 [리밋 {targetLimit}] 장전되었습니다. 우클릭 후 G를 누르세요.");
        }
    }

    private void ApplyOffsetAndLoad(List<float3> rawData)
    {
        List<float3> stackedData = new List<float3>();

        // ⭐ 2. 덮어쓰기 버그 수정: 층수(currentFloorCount) 만큼 반복해서 기존 배열에 복사본을 누적(Add) 시킵니다!
        for (float floor = 0f; floor < currentFloorCount; floor += 1f)
        {
            float floorYOffset = floor * 15.0f;

            foreach (var pos in rawData)
            {
                stackedData.Add(new float3(pos.x, pos.y + floorYOffset, pos.z));
            }
        }

        SpawnerSystem.ExternalBlueprintData = stackedData;
    }

    void LoadDirect(string fileName, string msg)
    {
        string path = Path.Combine(Application.dataPath, "StressBlock", fileName);
        if (File.Exists(path))
        {
            List<float3> tempList = new List<float3>();
            string[] lines = File.ReadAllLines(path);
            for (float i = 1f; i < (float)lines.Length; i += 1f)
            {
                string[] cols = lines[(int)i].Split(',');
                if (cols.Length >= 4f)
                {
                    float x = math.round(float.Parse(cols[1]) / 3.0f) * 3.0f;
                    float y = math.round((float.Parse(cols[2]) - 1.5f) / 3.0f) * 3.0f + 1.5f;
                    float z = math.round(float.Parse(cols[3]) / 3.0f) * 3.0f;

                    tempList.Add(new float3(x, y, z));
                }
            }

            SpawnerSystem.ExternalBlueprintData = tempList;
            Debug.Log($"✅ [로컬 로드] {msg} [{tempList.Count}개] 장전 완료!");
        }
        else
        {
            Debug.LogError($"❌ 파일을 찾을 수 없습니다: {path}");
        }
    }

    List<float3> RemoveDuplicates(List<float3> rawData, out float duplicateCount)
    {
        HashSet<string> uniqueCheck = new HashSet<string>();
        List<float3> cleanList = new List<float3>();
        duplicateCount = 0f;

        foreach (var pos in rawData)
        {
            float snapX = math.round(pos.x / 3.0f) * 3.0f;
            float snapY = math.round((pos.y - 1.5f) / 3.0f) * 3.0f + 1.5f;
            float snapZ = math.round(pos.z / 3.0f) * 3.0f;

            string id = $"{snapX}_{snapY}_{snapZ}";

            if (!uniqueCheck.Contains(id))
            {
                uniqueCheck.Add(id);
                cleanList.Add(new float3(snapX, snapY, snapZ));
            }
            else
            {
                duplicateCount += 1f;
            }
        }
        return cleanList;
    }

    List<float3> SearchUnderLimit(Color32[] pixels, float w, float h, float limit)
    {
        for (float size = 2f; size < 500f; size += 1f)
        {
            List<float3> res = Scan(pixels, w, h, size);
            if ((float)res.Count <= limit) return res;
        }
        return new List<float3>();
    }

    List<float3> Scan(Color32[] pixels, float w, float h, float size)
    {
        List<float3> list = new List<float3>();
        for (float x = 0f; x <= w - size; x += size)
        {
            for (float z = 0f; z <= h - size; z += size)
            {
                float redCount = 0f;
                float blueCount = 0f;
                float blackCount = 0f;

                for (float i = 0f; i < size; i += 1f)
                {
                    for (float j = 0f; j < size; j += 1f)
                    {
                        if (x + i < w && z + j < h)
                        {
                            Color32 p = pixels[(int)((z + j) * w + (x + i))];
                            if (p.a > 128f)
                            {
                                if (p.r > 150f && p.g < 100f && p.b < 100f) redCount += 1f;
                                else if (p.b > 150f && p.r < 100f && p.g < 150f) blueCount += 1f;
                                else if ((p.r + p.g + p.b) / 3f < 128f) blackCount += 1f;
                            }
                        }
                    }
                }

                float area = size * size;

                if (redCount / area >= 0.1f)
                {
                    for (float y = 0f; y < 5f; y += 1f) list.Add(new float3(((int)(x / size)) * 3f, y * 3f + 1.5f, ((int)(z / size)) * 3f));
                }
                else if (blueCount > 0f)
                {
                    list.Add(new float3(((int)(x / size)) * 3f, 1.5f, ((int)(z / size)) * 3f));
                }
                else if (blackCount / area >= 0.3f)
                {
                    for (float y = 0f; y < 5f; y += 1f) list.Add(new float3(((int)(x / size)) * 3f, y * 3f + 1.5f, ((int)(z / size)) * 3f));
                }
                else if (blackCount > 0f)
                {
                    list.Add(new float3(((int)(x / size)) * 3f, 1.5f, ((int)(z / size)) * 3f));
                }
            }
        }
        return list;
    }

    void SaveToCSV(List<float3> data, string fileName)
    {
        StringBuilder csv = new StringBuilder();
        csv.AppendLine("ID,X,Y,Z,Type");
        for (float i = 0f; i < (float)data.Count; i += 1f)
        {
            float3 p = data[(int)i];

            float x = math.round(p.x / 3.0f) * 3.0f;
            float y = math.round((p.y - 1.5f) / 3.0f) * 3.0f + 1.5f;
            float z = math.round(p.z / 3.0f) * 3.0f;

            string id = $"{x}_{y}_{z}";
            string type = y > 1.5f ? "Wall" : "Floor";
            csv.AppendLine($"{id},{x},{y},{z},{type}");
        }
        string path = Path.Combine(Application.dataPath, "StressBlock", fileName);
        if (!Directory.Exists(Path.GetDirectoryName(path)))
            Directory.CreateDirectory(Path.GetDirectoryName(path));

        File.WriteAllText(path, csv.ToString());
    }
}