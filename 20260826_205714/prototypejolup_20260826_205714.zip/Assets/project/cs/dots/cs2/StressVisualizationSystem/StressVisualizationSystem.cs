﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Rendering;
using UnityEngine;
using System.IO;
using System;
using Unity.Burst;
using Unity.Collections;
using System.Collections.Generic;
using System.Linq;

public struct OriginalPosition : IComponentData { public float3 Value; }
public struct OriginalMass : IComponentData { public float InverseMass; public float3 InverseInertia; }

[BurstCompile]
public partial struct ResetStressJob : IJobEntity
{
    public void Execute(ref BlockStress stress) { stress.TargetStress = 0.0f; }
}

[BurstCompile]
public partial struct ApplyExternalLoadJob : IJobEntity
{
    public bool IsWeightScanMode;
    public float BaseWeight;
    public float DynamicSensitivity;
    public float DeltaTime;
    public float QuakeX;
    public float QuakeZ;

    public void Execute(in PhysicsMass mass, ref BlockStress stress, ref PhysicsVelocity velRW)
    {
        float additionalStress = 0.0f;
        if (IsWeightScanMode)
        {
            float realMass = mass.InverseMass > 0.0f ? (1.0f / mass.InverseMass) : 1.0f;
            additionalStress = BaseWeight * realMass * 0.01f;
        }
        else
        {
            velRW.Linear += new float3(QuakeX, 0.0f, QuakeZ) * DeltaTime;
            additionalStress = math.lengthsq(velRW.Linear) * DynamicSensitivity;
        }
        stress.TargetStress += additionalStress;
    }
}

[BurstCompile]
public partial struct SmoothStressJob : IJobEntity
{
    public float DeltaTime;
    public float SmoothSpeed;
    public void Execute(ref BlockStress stress)
    {
        float currentSmoothed = math.lerp(stress.SmoothedStress, stress.TargetStress, DeltaTime * SmoothSpeed);
        stress.SmoothedStress = math.max(stress.SmoothedStress, currentSmoothed);
    }
}

[BurstCompile]
public partial struct TrackMaxDisplacementJob : IJobEntity
{
    public void Execute(in LocalTransform transform, in OriginalPosition origin, ref BlockDisplacement disp)
    {
        float dist = math.distance(transform.Position, origin.Value);
        if (dist > disp.MaxDist)
        {
            disp.MaxDist = dist;
            disp.MaxPos = transform.Position;
        }
    }
}

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct StressVisualizationSystem : ISystem
{
    private float scanTimer;
    private bool isScanning;
    private bool needsColorUpdate;
    private bool isWeightScanMode;
    private EntityQuery jointQuery;

    private float failureTickTimer;
    private const float FailureTickInterval = 1.0f;

    private static float TensionStressScale => SimulationSettingsProvider.Instance != null ? SimulationSettingsProvider.Instance.TensionStressScale : 5000.0f;

    private NativeList<FixedString512Bytes> destroyedLines;

    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<BlockStress>();
        jointQuery = state.GetEntityQuery(ComponentType.ReadOnly<PhysicsConstrainedBodyPair>(), ComponentType.ReadOnly<PhysicsJoint>());
        destroyedLines = new NativeList<FixedString512Bytes>(Allocator.Persistent);
    }

    public void OnDestroy(ref SystemState state)
    {
        if (destroyedLines.IsCreated) destroyedLines.Dispose();
    }

    public void OnUpdate(ref SystemState state)
    {
        if (Input.GetKeyDown(KeyCode.V)) { isWeightScanMode = true; StartScan(ref state); }

        if (isScanning)
        {
            scanTimer -= SystemAPI.Time.DeltaTime;
            if (scanTimer <= 0.0f) { isScanning = false; needsColorUpdate = true; StopPhysics(ref state); return; }

            state.Dependency = new ResetStressJob().ScheduleParallel(state.Dependency);

            float time = (float)SystemAPI.Time.ElapsedTime;
            state.Dependency = new ApplyExternalLoadJob
            {
                IsWeightScanMode = isWeightScanMode,
                BaseWeight = 1.0f,
                DynamicSensitivity = 0.5f,
                DeltaTime = SystemAPI.Time.DeltaTime,
                QuakeX = !isWeightScanMode ? math.sin(time * 35.0f) * 5.0f : 0.0f,
                QuakeZ = !isWeightScanMode ? math.cos(time * 28.0f) * 5.0f : 0.0f
            }.ScheduleParallel(state.Dependency);

            state.Dependency = new SmoothStressJob { DeltaTime = SystemAPI.Time.DeltaTime, SmoothSpeed = 3.0f }.ScheduleParallel(state.Dependency);
            state.Dependency = new TrackMaxDisplacementJob().ScheduleParallel(state.Dependency);

            failureTickTimer -= SystemAPI.Time.DeltaTime;
            if (failureTickTimer <= 0.0f)
            {
                failureTickTimer += FailureTickInterval;
                state.Dependency.Complete();
                ApplyFailureCheck(ref state);
            }
        }

        if (needsColorUpdate) { UpdateResults(ref state); needsColorUpdate = false; }
    }

    private void StartScan(ref SystemState state)
    {
        scanTimer = SimulationSettingsProvider.Instance != null ? SimulationSettingsProvider.Instance.gravityScanMaxTime : 5.0f;
        isScanning = true; needsColorUpdate = false;
        failureTickTimer = FailureTickInterval;
        destroyedLines.Clear();
        var ecb = new EntityCommandBuffer(Allocator.Temp);

        NativeList<Entity> allEntities = new NativeList<Entity>(Allocator.Temp);
        NativeList<float3> allPositions = new NativeList<float3>(Allocator.Temp);

        foreach (var (transform, entity) in SystemAPI.Query<RefRO<LocalTransform>>().WithAll<BlockTag>().WithEntityAccess())
        {
            allEntities.Add(entity);
            allPositions.Add(transform.ValueRO.Position);
        }

        NativeHashSet<Entity> badEntities = new NativeHashSet<Entity>(allEntities.Length, Allocator.Temp);
        int badCount = 0;

        NativeHashMap<int3, int> gridMap = new NativeHashMap<int3, int>(allEntities.Length, Allocator.Temp);
        for (int i = 0; i < allPositions.Length; i++)
        {
            int3 gridPos = new int3(
                (int)math.floor(allPositions[i].x / 3.0f + 0.5f),
                (int)math.floor(allPositions[i].y / 3.0f + 0.5f),
                (int)math.floor(allPositions[i].z / 3.0f + 0.5f));
            gridMap.TryAdd(gridPos, i);
        }

        NativeArray<int3> neighborOffsets = new NativeArray<int3>(6, Allocator.Temp);
        neighborOffsets[0] = new int3(1, 0, 0);
        neighborOffsets[1] = new int3(-1, 0, 0);
        neighborOffsets[2] = new int3(0, 1, 0);
        neighborOffsets[3] = new int3(0, -1, 0);
        neighborOffsets[4] = new int3(0, 0, 1);
        neighborOffsets[5] = new int3(0, 0, -1);

        // ⭐ [영구삭제 완전 제거] 파괴든 뭐든 블록이 영구적으로 사라지는 일은 절대 없어야 함.
        // 예전엔 시뮬레이션 중에만 이 "고립 파편 자동삭제" 진단을 건너뛰었는데, 평상시에도
        // 물리적으로 순간 흔들리며 이웃과 안 붙어있는 것처럼 오탐지될 수 있어 완전히 비활성화한다.
        {
        for (int i = 0; i < allEntities.Length; i++)
        {
            float3 myPos = allPositions[i];
            int3 myGrid = new int3(
                (int)math.floor(myPos.x / 3.0f + 0.5f),
                (int)math.floor(myPos.y / 3.0f + 0.5f),
                (int)math.floor(myPos.z / 3.0f + 0.5f));

            bool hasNeighbor = false;
            for (int n = 0; n < 6; n++)
            {
                if (gridMap.ContainsKey(myGrid + neighborOffsets[n]))
                {
                    hasNeighbor = true;
                    break;
                }
            }

            if (!hasNeighbor)
            {
                if (badEntities.Add(allEntities[i]))
                {
                    badCount++;
                    // ⭐ ecb.DestroyEntity(allEntities[i]); 는 더 이상 하지 않음 (영구삭제 완전 제거)
                }
            }
        }
        }

        gridMap.Dispose();
        neighborOffsets.Dispose();

        // ⭐ [조인트 파괴도 완전 제거 - 2026-08-15 수정]
        // badEntity 판정 자체가 floor() 격자 버킷팅의 부동소수점 오차 때문에 오탐이 잦았음
        // (회전/로드 직후 좌표가 1.5 기준 격자에 정확히 안 맞으면 특정 열 전체가 통째로
        //  "고립"으로 오판됨). 블록 삭제는 이미 막아놨었는데 조인트 삭제는 여기 그대로
        // 남아있어서, 오판된 열의 조인트가 끊기고 → 물리가 그 열을 통째로 날려버려
        // 건물이 세로 기둥 단위로 쪼개지고 사이에 빈 간격이 생기는 버그의 실제 원인이었음.
        // 블록 삭제와 동일하게 조인트 삭제도 완전히 비활성화한다.
        // (badCount는 로그로만 남기고 실제 조인트에는 손대지 않음)

        if (badCount > 0)
        {
            UnityEngine.Debug.LogWarning($"[안전 스캔] 진단: 고립처럼 보이는 블록 {badCount}개 감지 (더 이상 조인트를 끊지 않음)");
        }

        // (여기 있던 badEntities 기반 조인트 삭제 foreach 블록 완전히 제거함 - 오탐으로 인한
        //  기둥 분리 버그의 원인이었음)

        foreach (var (jointPair, joint, entity) in SystemAPI.Query<RefRO<PhysicsConstrainedBodyPair>, RefRO<PhysicsJoint>>().WithAll<JointTag>().WithEntityAccess())
        {
            if (SystemAPI.HasComponent<JointRestLength>(entity)) continue;

            Entity eA = jointPair.ValueRO.EntityA; Entity eB = jointPair.ValueRO.EntityB;
            if (badEntities.Contains(eA) || badEntities.Contains(eB)) continue;
            if (!SystemAPI.HasComponent<LocalTransform>(eA) || !SystemAPI.HasComponent<LocalTransform>(eB)) continue;

            var transA = SystemAPI.GetComponent<LocalTransform>(eA);
            var transB = SystemAPI.GetComponent<LocalTransform>(eB);
            float3 pivotA = math.transform(new RigidTransform(transA.Rotation, transA.Position), joint.ValueRO.BodyAFromJoint.Position);
            float3 pivotB = math.transform(new RigidTransform(transB.Rotation, transB.Position), joint.ValueRO.BodyBFromJoint.Position);
            float restDist = math.distance(pivotA, pivotB);

            ecb.AddComponent(entity, new JointRestLength { Value = restDist });
        }

        foreach (var (color, stress, transform, entity) in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>, RefRW<BlockStress>, RefRO<LocalTransform>>().WithAll<BlockTag>().WithEntityAccess())
        {
            if (badEntities.Contains(entity)) continue;

            color.ValueRW.Value = new float4(1.0f, 1.0f, 1.0f, 1.0f);
            stress.ValueRW.SmoothedStress = 0.0f; stress.ValueRW.TargetStress = 0.0f;
            stress.ValueRW.MaxTensileRatio = 0.0f;

            if (!SystemAPI.HasComponent<OriginalPosition>(entity))
            {
                // ⭐ [원본 손상 버그 수정] 조인트에 매달려 스캔 시작 시점에 이미 미세하게 처져 있으면
                //    그 처진 좌표가 그대로 박제되어, 이후 모든 ID 계산(SaveLastBuildingSnapshot,
                //    ReinforcementManager, MergeToAfterReinforce)이 전부 floor+0.5 격자 스냅을 쓰는데
                //    이 값만 안 스냅되어 있어서 경계에서 다른 격자 ID로 계산됨. 캡처 시점에 미리
                //    동일한 floor+0.5 공식으로 스냅해서, 살아있는 한 항상 같은 격자 ID를 가리키게 함.
                float3 rawPos = transform.ValueRO.Position;
                float3 snappedPos = GridUtility.Snap(rawPos);
                ecb.AddComponent(entity, new OriginalPosition { Value = snappedPos });
            }

            float3 originForDisp = SystemAPI.HasComponent<OriginalPosition>(entity)
                ? SystemAPI.GetComponent<OriginalPosition>(entity).Value
                : transform.ValueRO.Position;

            if (!SystemAPI.HasComponent<BlockDisplacement>(entity))
            {
                ecb.AddComponent(entity, new BlockDisplacement { MaxPos = originForDisp, MaxDist = 0.0f });
            }
            else
            {
                ecb.SetComponent(entity, new BlockDisplacement { MaxPos = originForDisp, MaxDist = 0.0f });
            }
        }

        foreach (var (gravity, velocity, mass, transform, entity) in SystemAPI.Query<RefRW<PhysicsGravityFactor>, RefRW<PhysicsVelocity>, RefRW<PhysicsMass>, RefRO<LocalTransform>>().WithAll<BlockTag>().WithEntityAccess())
        {
            if (badEntities.Contains(entity)) continue;

            if (!SystemAPI.HasComponent<OriginalMass>(entity))
            {
                ecb.AddComponent(entity, new OriginalMass { InverseMass = mass.ValueRO.InverseMass, InverseInertia = mass.ValueRO.InverseInertia });
            }

            if (transform.ValueRO.Position.y <= 3.1f)
            {
                mass.ValueRW.InverseMass = 0f;
                mass.ValueRW.InverseInertia = float3.zero;
            }
            else
            {
                mass.ValueRW.InverseMass = 0.1f;
                mass.ValueRW.InverseInertia = new float3(0.1f, 0.1f, 0.1f);
            }

            gravity.ValueRW.Value = 1.0f;
            velocity.ValueRW.Linear.y -= 0.01f;
        }

        ecb.Playback(state.EntityManager);
        ecb.Dispose();
        allEntities.Dispose();
        allPositions.Dispose();
        badEntities.Dispose();
    }

    private void StopPhysics(ref SystemState state)
    {
        foreach (var (transform, velocity, gravity, mass, originalPos, originalMass) in SystemAPI.Query<RefRW<LocalTransform>, RefRW<PhysicsVelocity>, RefRW<PhysicsGravityFactor>, RefRW<PhysicsMass>, RefRO<OriginalPosition>, RefRO<OriginalMass>>())
        {
            gravity.ValueRW.Value = 0.0f; velocity.ValueRW.Linear = float3.zero; velocity.ValueRW.Angular = float3.zero;
            transform.ValueRW.Position = originalPos.ValueRO.Value;
            transform.ValueRW.Rotation = quaternion.identity;

            // ⭐ [물리 폭발 완벽 방지] 복구 시 무조건 Kinematic(0)으로 묶어버려야 합니다!
            mass.ValueRW.InverseMass = 0.0f;
            mass.ValueRW.InverseInertia = float3.zero;
        }

        // ⭐ [물리 폭발 완벽 방지] 끊어졌던 조인트를 다시 복구해주어야 폭발하지 않습니다!
        RebuildAllJoints(ref state);
    }

private void RebuildAllJoints(ref SystemState state)
    {
        var destroyEcb = new EntityCommandBuffer(Allocator.Temp);
        foreach (var (pair, jointEntity) in SystemAPI.Query<RefRO<PhysicsConstrainedBodyPair>>().WithAll<JointTag>().WithEntityAccess())
        {
            destroyEcb.DestroyEntity(jointEntity);
        }
        destroyEcb.Playback(state.EntityManager);
        destroyEcb.Dispose();

        var gridMap = new NativeHashMap<int3, Entity>(4096, Allocator.Temp);
        var posMap = new NativeHashMap<Entity, float3>(4096, Allocator.Temp);

        foreach (var (transform, entity) in SystemAPI.Query<RefRO<LocalTransform>>().WithAll<BlockTag>().WithEntityAccess())
        {
            float3 pos = transform.ValueRO.Position;
            int3 key = new int3(
                (int)math.floor(pos.x / 3f + 0.5f),
                (int)math.floor(pos.y / 3f + 0.5f),
                (int)math.floor(pos.z / 3f + 0.5f));
            gridMap.TryAdd(key, entity);
            posMap.TryAdd(entity, pos);
        }

        var buildEcb = new EntityCommandBuffer(Allocator.Temp);
        var keys = gridMap.GetKeyArray(Allocator.Temp);

        int3[] localGridDirs = new int3[] { new int3(1, 0, 0), new int3(0, 0, 1), new int3(0, 1, 0) };
        float3[] localInternalDirs = new float3[] { new float3(1, 0, 0), new float3(0, 0, 1), new float3(0, 1, 0) };

        int newJointCount = 0;

        var matLookup = SystemAPI.GetComponentLookup<BlockMaterial>(true);

        for (int k = 0; k < keys.Length; k++)
        {
            int3 key = keys[k];
            Entity cur = gridMap[key];

            for (int d = 0; d < 3; d++)
            {
                if (gridMap.TryGetValue(key + localGridDirs[d], out Entity neighbor) && neighbor != cur)
                {
                    CreateMaterialJoint(ref buildEcb, ref matLookup, cur, neighbor, localInternalDirs[d] * 3.0f);
                    newJointCount++;
                }
            }
        }

        buildEcb.Playback(state.EntityManager);
        buildEcb.Dispose();
        keys.Dispose();
        gridMap.Dispose();
        posMap.Dispose();

        UnityEngine.Debug.Log($"🔧 [조인트 전면 재구성] 기존 조인트 삭제 후 인접 블록 {newJointCount}쌍 재결합 완료!");
    }

    private void CreateMaterialJoint(ref EntityCommandBuffer ecb, ref ComponentLookup<BlockMaterial> matLookup, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));

        var joint = PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f));

        float freq = 30f, damp = 0.3f;

        if (matLookup.HasComponent(entityA) && matLookup.HasComponent(entityB))
        {
            var matA = matLookup[entityA];
            var matB = matLookup[entityB];
            if (matA.SpringFrequency > 0f && matB.SpringFrequency > 0f)
            {
                freq = (matA.SpringFrequency + matB.SpringFrequency) * 0.5f;
                damp = (matA.SpringDamping + matB.SpringDamping) * 0.5f;
            }
        }

        var constraints = joint.GetConstraints();
        for (int i = 0; i < constraints.Length; i++)
        {
            var c = constraints[i];
            if (c.Type == ConstraintType.Linear)
            {
                c.SpringFrequency = freq;
                c.DampingRatio = damp;
            }
            constraints[i] = c;
        }
        joint.SetConstraints(constraints);

        ecb.AddComponent(jointEntity, joint);
    }  private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));
        ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f)));
    }

    // ⭐ [재질별 스프링 조인트] VibrationTestSystem.CreateMaterialJoint와 동일 패턴

    private void ApplyFailureCheck(ref SystemState state)
    {
        var ecb = new EntityCommandBuffer(Allocator.Temp);

        var transformLookup = SystemAPI.GetComponentLookup<LocalTransform>(true);
        var materialLookup = SystemAPI.GetComponentLookup<BlockMaterial>(true);
        var stressLookup = SystemAPI.GetComponentLookup<BlockStress>(false);

        // 🆕 [일시적 파괴 스위치] 물리를 풀어줄 때 쓸 RW 룩업
        // (OnUpdate에서 이 함수 호출 직전에 state.Dependency.Complete()를 이미 하므로 안전)
        var massLookup = SystemAPI.GetComponentLookup<PhysicsMass>(false);
        var gravityLookup = SystemAPI.GetComponentLookup<PhysicsGravityFactor>(false);

        foreach (var (jointPair, joint, rest, jointEntity) in SystemAPI.Query<
          RefRO<PhysicsConstrainedBodyPair>, RefRO<PhysicsJoint>, RefRO<JointRestLength>>().WithAll<JointTag>().WithEntityAccess())
        {
            Entity eA = jointPair.ValueRO.EntityA; Entity eB = jointPair.ValueRO.EntityB;

            if (!transformLookup.HasComponent(eA) || !transformLookup.HasComponent(eB)) continue;
            if (!materialLookup.HasComponent(eA) || !materialLookup.HasComponent(eB)) continue;

            var transA = transformLookup[eA];
            var transB = transformLookup[eB];
            float3 pivotA = math.transform(new RigidTransform(transA.Rotation, transA.Position), joint.ValueRO.BodyAFromJoint.Position);
            float3 pivotB = math.transform(new RigidTransform(transB.Rotation, transB.Position), joint.ValueRO.BodyBFromJoint.Position);
            float dist = math.distance(pivotA, pivotB);
            float stretch = math.max(0.0f, dist - rest.ValueRO.Value);

            if (stretch <= 0.0f) continue;

            var matA = materialLookup[eA];
            var matB = materialLookup[eB];
            float tensileStress = stretch * TensionStressScale;
            float tensileDefense = (matA.TensileStiffness + matB.TensileStiffness) * 0.5f;

            float ratio = tensileStress / math.max(1.0f, tensileDefense);

            if (stressLookup.HasComponent(eA))
            {
                var stressA = stressLookup[eA];
                stressA.MaxTensileRatio = math.max(stressA.MaxTensileRatio, ratio);
                stressLookup[eA] = stressA;
            }
            if (stressLookup.HasComponent(eB))
            {
                var stressB = stressLookup[eB];
                stressB.MaxTensileRatio = math.max(stressB.MaxTensileRatio, ratio);
                stressLookup[eB] = stressB;
            }

            // 🆕 [일시적 파괴] 인장 응력 초과 시 조인트를 끊고 물리를 풀어준다.
            // 스캔 시간(scanTimer) 끝나면 StopPhysics()가 위치 복구 + RebuildAllJoints()로
            // 자동으로 다시 이어붙이므로, 여기서 끊는 건 "영구 삭제"가 아니라 "일시적 파괴"다.
            if (ratio > 1.0f)
            {
                ecb.DestroyEntity(jointEntity);
                ReleaseBlockPhysics(eA, transA.Position, ref massLookup, ref gravityLookup);
                ReleaseBlockPhysics(eB, transB.Position, ref massLookup, ref gravityLookup);
            }
        }

        var toDestroy = new NativeList<Entity>(Allocator.Temp);
        // ⭐ [영구삭제는 여전히 금지] 압축파괴로 판정되어도 엔티티/조인트 자체는 지우지 않는다.
        // 대신 🆕 물리를 풀어줘서 실제로 주저앉는 모습이 보이게 하고, destroyedLines 로그도 남긴다.
        // 스캔 종료 시 StopPhysics()가 원위치로 복구한다.
        foreach (var (stress, mat, pos, entity) in SystemAPI.Query<
          RefRO<BlockStress>, RefRO<BlockMaterial>, RefRO<OriginalPosition>>().WithEntityAccess())
        {
            float compStress = stress.ValueRO.SmoothedStress;
            if (compStress <= mat.ValueRO.CompressiveStiffness) continue;

            float3 originPos = pos.ValueRO.Value;
            string id = GridUtility.ToBlockID(originPos);
            string mName = mat.ValueRO.MaterialName.ToString().Replace("\0", "").Trim();

            string destroyedLineStr = id + "|" +
                                      compStress.ToString("F2") + "|" +
                                      mName + "|" +
                                      mat.ValueRO.TensileStiffness.ToString("F1") + "|" +
                                      mat.ValueRO.CompressiveStiffness.ToString("F1") + "|" +
                                      originPos.y.ToString("F2");

            destroyedLines.Add(new FixedString512Bytes(destroyedLineStr));

            // 🆕 [일시적 파괴] 압축파괴 판정된 블록도 물리를 풀어 실제로 주저앉게 한다.
            ReleaseBlockPhysics(entity, originPos, ref massLookup, ref gravityLookup);
            // ⭐ toDestroy.Add(entity); 는 여전히 하지 않음 (영구삭제 완전 금지)
        }

        ecb.Playback(state.EntityManager);
        ecb.Dispose();
        toDestroy.Dispose();
    }

    // 🆕 [일시적 파괴 헬퍼] 지정한 블록의 중력/질량을 풀어서 실제로 낙하하게 만든다.
    // 바닥에 붙은 기초 블록(y<=3.1f)은 절대 풀어주지 않는다 (건물 전체가 붕 뜨는 것 방지).
    // 스캔이 끝나면 StopPhysics()가 위치를 되돌리고 다시 kinematic으로 고정한다.
    private void ReleaseBlockPhysics(Entity e, float3 pos, ref ComponentLookup<PhysicsMass> massLookup, ref ComponentLookup<PhysicsGravityFactor> gravityLookup)
    {
        if (pos.y <= 3.1f) return;

        if (gravityLookup.HasComponent(e))
        {
            var g = gravityLookup[e];
            g.Value = 1.0f;
            gravityLookup[e] = g;
        }

        if (massLookup.HasComponent(e))
        {
            var m = massLookup[e];
            m.InverseMass = 0.1f;
            m.InverseInertia = new float3(0.1f, 0.1f, 0.1f);
            massLookup[e] = m;
        }
    }

    private void UpdateResults(ref SystemState state)
    {
        state.Dependency.Complete();
        string path = Path.Combine(Application.dataPath, "StressBlock", "CurrentStress.csv");
        string reinforcePath = Path.Combine(Application.dataPath, "StressBlock", "Reinforcement_Plan.csv");
        string lastBuildPath = Path.Combine(Application.dataPath, "StressBlock", "Last_Building.csv");

        var toolMap = new Dictionary<string, string>();
        var typeMap = new Dictionary<string, string>();
        var matMap = new Dictionary<string, string>();
        var tensileMap = new Dictionary<string, string>();
        var compMap = new Dictionary<string, string>();

        if (File.Exists(path))
        {
            var oldLines = File.ReadAllLines(path).ToList();
            for (int i = 1; i < oldLines.Count; i++)
            {
                var c = oldLines.ElementAt(i).Split(',').ToList();
                if (c.Count >= 12)
                {
                    string k = c.ElementAt(0);
                    toolMap[k] = c.ElementAt(10);
                    typeMap[k] = c.ElementAt(11);
                    matMap[k] = c.ElementAt(7);
                    tensileMap[k] = c.ElementAt(8);
                    compMap[k] = c.ElementAt(9);
                }
            }
        }

        if (File.Exists(reinforcePath))
        {
            var rLines = File.ReadAllLines(reinforcePath).ToList();
            for (int i = 1; i < rLines.Count; i++)
            {
                var c = rLines.ElementAt(i).Split(',').ToList();
                if (c.Count >= 12)
                {
                    string k = c.ElementAt(0);
                    // ⭐ B키와 완벽 동일화: 이미 Reinforcement면 절대 안 뺏김!
                    if (toolMap.TryGetValue(k, out var existingTag) && existingTag == "Reinforcement" && c.ElementAt(10) != "Reinforcement") { }
                    else toolMap[k] = c.ElementAt(10);
                    typeMap[k] = c.ElementAt(11);
                    matMap[k] = c.ElementAt(7);
                    tensileMap[k] = c.ElementAt(8);
                    compMap[k] = c.ElementAt(9);
                }
            }
        }

        if (File.Exists(lastBuildPath))
        {
            var lLines = File.ReadAllLines(lastBuildPath).ToList();
            for (int i = 1; i < lLines.Count; i++)
            {
                var c = lLines.ElementAt(i).Split(',').ToList();
                if (c.Count >= 12)
                {
                    string k = c.ElementAt(0);
                    typeMap[k] = c.ElementAt(11);
                    // ⭐ B키와 완벽 동일화: 이미 Reinforcement면 절대 안 뺏김!
                    if (toolMap.TryGetValue(k, out var existingTag2) && existingTag2 == "Reinforcement" && c.ElementAt(10) != "Reinforcement") { }
                    else toolMap[k] = c.ElementAt(10);
                    matMap[k] = c.ElementAt(7);
                }
            }
        }

var bpManager = UnityEngine.Object.FindFirstObjectByType<BlueprintManager>();

// 🆕 [바닥/벽 2-pass 필터] CSV 쓰기 전, 현재 존재하는 블록 전체로 먼저 판정해둔다
var allBlocksForFloorCheck = new System.Collections.Generic.List<(float x, float y, float z, string id)>();
var existingBlocksForFloorCheck = new System.Collections.Generic.HashSet<string>();
foreach (var posQ in SystemAPI.Query<RefRO<OriginalPosition>>())
{
    float3 pQ = posQ.ValueRO.Value;
    string idQ = GridUtility.ToBlockID(pQ);
    allBlocksForFloorCheck.Add((pQ.x, pQ.y, pQ.z, idQ));
    existingBlocksForFloorCheck.Add(idQ);
}
var floorSet = GridUtility.ComputeFloorBlocks(allBlocksForFloorCheck, existingBlocksForFloorCheck);

System.Collections.Generic.List<string> linesToWrite = new System.Collections.Generic.List<string>();
linesToWrite.Add("BlockID,PosX,PosY,PosZ,Stress,RiskLevel,Prescription,Material,Tensile,Compressive,Tool,Type");
        foreach (var (stress, color, mat, pos, disp) in SystemAPI.Query<
          RefRO<BlockStress>,
          RefRW<URPMaterialPropertyBaseColor>,
          RefRO<BlockMaterial>,
          RefRO<OriginalPosition>,
          RefRO<BlockDisplacement>>())
        {
            float3 originPos = pos.ValueRO.Value;
            string id = GridUtility.ToBlockID(originPos);

            float3 p = disp.ValueRO.MaxDist > 0.0f ? disp.ValueRO.MaxPos : originPos;

            string mName = matMap.ContainsKey(id) ? matMap[id] : mat.ValueRO.MaterialName.ToString().Replace("\0", "").Trim();
            string tStr = tensileMap.ContainsKey(id) ? tensileMap[id] : mat.ValueRO.TensileStiffness.ToString("F1");
            string cStr = compMap.ContainsKey(id) ? compMap[id] : mat.ValueRO.CompressiveStiffness.ToString("F1");

            float tensile = 100f; float compressive = 100f;
            float.TryParse(tStr, out tensile);
            float.TryParse(cStr, out compressive);
            if (tensile <= 0.1f) tensile = mat.ValueRO.TensileStiffness;
            if (compressive <= 0.1f) compressive = mat.ValueRO.CompressiveStiffness;

            float curStress = stress.ValueRO.SmoothedStress;
            float compRatio = math.clamp(curStress / math.max(1.0f, compressive), 0.0f, 1.0f);
            float tensRatio = math.clamp(stress.ValueRO.MaxTensileRatio, 0.0f, 1.0f);
            float t = math.max(compRatio, tensRatio);
            float finalStressRecord = math.max(curStress, stress.ValueRO.MaxTensileRatio * tensile);

            float4 baseCol = new float4(0.7f, 0.7f, 0.7f, 1.0f);
            if (mName.Contains("Steel")) baseCol = new float4(0.2f, 0.5f, 1.0f, 1.0f);
            else if (mName.Contains("Wood") || mName.Contains("Timber")) baseCol = new float4(0.6f, 0.4f, 0.2f, 1.0f);
            else if (mName.Contains("Brick")) baseCol = new float4(0.8f, 0.3f, 0.2f, 1.0f);

            string risk = "Safe";
            string pres = "N";

            color.ValueRW.Value = math.lerp(baseCol, new float4(1.0f, 0.0f, 0.0f, 1.0f), t);

            if (t >= 0.99f) { risk = "Danger"; pres = "Y"; }
            else if (t >= 0.66f) { risk = "Danger"; pres = "Y"; }
            else if (t >= 0.33f) { risk = "Warning"; pres = "N"; }
            else { risk = "Safe"; pres = "N"; }

string tool = toolMap.ContainsKey(id) ? toolMap[id] : (bpManager != null ? bpManager.GetToolName(id) : "Existing");
string type = tool == "Reinforcement" ? "Reinforcement" : (floorSet.Contains(id) ? "Floor" : "Wall");

            string lineData = id + "," +
                              p.x.ToString("F2") + "," +
                              p.y.ToString("F2") + "," +
                              p.z.ToString("F2") + "," +
                              finalStressRecord.ToString("F2") + "," +
                              risk + "," +
                              pres + "," +
                              mName + "," +
                              tStr + "," +
                              cStr + "," +
                              tool + "," +
                              type;

            linesToWrite.Add(lineData);
        }

        foreach (var line in destroyedLines)
        {
            var parts = line.ToString().Split('|');
            if (parts.Length < 6) continue;

            string dId = parts[0];
            string dCompStress = parts[1];
            string dMatName = parts[2];
            string dTensile = parts[3];
            string dComp = parts[4];
            float dPosY = float.Parse(parts[5]);

string dTool = toolMap.ContainsKey(dId) ? toolMap[dId] : (bpManager != null ? bpManager.GetToolName(dId) : "Existing");
string dType = dTool == "Reinforcement" ? "Reinforcement" : (floorSet.Contains(dId) ? "Floor" : "Wall");

            string finalDestroyedLine = dId + ",DESTROYED,DESTROYED,DESTROYED," +
                                        dCompStress + ",Destroyed,Y," +
                                        dMatName + "," + dTensile + "," + dComp + "," +
                                        dTool + "," + dType;

            linesToWrite.Add(finalDestroyedLine);
        }

        string savePath = path;

        System.Threading.Tasks.Task.Run(() =>
        {
            File.WriteAllLines(savePath, linesToWrite);
        });

        needsColorUpdate = false;
    }
}