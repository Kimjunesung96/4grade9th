import os
import re
import ctypes
from ctypes import wintypes
from collections import defaultdict
import tkinter as tk
from tkinter import ttk, messagebox


# ============================================================
# Project Code Analyzer
# 프로젝트 최상단에 이 파일을 두고 실행하세요.
#
# 기능
# - 여러 코드 확장자 선택
# - 프로젝트 스캔
# - 파일명/경로 검색
# - 파일 내용 복사
# - 실제 파일 복사 (Windows 탐색기 Ctrl+V 가능)
# - 경로 복사
# - 참조 탐색
# - 참조 결과에서 내용 복사 / 실제 파일 복사 / 재탐색
#
# 주의:
# 참조 분석은 C# 컴파일러 수준의 완전한 의미 분석이 아니라
# 프로젝트 내 심볼 이름을 이용한 "참조 후보" 분석입니다.
# ============================================================


# ------------------------------------------------------------
# 프로젝트 위치
# ------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# ------------------------------------------------------------
# 무시할 폴더
# ------------------------------------------------------------

IGNORE_DIRS = {
    "Library",
    "Logs",
    "Packages",
    "ProjectSettings",
    "obj",
    "bin",
    ".git",
    ".vs",
    ".idea",
    "Temp",
    "UserSettings",
    "__pycache__",
    "node_modules",
    "Build",
    "Builds",
}


# ------------------------------------------------------------
# 지원 확장자
# ------------------------------------------------------------

FILE_TYPES = {
    ".cs": "C#",
    ".py": "Python",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".jsx": "React JSX",
    ".tsx": "React TSX",
    ".java": "Java",
    ".cpp": "C++",
    ".c": "C",
    ".h": "C/C++ Header",
    ".hpp": "C++ Header",
    ".kt": "Kotlin",
    ".go": "Go",
    ".rs": "Rust",
}


# ------------------------------------------------------------
# 전역 분석 데이터
# ------------------------------------------------------------

all_files = {}
name_index = defaultdict(set)

forward_graph = defaultdict(set)
reverse_graph = defaultdict(set)


# ============================================================
# 기본 유틸
# ============================================================

def normalize_path(path):
    return os.path.normpath(os.path.abspath(path))


def relative_path(path):
    try:
        return os.path.relpath(path, BASE_DIR)
    except ValueError:
        return path


def get_extension(path):
    return os.path.splitext(path)[1].lower()


def read_file(path):
    encodings = [
        "utf-8",
        "utf-8-sig",
        "cp949",
        "euc-kr",
        "latin-1",
    ]

    for encoding in encodings:
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except (UnicodeDecodeError, OSError):
            continue

    return ""


# ============================================================
# 심볼 추출
# ============================================================

def extract_symbols(content, path):
    """
    파일명 + 주요 선언 이름을 추출한다.

    이것은 완전한 AST/컴파일러 분석이 아니라
    참조 후보를 빠르게 찾기 위한 방식이다.
    """

    extension = get_extension(path)
    symbols = set()

    # 파일명 자체
    filename = os.path.splitext(os.path.basename(path))[0]

    if filename:
        symbols.add(filename)

    # --------------------------------------------------------
    # C#
    # --------------------------------------------------------

    if extension == ".cs":
        patterns = [
            r"\bclass\s+([A-Za-z_]\w*)",
            r"\bstruct\s+([A-Za-z_]\w*)",
            r"\binterface\s+([A-Za-z_]\w*)",
            r"\benum\s+([A-Za-z_]\w*)",
            r"\bdelegate\s+\w+\s+([A-Za-z_]\w*)",
        ]

        for pattern in patterns:
            symbols.update(re.findall(pattern, content))

    # --------------------------------------------------------
    # Python
    # --------------------------------------------------------

    elif extension == ".py":
        patterns = [
            r"\bclass\s+([A-Za-z_]\w*)",
            r"\bdef\s+([A-Za-z_]\w*)",
        ]

        for pattern in patterns:
            symbols.update(re.findall(pattern, content))

    # --------------------------------------------------------
    # Java / Kotlin
    # --------------------------------------------------------

    elif extension in {".java", ".kt"}:
        patterns = [
            r"\bclass\s+([A-Za-z_]\w*)",
            r"\binterface\s+([A-Za-z_]\w*)",
            r"\benum\s+([A-Za-z_]\w*)",
            r"\bobject\s+([A-Za-z_]\w*)",
        ]

        for pattern in patterns:
            symbols.update(re.findall(pattern, content))

    # --------------------------------------------------------
    # JS / TS
    # --------------------------------------------------------

    elif extension in {".js", ".ts", ".jsx", ".tsx"}:
        patterns = [
            r"\bclass\s+([A-Za-z_]\w*)",
            r"\bfunction\s+([A-Za-z_]\w*)",
            r"\b(?:const|let|var)\s+([A-Za-z_]\w*)",
        ]

        for pattern in patterns:
            symbols.update(re.findall(pattern, content))

    # --------------------------------------------------------
    # C / C++
    # --------------------------------------------------------

    elif extension in {".c", ".cpp", ".h", ".hpp"}:
        patterns = [
            r"\bclass\s+([A-Za-z_]\w*)",
            r"\bstruct\s+([A-Za-z_]\w*)",
            r"\benum\s+([A-Za-z_]\w*)",
        ]

        for pattern in patterns:
            symbols.update(re.findall(pattern, content))

    return symbols


# ============================================================
# 프로젝트 스캔
# ============================================================

def scan_project(selected_extensions, status_callback=None):
    global all_files
    global name_index
    global forward_graph
    global reverse_graph

    all_files = {}
    name_index = defaultdict(set)
    forward_graph = defaultdict(set)
    reverse_graph = defaultdict(set)

    # --------------------------------------------------------
    # 1. 파일 찾기
    # --------------------------------------------------------

    file_paths = []

    for root, dirs, files in os.walk(BASE_DIR):

        dirs[:] = [
            d for d in dirs
            if d not in IGNORE_DIRS
        ]

        for filename in files:

            extension = get_extension(filename)

            if extension not in selected_extensions:
                continue

            full_path = normalize_path(
                os.path.join(root, filename)
            )

            # 분석기 자기 자신은 제외
            if full_path == normalize_path(__file__):
                continue

            file_paths.append(full_path)

    file_paths.sort(
        key=lambda p: relative_path(p).lower()
    )

    total = len(file_paths)

    # --------------------------------------------------------
    # 2. 파일 읽기 + 심볼 추출
    # --------------------------------------------------------

    for index, path in enumerate(file_paths, start=1):

        if status_callback:
            status_callback(
                f"파일 분석 중... {index}/{total}\n"
                f"{relative_path(path)}"
            )

        content = read_file(path)

        symbols = extract_symbols(
            content,
            path
        )

        all_files[path] = {
            "name": os.path.basename(path),
            "path": path,
            "relative": relative_path(path),
            "extension": get_extension(path),
            "content": content,
            "symbols": symbols,
        }

        for symbol in symbols:
            name_index[symbol].add(path)

    # --------------------------------------------------------
    # 3. 참조 관계 분석
    # --------------------------------------------------------

    total_files = len(all_files)

    for index, (current_path, info) in enumerate(
        all_files.items(),
        start=1
    ):

        if status_callback:
            status_callback(
                f"참조 관계 분석 중... {index}/{total_files}\n"
                f"{info['relative']}"
            )

        content = info["content"]

        words = set(
            re.findall(
                r"\b[A-Za-z_]\w*\b",
                content
            )
        )

        for word in words:

            targets = name_index.get(word)

            if not targets:
                continue

            for target_path in targets:

                if target_path == current_path:
                    continue

                forward_graph[current_path].add(
                    target_path
                )

                reverse_graph[target_path].add(
                    current_path
                )

    if status_callback:
        status_callback(
            f"스캔 완료\n"
            f"총 {len(all_files)}개 파일"
        )


# ============================================================
# Windows 실제 파일 클립보드 복사
# ============================================================

CF_HDROP = 15
GMEM_MOVEABLE = 0x0002
GMEM_ZEROINIT = 0x0040


class DROPFILES(ctypes.Structure):
    _fields_ = [
        ("pFiles", wintypes.DWORD),
        ("pt", wintypes.POINT),
        ("fNC", wintypes.BOOL),
        ("fWide", wintypes.BOOL),
    ]


def copy_file_to_windows_clipboard(path):
    """
    Windows 파일 클립보드에 실제 파일을 넣는다.

    이후 탐색기에서 Ctrl+V를 하면
    해당 파일을 실제로 복사할 수 있다.
    """

    if os.name != "nt":
        raise RuntimeError(
            "실제 파일 클립보드 복사는 Windows에서만 지원됩니다."
        )

    path = os.path.abspath(path)

    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    file_list = path + "\0\0"
    data = file_list.encode("utf-16-le")

    dropfiles_size = ctypes.sizeof(DROPFILES)
    total_size = dropfiles_size + len(data)

    kernel32 = ctypes.windll.kernel32
    user32 = ctypes.windll.user32

    kernel32.GlobalAlloc.argtypes = [
        wintypes.UINT,
        ctypes.c_size_t
    ]
    kernel32.GlobalAlloc.restype = wintypes.HGLOBAL

    kernel32.GlobalLock.argtypes = [
        wintypes.HGLOBAL
    ]
    kernel32.GlobalLock.restype = wintypes.LPVOID

    kernel32.GlobalUnlock.argtypes = [
        wintypes.HGLOBAL
    ]
    kernel32.GlobalUnlock.restype = wintypes.BOOL

    kernel32.GlobalFree.argtypes = [
        wintypes.HGLOBAL
    ]
    kernel32.GlobalFree.restype = wintypes.HGLOBAL

    h_global = kernel32.GlobalAlloc(
        GMEM_MOVEABLE | GMEM_ZEROINIT,
        total_size
    )

    if not h_global:
        raise MemoryError("GlobalAlloc 실패")

    try:
        locked = kernel32.GlobalLock(h_global)

        if not locked:
            raise MemoryError("GlobalLock 실패")

        try:
            dropfiles = DROPFILES.from_buffer_copy(
                bytes(dropfiles_size)
            )

            dropfiles.pFiles = dropfiles_size
            dropfiles.pt.x = 0
            dropfiles.pt.y = 0
            dropfiles.fNC = 0
            dropfiles.fWide = 1

            ctypes.memmove(
                locked,
                ctypes.byref(dropfiles),
                dropfiles_size
            )

            ctypes.memmove(
                locked + dropfiles_size,
                data,
                len(data)
            )

        finally:
            kernel32.GlobalUnlock(h_global)

        if not user32.OpenClipboard(None):
            raise RuntimeError("Windows 클립보드를 열 수 없습니다.")

        try:
            if not user32.EmptyClipboard():
                raise RuntimeError("클립보드를 비울 수 없습니다.")

            if not user32.SetClipboardData(
                CF_HDROP,
                h_global
            ):
                raise RuntimeError(
                    "파일 클립보드 설정에 실패했습니다."
                )

            # SetClipboardData가 성공하면 Windows가 메모리 소유권을 가져간다.
            h_global = None

        finally:
            user32.CloseClipboard()

    finally:
        if h_global:
            kernel32.GlobalFree(h_global)


# ============================================================
# GUI
# ============================================================

class ProjectAnalyzerApp:

    def __init__(self, root):

        self.root = root

        self.root.title(
            "Project Code Analyzer"
        )

        self.root.geometry(
            "1250x760"
        )

        self.root.minsize(
            1000,
            600
        )

        self.extension_vars = {}

        self.filtered_files = []

        self.build_ui()

    # --------------------------------------------------------
    # 메인 UI
    # --------------------------------------------------------

    def build_ui(self):

        # ====================================================
        # 제목
        # ====================================================

        top = ttk.Frame(
            self.root,
            padding=10
        )

        top.pack(
            fill="x"
        )

        ttk.Label(
            top,
            text="Project Code Analyzer",
            font=("Arial", 18, "bold")
        ).pack(
            anchor="w"
        )

        ttk.Label(
            top,
            text=f"프로젝트 위치: {BASE_DIR}"
        ).pack(
            anchor="w",
            pady=(4, 8)
        )

        # ====================================================
        # 확장자
        # ====================================================

        type_frame = ttk.LabelFrame(
            self.root,
            text="분석할 파일 종류",
            padding=8
        )

        type_frame.pack(
            fill="x",
            padx=10,
            pady=4
        )

        row = 0
        column = 0

        for extension, description in FILE_TYPES.items():

            var = tk.BooleanVar(
                value=(extension == ".cs")
            )

            self.extension_vars[extension] = var

            ttk.Checkbutton(
                type_frame,
                text=f"{extension} ({description})",
                variable=var
            ).grid(
                row=row,
                column=column,
                sticky="w",
                padx=7,
                pady=2
            )

            column += 1

            if column >= 5:
                column = 0
                row += 1

        # ====================================================
        # 스캔 + 검색
        # ====================================================

        control_frame = ttk.Frame(
            self.root,
            padding=(10, 4)
        )

        control_frame.pack(
            fill="x"
        )

        ttk.Button(
            control_frame,
            text="프로젝트 스캔",
            command=self.start_scan
        ).pack(
            side="left"
        )

        ttk.Label(
            control_frame,
            text="검색:"
        ).pack(
            side="left",
            padx=(20, 5)
        )

        self.search_var = tk.StringVar()

        ttk.Entry(
            control_frame,
            textvariable=self.search_var
        ).pack(
            side="left",
            fill="x",
            expand=True
        )

        self.search_var.trace_add(
            "write",
            lambda *args: self.refresh_file_list()
        )

        # ====================================================
        # 파일 목록
        # ====================================================

        self.list_container = ttk.Frame(
            self.root,
            padding=(10, 4, 10, 10)
        )

        self.list_container.pack(
            fill="both",
            expand=True
        )

        # Canvas + Scrollbar
        self.canvas = tk.Canvas(
            self.list_container,
            highlightthickness=0
        )

        self.scrollbar = ttk.Scrollbar(
            self.list_container,
            orient="vertical",
            command=self.canvas.yview
        )

        self.file_rows_frame = ttk.Frame(
            self.canvas
        )

        self.file_rows_frame.bind(
            "<Configure>",
            lambda event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas_window = self.canvas.create_window(
            (0, 0),
            window=self.file_rows_frame,
            anchor="nw"
        )

        self.canvas.configure(
            yscrollcommand=self.scrollbar.set
        )

        self.canvas.pack(
            side="left",
            fill="both",
            expand=True
        )

        self.scrollbar.pack(
            side="right",
            fill="y"
        )

        self.canvas.bind(
            "<Configure>",
            self.resize_rows
        )

        self.canvas.bind_all(
            "<MouseWheel>",
            self.on_mousewheel
        )

        # ====================================================
        # 상태
        # ====================================================

        self.status_var = tk.StringVar(
            value="프로젝트를 스캔해주세요."
        )

        ttk.Label(
            self.root,
            textvariable=self.status_var,
            relief="sunken",
            anchor="w",
            padding=5
        ).pack(
            fill="x",
            side="bottom"
        )

    # --------------------------------------------------------
    # 행 크기
    # --------------------------------------------------------

    def resize_rows(self, event):
        try:
            self.canvas.itemconfigure(
                self.canvas_window,
                width=event.width
            )
        except Exception:
            pass

    # --------------------------------------------------------
    # 마우스 휠
    # --------------------------------------------------------

    def on_mousewheel(self, event):
        try:
            self.canvas.yview_scroll(
                int(-1 * (event.delta / 120)),
                "units"
            )
        except Exception:
            pass

    # --------------------------------------------------------
    # 스캔
    # --------------------------------------------------------

    def start_scan(self):

        selected = {
            extension
            for extension, var
            in self.extension_vars.items()
            if var.get()
        }

        if not selected:
            messagebox.showwarning(
                "파일 종류 선택",
                "최소 하나의 파일 종류를 선택해주세요."
            )
            return

        self.status_var.set(
            "스캔 시작..."
        )

        self.root.update_idletasks()

        try:
            scan_project(
                selected,
                self.update_status
            )

            self.refresh_file_list()

            messagebox.showinfo(
                "스캔 완료",
                f"{len(all_files)}개의 파일을 분석했습니다."
            )

        except Exception as e:
            messagebox.showerror(
                "스캔 오류",
                str(e)
            )

    def update_status(self, text):

        self.status_var.set(
            text
        )

        self.root.update_idletasks()

    # --------------------------------------------------------
    # 파일 목록 갱신
    # --------------------------------------------------------

    def refresh_file_list(self):

        for widget in self.file_rows_frame.winfo_children():
            widget.destroy()

        search = (
            self.search_var
            .get()
            .strip()
            .lower()
        )

        self.filtered_files = []

        for path, info in all_files.items():

            if search:

                if (
                    search not in info["name"].lower()
                    and search not in info["relative"].lower()
                ):
                    continue

            self.filtered_files.append(path)

        self.filtered_files.sort(
            key=lambda p: all_files[p]["relative"].lower()
        )

        self.create_header_row()

        for path in self.filtered_files:
            self.create_file_row(path)

        self.status_var.set(
            f"{len(self.filtered_files)}개 파일 표시 / "
            f"전체 {len(all_files)}개"
        )

    # --------------------------------------------------------
    # 헤더
    # --------------------------------------------------------

    def create_header_row(self):

        frame = tk.Frame(
            self.file_rows_frame,
            bd=1,
            relief="solid"
        )

        frame.pack(
            fill="x"
        )

        frame.grid_columnconfigure(
            0,
            weight=0,
            minsize=270
        )

        frame.grid_columnconfigure(
            1,
            weight=0,
            minsize=80
        )

        frame.grid_columnconfigure(
            2,
            weight=1
        )

        frame.grid_columnconfigure(
            3,
            weight=0,
            minsize=40
        )

        frame.grid_columnconfigure(
            4,
            weight=0,
            minsize=40
        )

        frame.grid_columnconfigure(
            5,
            weight=0,
            minsize=40
        )

        frame.grid_columnconfigure(
            6,
            weight=0,
            minsize=40
        )

        self.make_cell(
            frame,
            "파일명",
            0,
            bold=True
        )

        self.make_cell(
            frame,
            "종류",
            1,
            bold=True
        )

        self.make_cell(
            frame,
            "경로",
            2,
            bold=True
        )

        self.make_cell(
            frame,
            "📄",
            3,
            bold=True
        )

        self.make_cell(
            frame,
            "📋",
            4,
            bold=True
        )

        self.make_cell(
            frame,
            "📁",
            5,
            bold=True
        )

        self.make_cell(
            frame,
            "🔎",
            6,
            bold=True
        )

    # --------------------------------------------------------
    # 파일 행
    # --------------------------------------------------------

    def create_file_row(self, path):

        info = all_files[path]

        frame = tk.Frame(
            self.file_rows_frame,
            bd=1,
            relief="solid"
        )

        frame.pack(
            fill="x"
        )

        frame.grid_columnconfigure(
            0,
            weight=0,
            minsize=270
        )

        frame.grid_columnconfigure(
            1,
            weight=0,
            minsize=80
        )

        frame.grid_columnconfigure(
            2,
            weight=1
        )

        for column in range(3, 7):
            frame.grid_columnconfigure(
                column,
                weight=0,
                minsize=40
            )

        self.make_cell(
            frame,
            info["name"],
            0
        )

        self.make_cell(
            frame,
            info["extension"],
            1
        )

        self.make_cell(
            frame,
            info["relative"],
            2
        )

        # 파일 내용 복사
        ttk.Button(
            frame,
            text="📄",
            width=3,
            command=lambda p=path:
                self.copy_content(p)
        ).grid(
            row=0,
            column=3,
            padx=2,
            pady=2
        )

        # 실제 파일 복사
        ttk.Button(
            frame,
            text="📋",
            width=3,
            command=lambda p=path:
                self.copy_real_file(p)
        ).grid(
            row=0,
            column=4,
            padx=2,
            pady=2
        )

        # 경로 복사
        ttk.Button(
            frame,
            text="📁",
            width=3,
            command=lambda p=path:
                self.copy_path(p)
        ).grid(
            row=0,
            column=5,
            padx=2,
            pady=2
        )

        # 참조 탐색
        ttk.Button(
            frame,
            text="🔎",
            width=3,
            command=lambda p=path:
                self.show_references(p)
        ).grid(
            row=0,
            column=6,
            padx=2,
            pady=2
        )

    # --------------------------------------------------------
    # 셀
    # --------------------------------------------------------

    def make_cell(
        self,
        parent,
        text,
        column,
        bold=False
    ):

        font = (
            "Arial",
            9,
            "bold"
        ) if bold else (
            "Arial",
            9
        )

        label = tk.Label(
            parent,
            text=text,
            font=font,
            anchor="w",
            padx=6,
            pady=5
        )

        label.grid(
            row=0,
            column=column,
            sticky="ew"
        )

        return label

    # ========================================================
    # 복사 기능
    # ========================================================

    def copy_content(self, path):

        content = all_files[path]["content"]

        self.root.clipboard_clear()
        self.root.clipboard_append(
            content
        )
        self.root.update()

        self.status_var.set(
            f"파일 내용 복사 완료: "
            f"{all_files[path]['name']}"
        )

    def copy_real_file(self, path):

        try:
            copy_file_to_windows_clipboard(
                path
            )

            self.status_var.set(
                f"파일 복사 준비 완료: "
                f"{all_files[path]['name']} "
                f"(탐색기에서 Ctrl+V)"
            )

        except Exception as e:

            messagebox.showerror(
                "파일 복사 오류",
                str(e)
            )

    def copy_path(self, path):

        self.root.clipboard_clear()
        self.root.clipboard_append(
            path
        )
        self.root.update()

        self.status_var.set(
            f"경로 복사 완료: {path}"
        )

    # ========================================================
    # 참조 탐색
    # ========================================================

    def show_references(self, path):

        if path not in all_files:
            return

        info = all_files[path]

        window = tk.Toplevel(
            self.root
        )

        window.title(
            f"참조 탐색 - {info['name']}"
        )

        window.geometry(
            "1050x700"
        )

        window.minsize(
            850,
            500
        )

        # ----------------------------------------------------
        # 상단
        # ----------------------------------------------------

        top = ttk.Frame(
            window,
            padding=10
        )

        top.pack(
            fill="x"
        )

        ttk.Label(
            top,
            text=info["name"],
            font=("Arial", 16, "bold")
        ).pack(
            anchor="w"
        )

        ttk.Label(
            top,
            text=info["relative"]
        ).pack(
            anchor="w",
            pady=(3, 0)
        )

        # ----------------------------------------------------
        # 참조하는 파일
        # ----------------------------------------------------

        self.build_reference_section(
            window,
            "⬇ 이 코드가 참조하는 파일",
            forward_graph.get(path, set())
        )

        # ----------------------------------------------------
        # 참조받는 파일
        # ----------------------------------------------------

        self.build_reference_section(
            window,
            "⬆ 이 코드를 참조하는 파일",
            reverse_graph.get(path, set())
        )

    # --------------------------------------------------------
    # 참조 결과 섹션
    # --------------------------------------------------------

    def build_reference_section(
        self,
        parent,
        title,
        paths
    ):

        frame = ttk.LabelFrame(
            parent,
            text=title,
            padding=8
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5
        )

        paths = [
            path
            for path in paths
            if path in all_files
        ]

        paths.sort(
            key=lambda p:
                all_files[p]["relative"].lower()
        )

        if not paths:

            ttk.Label(
                frame,
                text="참조 관계가 없습니다."
            ).pack(
                anchor="w",
                padx=5,
                pady=5
            )

            return

        canvas = tk.Canvas(
            frame,
            highlightthickness=0
        )

        scrollbar = ttk.Scrollbar(
            frame,
            orient="vertical",
            command=canvas.yview
        )

        inner = ttk.Frame(
            canvas
        )

        inner.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )

        canvas_window = canvas.create_window(
            (0, 0),
            window=inner,
            anchor="nw"
        )

        canvas.configure(
            yscrollcommand=scrollbar.set
        )

        canvas.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

        def resize_inner(event):
            canvas.itemconfigure(
                canvas_window,
                width=event.width
            )

        canvas.bind(
            "<Configure>",
            resize_inner
        )

        for target in paths:

            self.create_reference_row(
                inner,
                target
            )

    # --------------------------------------------------------
    # 참조 결과 한 줄
    # --------------------------------------------------------

    def create_reference_row(
        self,
        parent,
        path
    ):

        info = all_files[path]

        frame = tk.Frame(
            parent,
            bd=1,
            relief="solid"
        )

        frame.pack(
            fill="x"
        )

        frame.grid_columnconfigure(
            0,
            weight=0,
            minsize=270
        )

        frame.grid_columnconfigure(
            1,
            weight=1
        )

        frame.grid_columnconfigure(
            2,
            weight=0,
            minsize=40
        )

        frame.grid_columnconfigure(
            3,
            weight=0,
            minsize=40
        )

        frame.grid_columnconfigure(
            4,
            weight=0,
            minsize=40
        )

        self.make_cell(
            frame,
            info["name"],
            0
        )

        self.make_cell(
            frame,
            info["relative"],
            1
        )

        # 파일 내용 복사
        ttk.Button(
            frame,
            text="📄",
            width=3,
            command=lambda p=path:
                self.copy_content(p)
        ).grid(
            row=0,
            column=2,
            padx=2,
            pady=2
        )

        # 실제 파일 복사
        ttk.Button(
            frame,
            text="📋",
            width=3,
            command=lambda p=path:
                self.copy_real_file(p)
        ).grid(
            row=0,
            column=3,
            padx=2,
            pady=2
        )

        # 다시 참조 탐색
        ttk.Button(
            frame,
            text="🔎",
            width=3,
            command=lambda p=path:
                self.show_references(p)
        ).grid(
            row=0,
            column=4,
            padx=2,
            pady=2
        )


# ============================================================
# 실행
# ============================================================

def main():

    root = tk.Tk()

    try:
        root.tk.call(
            "tk",
            "scaling",
            1.2
        )
    except Exception:
        pass

    ProjectAnalyzerApp(root)

    root.mainloop()


if __name__ == "__main__":
    main()
