import os
import re
from collections import defaultdict

# 탐색할 최상위 경로
BASE_DIR = '.'
# 유니티에서 스캔할 필요가 없는 무거운 기본 폴더들 제외
IGNORE_DIRS = {'Library', 'Logs', 'Packages', 'obj', 'Temp', 'Build', '.git'}

forward_graph = defaultdict(set)
reverse_graph = defaultdict(set)

def scan_unity_project():
    print("🔍 Unity(C#) 프로젝트 코드를 스캔하여 관계 지도를 그리는 중입니다...\n")
    
    all_files = []
    file_contents = {}
    class_names = {}

    # 1. 모든 .cs 파일 찾기
    for root, dirs, files in os.walk(BASE_DIR):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for file in files:
            if file.endswith('.cs'):
                filepath = os.path.normpath(os.path.join(root, file))
                all_files.append(filepath)
                # 파일 이름(확장자 제외)을 클래스 이름으로 간주
                class_name = file[:-3]
                class_names[class_name] = filepath

    print(f"📂 총 {len(all_files)}개의 .cs 파일을 찾았습니다. 교차 분석을 시작합니다 (조금 걸릴 수 있습니다)...")

    # 2. 파일 내용 메모리에 읽어두기 (유니티는 BOM 있는 UTF-8이 많음)
    for file_path in all_files:
        try:
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                file_contents[file_path] = f.read()
        except:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                file_contents[file_path] = f.read()

    # 3. 각 클래스 이름이 다른 스크립트에 등장하는지 정규식(단어 단위)으로 검사
    for target_class, target_path in class_names.items():
        # 단어 경계(\b)를 사용하여 정확히 해당 클래스 이름만 매칭
        pattern = re.compile(rf'\b{target_class}\b')
        
        for source_path, content in file_contents.items():
            if source_path == target_path:
                continue # 자기 자신은 제외
            
            if pattern.search(content):
                # source_path 스크립트 안에 target_class 단어가 존재함
                forward_graph[source_path].add(target_path)
                reverse_graph[target_path].add(source_path)

    print("✅ 스캔 및 분석 완료! 지도를 완성했습니다.")

def search_dependencies():
    while True:
        print("=" * 60)
        query = input("💡 검색할 C# 스크립트명 입력 (예: ReinforcementManager) / 종료는 q: ").strip()
        
        if query.lower() == 'q':
            print("🚀 프로그램을 종료합니다.")
            break
            
        if not query:
            continue
            
        # .cs를 붙여서 검색했으면 떼어줌
        if query.endswith('.cs'):
            query = query[:-3]
            
        found_files = [f for f in forward_graph.keys() | reverse_graph.keys() if query.lower() in os.path.basename(f).lower()]
        
        if not found_files:
            print(f"❌ '{query}'(이)가 포함된 .cs 코드를 찾을 수 없거나, 연결된 의존성이 없습니다.")
            continue
            
        for target in found_files:
            print(f"\n📂 [선택된 스크립트]: {target}")
            
            print("\n  [⬇️ 이 스크립트가 가져다 쓰는 다른 스크립트]")
            if forward_graph[target]:
                for dep in sorted(forward_graph[target]):
                    print(f"    - {os.path.basename(dep)}")
            else:
                print("    (없음)")
                
            print("\n  [⬆️ 이 스크립트를 가져다 쓰는 다른 스크립트 (역추적)]")
            if reverse_graph[target]:
                for dep in sorted(reverse_graph[target]):
                    print(f"    - {os.path.basename(dep)}")
            else:
                print("    (없음)")

if __name__ == "__main__":
    scan_unity_project()
    search_dependencies()