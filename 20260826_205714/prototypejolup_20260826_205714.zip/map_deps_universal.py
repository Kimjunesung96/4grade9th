import os
import re
from collections import defaultdict

# 탐색할 최상위 경로
BASE_DIR = '.'
# 스캔에서 제외할 폴더
IGNORE_DIRS = {'node_modules', '.git', '.vite', 'dist', 'build', 'Library', 'Logs', 'Packages', 'obj', 'Temp'}
# 읽지 않을 확장자 (바이너리)
IGNORE_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.svg', '.mp4', '.dll', '.exe', '.zip', '.pdf', '.meta',
               '.prefab', '.unity', '.asset', '.mat', '.anim', '.controller', '.fbx', '.obj'}

# 이 크기 이상인 파일은 스킵 (단위: bytes) — 기본 500KB
MAX_FILE_SIZE = 500 * 1024

forward_graph = defaultdict(set)  # 파일 -> 이 파일이 언급하는 파일들
reverse_graph = defaultdict(set)  # 파일 -> 이 파일을 언급하는 파일들

all_valid_files = []  # 고립 파일 검색용 전체 목록


def make_pattern(name):
    """
    \b 대신 직접 경계 패턴 작성.
    한글/언더스코어 시작 파일명도 정확히 잡힘.
    '파일명' 앞뒤가 알파벳/숫자/밑줄이 아닌 경우에만 매칭.
    """
    escaped = re.escape(name)
    return re.compile(rf'(?<![A-Za-z0-9_]){escaped}(?![A-Za-z0-9_])')


def scan_universal_project():
    global all_valid_files

    print("🔍 [만능 모드] 확장자를 가리지 않고 모든 파일의 연관성을 스캔합니다...\n")

    file_contents = {}
    file_names_map = {}  # 파일명(확장자 제외) -> 실제 경로

    # 1. 파일 목록 수집
    for root, dirs, files in os.walk(BASE_DIR):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in IGNORE_EXTS:
                continue

            filepath = os.path.normpath(os.path.join(root, file))
            all_valid_files.append(filepath)

            name_no_ext = os.path.splitext(file)[0]
            # 2글자 이하는 오탐이 심하므로 의존성 추적 대상에서만 제외
            # (검색은 가능, 다만 역추적만 됨)
            if len(name_no_ext) > 2:
                file_names_map[name_no_ext] = filepath

    print(f"📂 총 {len(all_valid_files)}개의 파일을 찾았습니다. 읽는 중...")

    # 2. 파일 내용 읽기 (크기 제한 적용)
    skipped = 0
    for file_path in all_valid_files:
        if os.path.getsize(file_path) > MAX_FILE_SIZE:
            skipped += 1
            continue
        try:
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                file_contents[file_path] = f.read()
        except UnicodeDecodeError:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    file_contents[file_path] = f.read()
            except Exception:
                pass

    if skipped:
        print(f"⚡ 대용량 파일 {skipped}개 스킵 (500KB 초과)")
    print(f"🧠 파일 교차 분석 중... ({len(file_contents)}개 × {len(file_names_map)}개 조합)")

    # 3. 무차별 대입 스캔 (진행률 표시)
    total = len(file_names_map)
    for i, (target_name, target_path) in enumerate(file_names_map.items(), 1):
        if i % 10 == 0 or i == total:
            print(f"  {i}/{total} 완료...", end='\r')

        pattern = make_pattern(target_name)

        for source_path, content in file_contents.items():
            if source_path == target_path:
                continue
            if pattern.search(content):
                forward_graph[source_path].add(target_path)
                reverse_graph[target_path].add(source_path)

    print()  # 진행률 줄 정리

    print("✅ 스캔 완료! 검색 준비됐습니다.\n")


def search_dependencies():
    while True:
        print("=" * 60)
        query = input("💡 검색할 파일명 입력 (확장자 있어도 없어도 됨) / 종료는 q: ").strip()

        if query.lower() == 'q':
            print("🚀 종료합니다.")
            break

        if not query:
            continue

        query_no_ext = os.path.splitext(query)[0].lower()

        # 버그1 수정: forward/reverse graph가 아닌 전체 파일 목록에서 검색
        found_files = [
            f for f in all_valid_files
            if query_no_ext in os.path.splitext(os.path.basename(f))[0].lower()
        ]

        if not found_files:
            print(f"❌ '{query}'(이)가 포함된 파일을 찾을 수 없습니다.")
            continue

        for target in found_files:
            print(f"\n📂 [선택된 파일]: {target}")

            print("\n  [⬇️ 이 파일이 언급하는 다른 파일들]")
            if forward_graph[target]:
                for dep in sorted(forward_graph[target]):
                    print(f"    - {os.path.basename(dep)}  ({dep})")
            else:
                print("    (없음)")

            print("\n  [⬆️ 이 파일을 언급하는 다른 파일들]")
            if reverse_graph[target]:
                for dep in sorted(reverse_graph[target]):
                    print(f"    - {os.path.basename(dep)}  ({dep})")
            else:
                print("    (없음 — 고립 파일이거나 파일명이 너무 짧아 추적 제외됨)")


if __name__ == "__main__":
    scan_universal_project()
    search_dependencies()