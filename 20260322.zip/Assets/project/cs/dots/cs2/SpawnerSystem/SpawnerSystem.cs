﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

// ⭐ 가설계(홀로그램) 블록을 구분하기 위한 꼬리표
public struct GhostBlockTag : IComponentData { }

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct SpawnerSystem : ISystem
{
    private float3 dragStartPos;
    private float3 dragEndPos;
    private int currentBuildMode;
    private float guideHeight;
    private bool isGuideActive;
    private int nextStructureID;

    // 🎯 [도장 찍기 공법] 우클릭 이동 좌표 기억장치
    private bool isCenterMoved;
    private float3 customCenterPos;

    private NativeList<BlobAssetReference<Unity.Physics.Collider>> _createdColliders;

    // 👷‍♂️ [블랙박스 번호판 버그 픽스!] UI의 0번 개입을 원천 차단!
    private string GetToolName(int mode)
    {
        switch (mode)
        {
            case 0: return "1_Solid_Wall";
            case 1: return "1_Solid_Wall";
            case 2: return "2_Empty_Frame";
            case 3: return "3_Circular_Pattern";
            case 4: return "4_Pyramid";
            case 5: return "5_Cone";
            default: return "Unknown_Tool";
        }
    }

    public void OnCreate(ref SystemState state)
    {
        currentBuildMode = 1;
        guideHeight = 1f;
        isGuideActive = false;
        nextStructureID = 1;
        isCenterMoved = false;
        customCenterPos = float3.zero;
        _createdColliders = new NativeList<BlobAssetReference<Unity.Physics.Collider>>(Allocator.Persistent);
    }

    public void OnDestroy(ref SystemState state)
    {
        if (_createdColliders.IsCreated)
        {
            foreach (var col in _createdColliders) { if (col.IsCreated) col.Dispose(); }
            _createdColliders.Dispose();
        }
    }

    public void OnUpdate(ref SystemState state)
    {
        if (!UnityEngine.Application.isPlaying || Camera.main == null) return;

        if (!SystemAPI.HasSingleton<BuilderStateData>()) return;
        var builderState = SystemAPI.GetSingletonRW<BuilderStateData>();

        if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsSingleton)) return;

        SpawnerData spawnerData = default;
        bool hasSpawner = false;
        foreach (var data in SystemAPI.Query<RefRO<SpawnerData>>())
        {
            spawnerData = data.ValueRO;
            hasSpawner = true;
            break;
        }
        if (!hasSpawner) return;

        PhysicsWorld physicsWorld = physicsSingleton.PhysicsWorld;

        // 휠 조작 (층수 조절)
        if (Input.mouseScrollDelta.y != 0)
        {
            builderState.ValueRW.GuideHeight += Input.mouseScrollDelta.y;
            if (builderState.ValueRW.GuideHeight < 1f) builderState.ValueRW.GuideHeight = 1f;
        }

        // 모드 변경 조작
        if (Input.GetKeyDown(KeyCode.Alpha1)) { builderState.ValueRW.CurrentMode = 1; }
        if (Input.GetKeyDown(KeyCode.Alpha2)) { builderState.ValueRW.CurrentMode = 2; }
        if (Input.GetKeyDown(KeyCode.Alpha3)) { builderState.ValueRW.CurrentMode = 3; }
        if (Input.GetKeyDown(KeyCode.Alpha4)) { builderState.ValueRW.CurrentMode = 4; }
        if (Input.GetKeyDown(KeyCode.Alpha5)) { builderState.ValueRW.CurrentMode = 5; }

        // 🏆 [교체 완료] Enter키: Master 도면집에 영구 박제!
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.SaveToMaster();
                Debug.Log("⭐⭐⭐ 십장님! 마스터 도면집(Master Blueprint)에 영구 박제 완료!! ⭐⭐⭐");
            }
        }
        // 🚨 [교체 완료] R키: Temp 작업대 파쇄 및 챕터 초기화!
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.OnPressRKey();
                Debug.Log("🪓 [현장 철거] R키 작동! Temp 서류를 파쇄하고 새 챕터를 시작합니다!");
            }
        }

        currentBuildMode = builderState.ValueRO.CurrentMode;
        guideHeight = builderState.ValueRO.GuideHeight;
        dragStartPos = builderState.ValueRO.GuideStartPos;
        dragEndPos = builderState.ValueRO.GuideEndPos;

        // =================================================================
        // 🎯 [도장 찍기 공법] 크기와 중심 좌표 계산
        // =================================================================
        float sizeX = math.abs(dragEndPos.x - dragStartPos.x);
        float sizeZ = math.abs(dragEndPos.z - dragStartPos.z);
        float3 defaultCenter = new float3((dragStartPos.x + dragEndPos.x) / 2f, 0, (dragStartPos.z + dragEndPos.z) / 2f);

        // 1회성 우클릭(Mouse1)으로 도장 찍을 위치 변경!
        if (Input.GetMouseButtonDown(1))
        {
            UnityEngine.Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastInput rayInput = new RaycastInput { Start = ray.origin, End = ray.origin + ray.direction * 500f, Filter = CollisionFilter.Default };
            if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
            {
                customCenterPos = hit.Position;
                isCenterMoved = true;
                Debug.Log($"[블루프린트] 도장 찍을 좌표 이동 완료: {customCenterPos}");
            }
        }

        // 좌클릭(Mouse0)으로 새 드래그 시작하면 이동 상태 초기화!
        if (Input.GetMouseButtonDown(0)) isCenterMoved = false;

        // 최종 중심 위치 & 기존 위치와의 차이(오프셋) 계산
        float3 finalCenter = isCenterMoved ? new float3(customCenterPos.x, 0, customCenterPos.z) : defaultCenter;
        float3 centerOffset = finalCenter - defaultCenter;

        // ⭐ 우클릭으로 중심이 바뀌었으면, 실제 지어지는 블록의 시작/끝 좌표도 같이 옮겨줍니다!
        float3 actualStartPos = dragStartPos + centerOffset;
        float3 actualEndPos = dragEndPos + centerOffset;
        // =================================================================

        // 내핵 시공 방지턱 (-10000 이하 쓰레기값 무시)
        isGuideActive = (math.lengthsq(actualStartPos) > 0.001f || math.lengthsq(actualEndPos) > 0.001f) && actualStartPos.x > -10000f;

        // 가설계 선 그리기 (옮겨진 좌표 기준)
        if (isGuideActive) DrawGuideWireframe(actualStartPos, actualEndPos, guideHeight, currentBuildMode);

        bool isFKeyPressed = Input.GetKeyDown(KeyCode.F);
        bool isGKeyPressed = Input.GetKeyDown(KeyCode.G);

        if (isGuideActive && (isFKeyPressed || isGKeyPressed))
        {
            bool isGhost = isFKeyPressed;

            // 📝 [교체 완료] 최신식 LogManager로 데이터 전송!
            if (LogManager.Instance != null)
            {
                string toolName = GetToolName(currentBuildMode);
                int height = (int)math.round(guideHeight);
                string actionStr = isGhost ? "Key_F" : "Key_G";
                string statusStr = isGhost ? "Preview_Hologram" : "Build_Complete";

                // 중심 좌표를 안전하게 정수로 변환하여 문자열로 포장!
                int safeCenterX = math.isnan(finalCenter.x) || math.isinf(finalCenter.x) ? 0 : (int)math.round(finalCenter.x);
                int safeCenterZ = math.isnan(finalCenter.z) || math.isinf(finalCenter.z) ? 0 : (int)math.round(finalCenter.z);
                string centerStr = $"[{safeCenterX}, {safeCenterZ}]";

                LogManager.Instance.AddLog(toolName, height, actionStr, statusStr, centerStr);
            }

            // 기존 가설계 블록 청소
            var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
            foreach (var (ghostTag, entity) in SystemAPI.Query<RefRO<GhostBlockTag>>().WithEntityAccess())
            {
                ecb.DestroyEntity(entity);
            }

            float highestY = -9999f;
            Entity hitEntity = Entity.Null;
            bool hitAnything = false;
            float blockSize = 3.0f;

            // ⭐ 여기서부터 타설 공정! 드래그한 위치(drag) 대신 '옮겨진 도장 위치(actual)'를 사용합니다!
            float3 startXZ = new float3(actualStartPos.x, 0, actualStartPos.z);
            float3 endXZ = new float3(actualEndPos.x, 0, actualEndPos.z);
            float distance = math.distance(startXZ, endXZ);

            if (currentBuildMode == 1)
            {
                float3 dir = distance < 0.1f ? new float3(1, 0, 0) : math.normalize(endXZ - startXZ);
                int steps = (int)math.max(1, math.round(distance / (blockSize * 0.5f)));
                for (int i = 0; i <= steps; i++)
                {
                    float3 p = startXZ + dir * (i * (distance / math.max(1, steps)));
                    CheckRay(physicsWorld, p.x, p.z, ref highestY, ref hitEntity, ref hitAnything);
                }
            }
            else if (currentBuildMode == 2 || currentBuildMode == 4)
            {
                float minX = math.min(startXZ.x, endXZ.x); float maxX = math.max(startXZ.x, endXZ.x);
                float minZ = math.min(startXZ.z, endXZ.z); float maxZ = math.max(startXZ.z, endXZ.z);
                for (float x = minX; x <= maxX + 0.1f; x += 1.0f)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += 1.0f)
                    {
                        if (currentBuildMode == 2) { if (x > minX + 1.5f && x < maxX - 1.5f && z > minZ + 1.5f && z < maxZ - 1.5f) continue; }
                        CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                    }
                }
            }
            else if (currentBuildMode == 3 || currentBuildMode == 5)
            {
                float radius = distance / 2.0f;
                float3 center = (startXZ + endXZ) / 2.0f;
                float minX = center.x - radius; float maxX = center.x + radius;
                float minZ = center.z - radius; float maxZ = center.z + radius;
                for (float x = minX; x <= maxX + 0.1f; x += 1.0f)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += 1.0f)
                    {
                        float distSq = math.distancesq(new float3(x, 0, z), center);
                        if (distSq <= radius * radius)
                        {
                            if (currentBuildMode == 3 && distSq < (radius - 1.5f) * (radius - 1.5f)) continue;
                            CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                        }
                    }
                }
            }

            if (hitAnything)
            {
                // 여기도 actual 위치 기반으로 높이 계산
                float finalBuildY = math.max(highestY, actualStartPos.y);
                ExecuteBuild(ref state, spawnerData, actualStartPos, actualEndPos, finalBuildY, hitEntity, isGhost);

                if (!isGhost) isGuideActive = false;
            }
        }
    }

    // ⭐ 빌드 실행할 때도 옮겨진 위치(actual)를 건네줍니다!
    private void ExecuteBuild(ref SystemState state, SpawnerData data, float3 actualStart, float3 actualEnd, float targetY, Entity hitEntity, bool isGhost)
    {
        bool hitExistingBlock = SystemAPI.HasComponent<BlockTag>(hitEntity);
        float3 hitEntityPos = hitExistingBlock ? SystemAPI.GetComponent<LocalTransform>(hitEntity).Position : float3.zero;

        switch (currentBuildMode)
        {
            case 1: BuildSolidWall(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 2: BuildEmptyFrame(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 3: BuildCircularPattern(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 4: BuildPyramid(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 5: BuildCone(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
        }

        if (!isGhost) nextStructureID++;
    }

    private void CheckRay(PhysicsWorld physicsWorld, float x, float z, ref float highestY, ref Entity hitEntity, ref bool hitAnything)
    {
        float3 rayPos = new float3(x, 100f, z);
        RaycastInput rayInput = new RaycastInput { Start = rayPos, End = rayPos + new float3(0, -200f, 0), Filter = CollisionFilter.Default };
        if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
        {
            hitAnything = true;
            if (hit.Position.y > highestY) { highestY = hit.Position.y; hitEntity = hit.Entity; }
        }
    }

    private void DrawGuideWireframe(float3 start, float3 end, float heightParam, int mode)
    {
        Color color = Color.green; float blockSize = 3.0f; float h = heightParam * blockSize;
        if (mode == 1 || mode == 2)
        {
            Vector3 p1 = new Vector3(start.x, start.y, start.z); Vector3 p2 = new Vector3(end.x, start.y, start.z);
            Vector3 p3 = new Vector3(end.x, start.y, end.z); Vector3 p4 = new Vector3(start.x, start.y, end.z);
            Debug.DrawLine(p1, p2, color); Debug.DrawLine(p2, p3, color); Debug.DrawLine(p3, p4, color); Debug.DrawLine(p4, p1, color);
            if (heightParam > 1)
            {
                Vector3 t1 = p1 + Vector3.up * h; Vector3 t2 = p2 + Vector3.up * h; Vector3 t3 = p3 + Vector3.up * h; Vector3 t4 = p4 + Vector3.up * h;
                Debug.DrawLine(t1, t2, color); Debug.DrawLine(t2, t3, color); Debug.DrawLine(t3, t4, color); Debug.DrawLine(t4, t1, color);
                Debug.DrawLine(p1, t1, color); Debug.DrawLine(p2, t2, color); Debug.DrawLine(p3, t3, color); Debug.DrawLine(p4, t4, color);
            }
        }
        else if (mode == 3 || mode == 4 || mode == 5)
        {
            float3 center = (start + end) / 2f; float radius = math.distance(start, end) / 2f;
            int segments = 24; float angleStep = (2f * math.PI) / segments;
            Vector3 prev = center + new float3(radius, 0, 0);
            for (int i = 1; i <= segments; i++)
            {
                Vector3 next = center + new float3(math.cos(i * angleStep) * radius, 0, math.sin(i * angleStep) * radius);
                Debug.DrawLine(prev, next, color); prev = next;
            }
            if (heightParam > 1) Debug.DrawLine(center, center + new float3(0, h, 0), color);
        }
    }

    private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));
        ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f)));
    }
}