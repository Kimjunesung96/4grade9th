﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// 1. 단일 기록 (한 줄 엑기스)
[Serializable]
public class ActionLog
{
    public string time;
    public string tool;
    public int height;
    public string action; // "Key_F", "Key_G"
    public string status; // "Preview_Hologram", "Build_Complete"
    public string centerXZ;
}

// 2. [CCTV용] 1회차 시도 
[Serializable]
public class ProjectAttempt
{
    public int Attempt;
    public string Start_Time;
    public string End_Time;
    public string Status;
    public List<ActionLog> Actions = new List<ActionLog>();
}

// 3. [CCTV용] 파일 구조 (날짜 O)
[Serializable]
public class DailyRawLog
{
    public string Date;
    public int Total_Attempts;
    public List<string> Reset_Timestamps = new List<string>();
    public List<ProjectAttempt> Projects_Details = new List<ProjectAttempt>();
}

// 4. [Temp 작업대용] 파일 구조 (날짜 X)
[Serializable]
public class TempLog
{
    public string Notice = "현재 타설 중인 블록입니다. (R키 누르면 날아감)";
    public List<ActionLog> Current_Blocks = new List<ActionLog>();
}

// 5. [마스터 도면집용] 내부 도면 구조
[Serializable]
public class Blueprint
{
    public int Blueprint_ID;
    public string Saved_Time;
    public List<ActionLog> Blocks = new List<ActionLog>();
}

// 6. [마스터 도면집용] 파일 구조 (날짜 O)
[Serializable]
public class MasterBlueprintLog
{
    public string Date;
    public int Total_Masterpieces;
    public List<Blueprint> Blueprints = new List<Blueprint>();
}

public class LogManager : MonoBehaviour
{
    public static LogManager Instance;

    // 서류철 3형제
    private DailyRawLog rawDailyLog;
    private TempLog tempLogData;
    private MasterBlueprintLog masterLogData;
    private ProjectAttempt currentAttempt;

    // 파일 경로 3형제
    private string rawFilePath;
    private string tempFilePath;
    private string masterFilePath;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        string dateStr = DateTime.Now.ToString("yyyyMMdd");
        string basePath = Application.dataPath;

        // ⭐ 십장님의 3파일 시스템 경로 세팅!
        rawFilePath = Path.Combine(basePath, $"Log_Raw_{dateStr}.json");
        tempFilePath = Path.Combine(basePath, "Temp_Current_Building.json"); // 👈 날짜 없음!
        masterFilePath = Path.Combine(basePath, $"Master_Blueprint_{dateStr}.json");

        LoadOrCreateLogs();
    }

    void LoadOrCreateLogs()
    {
        // 1. Raw 불러오기
        if (File.Exists(rawFilePath)) rawDailyLog = JsonUtility.FromJson<DailyRawLog>(File.ReadAllText(rawFilePath));
        else rawDailyLog = new DailyRawLog { Date = DateTime.Now.ToString("yyyy-MM-dd") };

        // 2. Master 불러오기
        if (File.Exists(masterFilePath)) masterLogData = JsonUtility.FromJson<MasterBlueprintLog>(File.ReadAllText(masterFilePath));
        else masterLogData = new MasterBlueprintLog { Date = DateTime.Now.ToString("yyyy-MM-dd") };

        // 3. Temp는 출근하면 무조건 빈 작업대로 싹 치워놓기!
        tempLogData = new TempLog();
        SaveTempLog();

        // Raw 챕터 정리
        if (rawDailyLog.Projects_Details.Count == 0 || rawDailyLog.Projects_Details[rawDailyLog.Projects_Details.Count - 1].Status != "In_Progress")
        {
            StartNewAttempt();
        }
        else
        {
            currentAttempt = rawDailyLog.Projects_Details[rawDailyLog.Projects_Details.Count - 1];
        }
    }

    void StartNewAttempt()
    {
        rawDailyLog.Total_Attempts++;
        currentAttempt = new ProjectAttempt { Attempt = rawDailyLog.Total_Attempts, Start_Time = DateTime.Now.ToString("HH:mm:ss"), Status = "In_Progress" };
        rawDailyLog.Projects_Details.Add(currentAttempt);
        SaveRawLog();
    }

    // 🏗️ 현장에서 타설/홀로그램 할 때 부를 함수
    public void AddLog(string tool, int height, string action, string status, string centerXZ)
    {
        ActionLog newLog = new ActionLog { time = DateTime.Now.ToString("HH:mm:ss"), tool = tool, height = height, action = action, status = status, centerXZ = centerXZ };

        // 1. 무조건 Raw에는 다 적음
        currentAttempt.Actions.Add(newLog);
        SaveRawLog();

        // 2. 진짜 타설(G)일 때만 Temp(작업대)에 복사!
        if (action == "Key_G" || status == "Build_Complete")
        {
            tempLogData.Current_Blocks.Add(newLog);
            SaveTempLog();
        }
    }

    // 🚨 R키 눌렀을 때 (엎어치기!)
    public void OnPressRKey()
    {
        string nowTime = DateTime.Now.ToString("HH:mm:ss");

        // 1. Raw 마감 처리
        currentAttempt.End_Time = nowTime;
        currentAttempt.Status = "Reset";
        rawDailyLog.Reset_Timestamps.Add($"Attempt {currentAttempt.Attempt}: {nowTime} (Reset)");
        SaveRawLog();
        StartNewAttempt();

        // 2. Temp 작업대 서류 파쇄!!!
        tempLogData.Current_Blocks.Clear();
        SaveTempLog();
    }

    // 🏆 Enter키 눌렀을 때 (마스터 도면집에 영구 박제!)
    public void SaveToMaster()
    {
        if (tempLogData.Current_Blocks.Count == 0) return; // 지은 게 없으면 무시

        string nowTime = DateTime.Now.ToString("HH:mm:ss");

        // 1. 마스터 도면집에 새 페이지 추가
        masterLogData.Total_Masterpieces++;
        Blueprint newBlueprint = new Blueprint
        {
            Blueprint_ID = masterLogData.Total_Masterpieces,
            Saved_Time = nowTime,
            Blocks = new List<ActionLog>(tempLogData.Current_Blocks) // Temp 내용물 싹 다 복사!
        };
        masterLogData.Blueprints.Add(newBlueprint);
        SaveMasterLog();

        // 2. Raw에 '성공' 도장 찍기
        currentAttempt.End_Time = nowTime;
        currentAttempt.Status = "Success";
        rawDailyLog.Reset_Timestamps.Add($"Attempt {currentAttempt.Attempt}: {nowTime} (Success)");
        SaveRawLog();
        StartNewAttempt();

        // 3. 다음 공사를 위해 Temp 작업대 비우기!
        tempLogData.Current_Blocks.Clear();
        SaveTempLog();

        Debug.Log("🎉 마스터 도면집에 성공적으로 영구 박제되었습니다!");
    }

    // 파일 굽기 3형제
    private void SaveRawLog() { File.WriteAllText(rawFilePath, JsonUtility.ToJson(rawDailyLog, true)); }
    private void SaveTempLog() { File.WriteAllText(tempFilePath, JsonUtility.ToJson(tempLogData, true)); }
    private void SaveMasterLog() { File.WriteAllText(masterFilePath, JsonUtility.ToJson(masterLogData, true)); }
}