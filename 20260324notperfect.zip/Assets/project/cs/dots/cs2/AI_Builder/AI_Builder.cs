﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

// 🚨 AI 장부(도면) 규격
[Serializable]
public class AiBlock
{
    public string tool;
    public string sizeXZH;
    public string centerXYZ;
}

[Serializable]
public class AiBlueprintData
{
    public List<AiBlock> Option_A;
    public List<AiBlock> Option_B;
    public List<AiBlock> Option_C;
}

public class AI_Builder : MonoBehaviour
{
    [Header("현장 자재 (프리팹)")]
    public GameObject realBlockPrefab;
    public GameObject hologramPrefab;

    private bool isAiHologramActive = false;
    private List<GameObject> activeHolograms = new List<GameObject>();
    private Vector3 currentBlueprintCenter;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Y)) LoadAndSpawnHolograms("Option_A");
        if (Input.GetKeyDown(KeyCode.U)) LoadAndSpawnHolograms("Option_B");
        if (Input.GetKeyDown(KeyCode.I)) LoadAndSpawnHolograms("Option_C");

        if (isAiHologramActive)
        {
            // 🚀 우클릭: 십장님 마우스 찍은 곳으로 전체 도면 중앙이 철컥! 이동합니다.
            if (Input.GetMouseButtonDown(1))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out RaycastHit hit))
                {
                    MoveHologramsTo(hit.point);
                }
            }

            // 🚀 G키: 일괄 타설!
            if (Input.GetKeyDown(KeyCode.G)) ConfirmAiBuild();
            if (Input.GetKeyDown(KeyCode.Escape)) CancelHolograms();
        }
    }

    private string GetLatestBlueprintJson()
    {
        string dirPath = Path.Combine(Application.dataPath, "ai_designs");
        if (!Directory.Exists(dirPath)) return null;

        var latestFile = new DirectoryInfo(dirPath).GetFiles("Gemini_Blueprint_*.json")
                            .OrderByDescending(f => f.LastWriteTime).FirstOrDefault();
        if (latestFile == null) return null;

        return File.ReadAllText(latestFile.FullName);
    }

    private void LoadAndSpawnHolograms(string optionName)
    {
        CancelHolograms();

        string json = GetLatestBlueprintJson();
        if (string.IsNullOrEmpty(json))
        {
            Debug.LogError("🚨 [AI 무전] 창고에 도면이 없습니다! T키로 발주부터 하십쇼!");
            return;
        }

        AiBlueprintData blueprint = JsonUtility.FromJson<AiBlueprintData>(json);
        List<AiBlock> targetBlocks = null;

        if (optionName == "Option_A") targetBlocks = blueprint.Option_A;
        else if (optionName == "Option_B") targetBlocks = blueprint.Option_B;
        else if (optionName == "Option_C") targetBlocks = blueprint.Option_C;

        if (targetBlocks == null || targetBlocks.Count == 0) return;

        // 🚨 [십장님 지시사항] 전체 도면의 진짜 중앙을 찾기 위한 측량기!
        float minX = float.MaxValue, maxX = float.MinValue;
        float minZ = float.MaxValue, maxZ = float.MinValue;

        foreach (AiBlock block in targetBlocks)
        {
            string cleanSize = block.sizeXZH.Replace("[", "").Replace("]", "").Replace(" ", "");
            string[] sizeArr = cleanSize.Split(',');
            float sX = float.Parse(sizeArr[0]);
            float sZ = float.Parse(sizeArr[1]);
            int h = int.Parse(sizeArr[2]);

            string cleanCenter = block.centerXYZ.Replace("[", "").Replace("]", "").Replace(" ", "");
            string[] centerArr = cleanCenter.Split(',');
            float cX = float.Parse(centerArr[0]);
            float cY = float.Parse(centerArr[1]);
            float cZ = float.Parse(centerArr[2]);
            Vector3 blockPos = new Vector3(cX, cY, cZ);

            GameObject holo = Instantiate(hologramPrefab, blockPos, Quaternion.identity);
            holo.transform.localScale = new Vector3(sX, h * 3.0f, sZ);
            activeHolograms.Add(holo);

            // 🚨 지어지는 모든 블록의 최외곽 좌표를 기록합니다!
            if (cX < minX) minX = cX;
            if (cX > maxX) maxX = cX;
            if (cZ < minZ) minZ = cZ;
            if (cZ > maxZ) maxZ = cZ;
        }

        // 🚨 [수술 완료] 모서리가 아니라, 전체 건물의 '바닥 정중앙'을 마우스 손잡이로 설정합니다!
        currentBlueprintCenter = new Vector3((minX + maxX) / 2f, 0, (minZ + maxZ) / 2f);

        isAiHologramActive = true;
        Debug.Log($"👀 [{optionName}] 전체 도면 중앙 영점 조절 완료! 우클릭으로 부지 통째로 이사하십쇼!");
    }

    private void MoveHologramsTo(Vector3 targetPos)
    {
        float blockSize = 3.0f;
        // 마우스 찍은 위치를 3.0 격자에 철컥! 맞춤
        float snappedX = (float)Math.Round(targetPos.x / blockSize) * blockSize;
        float snappedZ = (float)Math.Round(targetPos.z / blockSize) * blockSize;
        Vector3 newCenter = new Vector3(snappedX, 0, snappedZ);

        // 현재 도면 중앙에서 -> 새 마우스 중앙으로 얼마나 이동해야 하는지 계산
        Vector3 offset = newCenter - currentBlueprintCenter;

        foreach (GameObject holo in activeHolograms)
        {
            holo.transform.position += new Vector3(offset.x, 0, offset.z);
        }

        // 영점 갱신
        currentBlueprintCenter = newCenter;
    }

    private void ConfirmAiBuild()
    {
        foreach (GameObject holo in activeHolograms)
        {
            GameObject realBlock = Instantiate(realBlockPrefab, holo.transform.position, holo.transform.rotation);
            realBlock.transform.localScale = holo.transform.localScale;
        }

        CancelHolograms();
        Debug.Log("🔨 [현장 무전] 복합 도면 일괄 타설 완료!! 십장님, 시원하게 올라갔습니다!");
    }

    private void CancelHolograms()
    {
        foreach (GameObject holo in activeHolograms) Destroy(holo);
        activeHolograms.Clear();
        isAiHologramActive = false;
    }
}