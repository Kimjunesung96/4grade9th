﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

public struct GhostBlockTag : IComponentData { }

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct SpawnerSystem : ISystem
{
    private float3 dragStartPos;
    private float3 dragEndPos;
    private int currentBuildMode;
    private float guideHeight;
    private bool isGuideActive;
    private int nextStructureID;

    private bool isCenterMoved;
    private float3 customCenterPos;

    private NativeList<BlobAssetReference<Unity.Physics.Collider>> _createdColliders;

    private string GetToolName(int mode)
    {
        switch (mode)
        {
            case 0: return "1_Solid_Wall";
            case 1: return "1_Solid_Wall";
            case 2: return "2_Empty_Frame";
            case 3: return "3_Circular_Pattern";
            case 4: return "4_Pyramid";
            case 5: return "5_Cone";
            default: return "Unknown_Tool";
        }
    }

    public void OnCreate(ref SystemState state)
    {
        currentBuildMode = 1;
        guideHeight = 1f;
        isGuideActive = false;
        nextStructureID = 1;
        isCenterMoved = false;
        customCenterPos = float3.zero;
        _createdColliders = new NativeList<BlobAssetReference<Unity.Physics.Collider>>(Allocator.Persistent);
    }

    public void OnDestroy(ref SystemState state)
    {
        if (_createdColliders.IsCreated)
        {
            foreach (var col in _createdColliders) { if (col.IsCreated) col.Dispose(); }
            _createdColliders.Dispose();
        }
    }

    public void OnUpdate(ref SystemState state)
    {
        if (!UnityEngine.Application.isPlaying || Camera.main == null) return;

        if (!SystemAPI.HasSingleton<BuilderStateData>()) return;
        var builderState = SystemAPI.GetSingletonRW<BuilderStateData>();

        if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsSingleton)) return;

        SpawnerData spawnerData = default;
        bool hasSpawner = false;
        foreach (var data in SystemAPI.Query<RefRO<SpawnerData>>())
        {
            spawnerData = data.ValueRO;
            hasSpawner = true;
            break;
        }
        if (!hasSpawner) return;

        PhysicsWorld physicsWorld = physicsSingleton.PhysicsWorld;

        if (Input.mouseScrollDelta.y != 0)
        {
            builderState.ValueRW.GuideHeight += Input.mouseScrollDelta.y;
            if (builderState.ValueRW.GuideHeight < 1f) builderState.ValueRW.GuideHeight = 1f;
        }

        if (Input.GetKeyDown(KeyCode.Alpha1)) { builderState.ValueRW.CurrentMode = 1; }
        if (Input.GetKeyDown(KeyCode.Alpha2)) { builderState.ValueRW.CurrentMode = 2; }
        if (Input.GetKeyDown(KeyCode.Alpha3)) { builderState.ValueRW.CurrentMode = 3; }
        if (Input.GetKeyDown(KeyCode.Alpha4)) { builderState.ValueRW.CurrentMode = 4; }
        if (Input.GetKeyDown(KeyCode.Alpha5)) { builderState.ValueRW.CurrentMode = 5; }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.SaveToMaster();
                Debug.Log("⭐⭐⭐ 십장님! 마스터 도면집(Master Blueprint)에 영구 박제 완료!! ⭐⭐⭐");
            }
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.OnPressRKey();
                Debug.Log("🪓 [현장 철거] R키 작동! Temp 서류를 파쇄하고 새 챕터를 시작합니다!");
            }
        }

        currentBuildMode = builderState.ValueRO.CurrentMode;
        guideHeight = builderState.ValueRO.GuideHeight;
        dragStartPos = builderState.ValueRO.GuideStartPos;
        dragEndPos = builderState.ValueRO.GuideEndPos;

        if (Input.GetMouseButtonDown(1))
        {
            UnityEngine.Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastInput rayInput = new RaycastInput { Start = ray.origin, End = ray.origin + ray.direction * 500f, Filter = CollisionFilter.Default };
            if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
            {
                customCenterPos = hit.Position;
                isCenterMoved = true;
            }
        }

        if (Input.GetMouseButtonDown(0)) isCenterMoved = false;

        float3 defaultCenter = new float3((dragStartPos.x + dragEndPos.x) / 2f, 0, (dragStartPos.z + dragEndPos.z) / 2f);
        float3 finalCenter = isCenterMoved ? new float3(customCenterPos.x, 0, customCenterPos.z) : defaultCenter;
        float3 centerOffset = finalCenter - defaultCenter;

        float3 actualStartPos = dragStartPos + centerOffset;
        float3 actualEndPos = dragEndPos + centerOffset;

        // ⭐⭐⭐ [현장 규격 통일!] 모든 기준을 3.0f로 맞춥니다! ⭐⭐⭐
        float blockSize = 3.0f;

        // 1. 눈금자 스냅: 이제 1단위가 아니라 3.0 단위로 철컥철컥 움직입니다! (올림/반올림 오차 해결!)
        actualStartPos.x = (float)System.Math.Round(actualStartPos.x / blockSize) * blockSize;
        actualStartPos.z = (float)System.Math.Round(actualStartPos.z / blockSize) * blockSize;
        actualEndPos.x = (float)System.Math.Round(actualEndPos.x / blockSize) * blockSize;
        actualEndPos.z = (float)System.Math.Round(actualEndPos.z / blockSize) * blockSize;
        finalCenter.x = (float)System.Math.Round(finalCenter.x / blockSize) * blockSize;
        finalCenter.z = (float)System.Math.Round(finalCenter.z / blockSize) * blockSize;

        isGuideActive = (math.lengthsq(actualStartPos) > 0.001f || math.lengthsq(actualEndPos) > 0.001f) && actualStartPos.x > -10000f;

        if (isGuideActive)
        {
            float previewY = actualStartPos.y;
            Entity tempEntity = Entity.Null;
            bool tempHit = false;
            CheckRay(physicsWorld, finalCenter.x, finalCenter.z, ref previewY, ref tempEntity, ref tempHit);

            float snappedHighestY = (float)System.Math.Round(previewY / blockSize) * blockSize;

            float3 drawStartPos = actualStartPos;
            float3 drawEndPos = actualEndPos;
            drawStartPos.y = math.max(actualStartPos.y, snappedHighestY);
            drawEndPos.y = math.max(actualEndPos.y, snappedHighestY);

            // 도면 그리는 놈 호출!
            DrawGuideWireframe(drawStartPos, drawEndPos, guideHeight, currentBuildMode, blockSize);
        }

        bool isFKeyPressed = Input.GetKeyDown(KeyCode.F);
        bool isGKeyPressed = Input.GetKeyDown(KeyCode.G);

        if (isGuideActive && (isFKeyPressed || isGKeyPressed))
        {
            bool isGhost = isFKeyPressed;

            if (LogManager.Instance != null)
            {
                string toolName = GetToolName(currentBuildMode);
                int height = (int)math.round(guideHeight);
                string actionStr = isGhost ? "Key_F" : "Key_G";
                string statusStr = isGhost ? "Preview_Hologram" : "Build_Complete";

                int safeCenterX = (int)finalCenter.x;
                int safeCenterZ = (int)finalCenter.z;
                string centerStr = $"[{safeCenterX}, {safeCenterZ}]";

                // 🚨 [현장 줄자 투입!] 드래그한 시작점과 끝점의 거리를 재서 실제 크기(가로/세로)를 뽑아냅니다!
                float sizeX = math.abs(actualEndPos.x - actualStartPos.x) + blockSize;
                float sizeZ = math.abs(actualEndPos.z - actualStartPos.z) + blockSize;

                // LogManager한테 크기(sizeX, sizeZ)까지 같이 넘겨서 장부에 적으라고 짬때립니다.
                LogManager.Instance.AddLog(toolName, height, actionStr, statusStr, centerStr, sizeX, sizeZ);
            }

            var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
            foreach (var (ghostTag, entity) in SystemAPI.Query<RefRO<GhostBlockTag>>().WithEntityAccess())
            {
                ecb.DestroyEntity(entity);
            }

            float highestY = -9999f;
            Entity hitEntity = Entity.Null;
            bool hitAnything = false;

            float3 startXZ = new float3(actualStartPos.x, 0, actualStartPos.z);
            float3 endXZ = new float3(actualEndPos.x, 0, actualEndPos.z);
            float distance = math.distance(startXZ, endXZ);

            // ⭐ 짓는 놈도 이제 1.0이 아니라 blockSize(3.0f) 간격으로 타설합니다!
            if (currentBuildMode == 1)
            {
                float3 dir = distance < 0.1f ? new float3(1, 0, 0) : math.normalize(endXZ - startXZ);
                int steps = (int)math.max(1, math.round(distance / blockSize));
                for (int i = 0; i <= steps; i++)
                {
                    float3 p = startXZ + dir * (i * (distance / math.max(1, steps)));
                    CheckRay(physicsWorld, p.x, p.z, ref highestY, ref hitEntity, ref hitAnything);
                }
            }
            else if (currentBuildMode == 2 || currentBuildMode == 4)
            {
                float minX = math.min(startXZ.x, endXZ.x); float maxX = math.max(startXZ.x, endXZ.x);
                float minZ = math.min(startXZ.z, endXZ.z); float maxZ = math.max(startXZ.z, endXZ.z);
                for (float x = minX; x <= maxX + 0.1f; x += blockSize) // 간격 3.0f로 벌림!
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += blockSize)
                    {
                        if (currentBuildMode == 2)
                        {
                            if (x > minX + (blockSize * 0.5f) && x < maxX - (blockSize * 0.5f) && z > minZ + (blockSize * 0.5f) && z < maxZ - (blockSize * 0.5f)) continue;
                        }
                        CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                    }
                }
            }
            else if (currentBuildMode == 3 || currentBuildMode == 5)
            {
                float radius = distance / 2.0f;
                float3 center = (startXZ + endXZ) / 2.0f;
                float minX = center.x - radius; float maxX = center.x + radius;
                float minZ = center.z - radius; float maxZ = center.z + radius;
                for (float x = minX; x <= maxX + 0.1f; x += blockSize) // 간격 3.0f로 벌림!
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += blockSize)
                    {
                        float distSq = math.distancesq(new float3(x, 0, z), center);
                        if (distSq <= radius * radius)
                        {
                            if (currentBuildMode == 3 && distSq < (radius - blockSize * 0.5f) * (radius - blockSize * 0.5f)) continue;
                            CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                        }
                    }
                }
            }

            if (hitAnything)
            {
                float finalBuildY = math.max(highestY, actualStartPos.y);
                ExecuteBuild(ref state, spawnerData, actualStartPos, actualEndPos, finalBuildY, hitEntity, isGhost);

                if (!isGhost) isGuideActive = false;
            }
        }
    }

    private void ExecuteBuild(ref SystemState state, SpawnerData data, float3 actualStart, float3 actualEnd, float targetY, Entity hitEntity, bool isGhost)
    {
        bool hitExistingBlock = SystemAPI.HasComponent<BlockTag>(hitEntity);
        float3 hitEntityPos = hitExistingBlock ? SystemAPI.GetComponent<LocalTransform>(hitEntity).Position : float3.zero;

        switch (currentBuildMode)
        {
            case 1: BuildSolidWall(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 2: BuildEmptyFrame(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 3: BuildCircularPattern(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 4: BuildPyramid(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
            case 5: BuildCone(ref state, data, actualStart, actualEnd, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID, isGhost); break;
        }

        if (!isGhost) nextStructureID++;
    }

    private void CheckRay(PhysicsWorld physicsWorld, float x, float z, ref float highestY, ref Entity hitEntity, ref bool hitAnything)
    {
        float3 rayPos = new float3(x, 100f, z);
        RaycastInput rayInput = new RaycastInput { Start = rayPos, End = rayPos + new float3(0, -200f, 0), Filter = CollisionFilter.Default };
        if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
        {
            hitAnything = true;
            if (hit.Position.y > highestY) { highestY = hit.Position.y; hitEntity = hit.Entity; }
        }
    }

    // ⭐ 도면 그리는 놈도 blockSize를 넘겨받아서 1.5f 만큼 빵빵하게 감쌉니다!
    // ⭐ 도면 그리는 놈도 blockSize를 넘겨받아서 대각선 영점을 맞춥니다!
    private void DrawGuideWireframe(float3 start, float3 end, float heightParam, int mode, float blockSize)
    {
        Color color = Color.green;
        float floorHeight = blockSize;

        if (mode == 1 || mode == 2)
        {
            // 🚨 [대각선 45도 밀림 해결!] 
            // 블록 중심점이 모서리에 있기 때문에, -halfSize를 하지 않고 
            // 시작점은 그대로 두고 끝점만 +blockSize를 해줍니다!
            // 이렇게 하면 도면 전체가 대각선으로 쓱 이동해서 블록이랑 칼같이 맞습니다!
            float minX = math.min(start.x, end.x);
            float maxX = math.max(start.x, end.x) + blockSize;
            float minZ = math.min(start.z, end.z);
            float maxZ = math.max(start.z, end.z) + blockSize;

            float minY = start.y;
            float maxY = start.y + (heightParam * floorHeight);

            Vector3 p1 = new Vector3(minX, minY, minZ);
            Vector3 p2 = new Vector3(maxX, minY, minZ);
            Vector3 p3 = new Vector3(maxX, minY, maxZ);
            Vector3 p4 = new Vector3(minX, minY, maxZ);

            Debug.DrawLine(p1, p2, color); Debug.DrawLine(p2, p3, color);
            Debug.DrawLine(p3, p4, color); Debug.DrawLine(p4, p1, color);

            if (heightParam > 0)
            {
                Vector3 t1 = new Vector3(minX, maxY, minZ);
                Vector3 t2 = new Vector3(maxX, maxY, minZ);
                Vector3 t3 = new Vector3(maxX, maxY, maxZ);
                Vector3 t4 = new Vector3(minX, maxY, maxZ);

                Debug.DrawLine(t1, t2, color); Debug.DrawLine(t2, t3, color);
                Debug.DrawLine(t3, t4, color); Debug.DrawLine(t4, t1, color);

                Debug.DrawLine(p1, t1, color); Debug.DrawLine(p2, t2, color);
                Debug.DrawLine(p3, t3, color); Debug.DrawLine(p4, t4, color);
            }
        }
        else if (mode == 3 || mode == 4 || mode == 5)
        {
            float3 center = (start + end) / 2f;

            // 🚨 [원형 도면 대각선 해결!] 원형 도면도 모서리 쏠림에 맞춰서 중심축을 대각선으로 밀어줍니다!
            center.x += (blockSize / 2f);
            center.z += (blockSize / 2f);

            // 사이즈(반경)는 기존과 똑같이 유지!
            float radius = (math.distance(start, end) / 2f) + (blockSize / 2f);

            float minY = start.y;
            float maxY = start.y + (heightParam * floorHeight);

            int segments = 24; float angleStep = (2f * math.PI) / segments;
            Vector3 prev = center + new float3(radius, 0, 0);
            prev.y = minY;

            for (int i = 1; i <= segments; i++)
            {
                Vector3 next = center + new float3(math.cos(i * angleStep) * radius, 0, math.sin(i * angleStep) * radius);
                next.y = minY;
                Debug.DrawLine(prev, next, color);
                prev = next;
            }
            if (heightParam > 0)
            {
                Debug.DrawLine(new Vector3(center.x, minY, center.z), new Vector3(center.x, maxY, center.z), color);
            }
        }
    }

    private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));
        ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f)));
    }
}