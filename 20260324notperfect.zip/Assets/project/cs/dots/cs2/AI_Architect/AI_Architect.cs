﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.IO;
using System.Text;

public class AI_Architect : MonoBehaviour
{
    // 🚨 십장님의 구글 제미나이 API 키 (외부 공유 시 반드시 삭제!)
    [Header("Google Gemini API 설정")]
    public string apiKey = "카톡봐라";

    // 🚨 다중 주파수 채널 (1순위, 2순위, 3순위) - 하나 죽어도 알아서 다음 걸로 연결!
    private string[] apiEndpoints = new string[]
    {
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", // 1순위: 최신 초고속 (가장 똑똑함)
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent", // 2순위: 구형 고속
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent"    // 3순위: 옛날 주파수
    };

    // ==========================================================
    // 1. [AI 뇌에 박아넣을 수식 매뉴얼 + 십장님 설계 철학]
    // ==========================================================
    private string GetConstructionManual()
    {
        return @"
[AI ARCHITECT MATHEMATICAL RULES & DESIGN PHILOSOPHY]
You are a coordinate calculator for a 3D voxel builder. You must strictly follow these rules.

1. THE GOLDEN GRID RULE (blockSize = 3.0):
   - All blocks are 3.0 x 3.0 x 3.0.
   - Block centers (X, Y, Z) MUST ALWAYS end in .5 or .0 based on the formula: `(Integer * 3.0) + 1.5` or `(Integer * 3.0) - 1.5`.
   - Valid coordinates: -4.5, -1.5, 1.5, 4.5, 7.5, 10.5, etc. DO NOT output values like 0.0, 1.0, or 2.5.

2. VERTICAL (Y-AXIS) FORMULA:
   - Y_center = Base_Floor_Y + (Floor_Level * 3.0) + 1.5
   - Current Base Ground: Y = -3.0
   - 1st Floor blocks (Level 0): Y = -1.5
   - 2nd Floor blocks (Level 1): Y = 1.5
   - 3rd Floor blocks (Level 2): Y = 4.5

3. TOOL LOGIC:
   - ""1_Solid_Wall"": Solid support/pillar. Use this for maximum reinforcement.
   - ""2_Empty_Frame"": Hollow frame. Good for basic structure.
   - ""3_Circular_Pattern"", ""4_Pyramid"", ""5_Cone"".

4. 🚨 YOUR MISSION (3 STRICT OPTIONS):
   Read the [CURRENT BUILDING STATE]. Generate exactly 3 options based on the user's prompt, strictly following this design philosophy:
   - Option_A (Highest Reproduction): Focus on continuing the exact style and layout of the current lower floor perfectly.
   - Option_B (Maximum Reinforcement / Low Stress): Focus heavily on structural stability. Add extra pillars (""1_Solid_Wall"") or internal supports to completely eliminate structural stress.
   - Option_C (Moderate Reinforcement): A balanced mix. Maintain the original design but add moderate structural reinforcements where necessary.

5. 🚨 OUTPUT FORMAT (CRITICAL STRICT RULES):
   - DO NOT write any explanations, greetings, or conversational text.
   - DO NOT use markdown code blocks (like ```json). Just output raw JSON text starting with { and ending with }.
   - The JSON MUST exactly match this schema with exactly 3 keys: Option_A, Option_B, Option_C.
   {
     ""Option_A"": [ { ""tool"": ""2_Empty_Frame"", ""height"": 5, ""centerXYZ"": ""[-10.50, 1.50, 76.50]"" } ],
     ""Option_B"": [ { ""tool"": ""1_Solid_Wall"", ""height"": 5, ""centerXYZ"": ""[-10.50, 1.50, 76.50]"" } ],
     ""Option_C"": [ { ""tool"": ""2_Empty_Frame"", ""height"": 5, ""centerXYZ"": ""[-10.50, 1.50, 76.50]"" } ]
   }
";
    }

    // ==========================================================
    // 2. [주문 접수처]
    // ==========================================================
    public void OrderBlueprintFromAI(string userPrompt)
    {
        StartCoroutine(CallGemini(userPrompt));
    }

    // ==========================================================
    // 3. [통신 발사대] : 십장님 특허 "될 때까지 채널 돌리기!"
    // ==========================================================
    private IEnumerator CallGemini(string userPrompt)
    {
        string tempFilePath = Path.Combine(Application.dataPath, "temp", "Temp_Current_Building.json");
        string currentBuildingData = "No previous blocks. This is a new construction.";

        if (File.Exists(tempFilePath))
        {
            currentBuildingData = File.ReadAllText(tempFilePath);
            Debug.Log("📄 [AI 무전] 현재 타설 중인 Temp 장부(1층 도면) 확보 완료!");
        }
        else
        {
            Debug.LogWarning("⚠️ [AI 무전] Temp 장부가 없습니다. 맨땅에 헤딩(새 건물) 설계로 간주합니다.");
        }

        string aiManual = GetConstructionManual();
        string fullInstruction = aiManual +
                                 "\n\n[CURRENT BUILDING STATE]\n" + currentBuildingData +
                                 "\n\n[USER ORDER]\n" + userPrompt;

        string safePrompt = fullInstruction.Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
        string jsonBody = "{\"contents\": [{\"parts\": [{\"text\": \"" + safePrompt + "\"}]}]}";
        byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonBody);

        bool isSuccess = false;

        for (int i = 0; i < apiEndpoints.Length; i++)
        {
            string url = apiEndpoints[i] + "?key=" + apiKey;
            string modelName = apiEndpoints[i].Substring(apiEndpoints[i].LastIndexOf('/') + 1);
            Debug.Log($"🚀 [AI 무전] {i + 1}번 채널({modelName})로 발주 시도 중...");

            using (UnityWebRequest request = new UnityWebRequest(url, "POST"))
            {
                request.uploadHandler = new UploadHandlerRaw(bodyRaw);
                request.downloadHandler = new DownloadHandlerBuffer();
                request.SetRequestHeader("Content-Type", "application/json");

                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log($"✅ [AI 무전 성공] {i + 1}번 채널 접속 완료! 도면 하차 시작!");
                    ProcessAIBlueprint(request.downloadHandler.text);
                    isSuccess = true;
                    break;
                }
                else
                {
                    Debug.LogWarning($"⚠️ [AI 무전] {i + 1}번 채널 불발! 에러: {request.error} -> 바로 다음 주파수로 넘어갑니다!");
                }
            }
        }

        if (!isSuccess)
        {
            Debug.LogError("🚨 [AI 무전 대참사] 꽂아둔 채널이 전부 먹통입니다! API 키나 인터넷 연결을 확인하십쇼!");
        }
    }

    // ==========================================================
    // 4. [도면 검수장 & 창고 저장]
    // ==========================================================
    private void ProcessAIBlueprint(string jsonResponse)
    {
        Debug.Log("📦 [도면 원본 내용]: \n" + jsonResponse);

        // 🚨 십장님의 전용 창고 경로
        string directoryPath = Path.Combine(Application.dataPath, "ai_designs");

        if (!Directory.Exists(directoryPath))
        {
            Directory.CreateDirectory(directoryPath);
        }

        string fileName = "Gemini_Blueprint_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".json";
        string filePath = Path.Combine(directoryPath, fileName);

        File.WriteAllText(filePath, jsonResponse);

        Debug.Log($"💾 [도면 하차 완료] AI의 설계도가 전용 창고에 흠집 없이 저장되었습니다!\n경로: {filePath}");
    }

    // ==========================================================
    // 🚨 [방아쇠] : T키 스위치!
    // ==========================================================
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            Debug.Log("📡 [현장 무전] T키 입력 확인! AI에게 도면 발주 들어갑니다!");

            string myOrder = "현재 지어진 1층(Y=-1.5) 프레임 위치를 파악하고, 그 위인 2층(Y=1.5) 높이에 딱 맞는 새로운 프레임 도면 3가지를 짜와라!";

            OrderBlueprintFromAI(myOrder);
        }
    }
}