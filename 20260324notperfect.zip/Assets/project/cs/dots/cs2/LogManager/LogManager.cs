﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// 1. 단일 기록 (십장님 특허 3합축 기술 적용!)
[Serializable]
public class ActionLog
{
    public string time;
    public string tool;
    public string sizeXZH;   // 👈 [추가] 가로, 세로, 높이를 한 방에 압축!
    public string centerXYZ; // 👈 스포너가 넘겨준 진짜 3D 좌표 (Y값 층수 포함)
    public string action;
    public string status;
    public string pivotXYZ;  // 👈 (보너스) 기준점(노란블록) 좌표도 따로 남김
}

[Serializable]
public class ProjectAttempt
{
    public int Attempt;
    public string Start_Time;
    public string End_Time;
    public string Status;
    public List<ActionLog> Actions = new List<ActionLog>();
}

[Serializable]
public class DailyRawLog
{
    public string Date;
    public int Total_Attempts;
    public List<string> Reset_Timestamps = new List<string>();
    public List<ProjectAttempt> Projects_Details = new List<ProjectAttempt>();
}

[Serializable]
public class TempLog
{
    public string Notice = "현재 타설 중인 블록입니다. (R키 누르면 날아감)";
    public List<ActionLog> Current_Blocks = new List<ActionLog>();
}

[Serializable]
public class Blueprint
{
    public int Blueprint_ID;
    public string Saved_Time;
    public List<ActionLog> Blocks = new List<ActionLog>();
}

[Serializable]
public class MasterBlueprintLog
{
    public string Date;
    public int Total_Masterpieces;
    public List<Blueprint> Blueprints = new List<Blueprint>();
}

public class LogManager : MonoBehaviour
{
    public static LogManager Instance;

    private DailyRawLog rawDailyLog;
    private TempLog tempLogData;
    private MasterBlueprintLog masterLogData;
    private ProjectAttempt currentAttempt;

    private string rawFilePath;
    private string tempFilePath;
    private string masterFilePath;

    // 🚨 시뮬레이션 중앙(노란 블럭)의 위치를 알기 위한 피벗 참조
    private Transform simulationPivot;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        string dateStr = DateTime.Now.ToString("yyyyMMdd");
        string basePath = Application.dataPath;

        string historyDir = Path.Combine(basePath, "history");
        string tempDir = Path.Combine(basePath, "temp");
        string architectDir = Path.Combine(basePath, "architecture");

        if (!Directory.Exists(historyDir)) Directory.CreateDirectory(historyDir);
        if (!Directory.Exists(tempDir)) Directory.CreateDirectory(tempDir);
        if (!Directory.Exists(architectDir)) Directory.CreateDirectory(architectDir);

        rawFilePath = Path.Combine(historyDir, $"Log_Raw_{dateStr}.json");
        tempFilePath = Path.Combine(tempDir, "Temp_Current_Building.json");
        masterFilePath = Path.Combine(architectDir, $"Master_Blueprint_{dateStr}.json");

        LoadOrCreateLogs();
    }

    void Update()
    {
        // 🚨 실시간으로 씬에 있는 SimulationPivot(노란 블럭의 부모)을 찾습니다.
        if (simulationPivot == null)
        {
            GameObject pivotObj = GameObject.Find("SimulationPivot");
            if (pivotObj != null) simulationPivot = pivotObj.transform;
        }
    }

    void LoadOrCreateLogs()
    {
        if (File.Exists(rawFilePath)) rawDailyLog = JsonUtility.FromJson<DailyRawLog>(File.ReadAllText(rawFilePath));
        else rawDailyLog = new DailyRawLog { Date = DateTime.Now.ToString("yyyy-MM-dd") };

        if (File.Exists(masterFilePath)) masterLogData = JsonUtility.FromJson<MasterBlueprintLog>(File.ReadAllText(masterFilePath));
        else masterLogData = new MasterBlueprintLog { Date = DateTime.Now.ToString("yyyy-MM-dd") };

        tempLogData = new TempLog();
        SaveTempLog();

        if (rawDailyLog.Projects_Details.Count == 0 || rawDailyLog.Projects_Details[rawDailyLog.Projects_Details.Count - 1].Status != "In_Progress")
        {
            StartNewAttempt();
        }
        else
        {
            currentAttempt = rawDailyLog.Projects_Details[rawDailyLog.Projects_Details.Count - 1];
        }
    }

    void StartNewAttempt()
    {
        rawDailyLog.Total_Attempts++;
        currentAttempt = new ProjectAttempt { Attempt = rawDailyLog.Total_Attempts, Start_Time = DateTime.Now.ToString("HH:mm:ss"), Status = "In_Progress" };
        rawDailyLog.Projects_Details.Add(currentAttempt);
        SaveRawLog();
    }

    // 🚨 스포너가 넘겨준 줄자(sizeX, sizeZ)와 좌표(centerXYZ)를 정확하게 받아서 압축합니다!
    public void AddLog(string tool, int height, string action, string status, string centerXYZ, float sizeX, float sizeZ)
    {
        // 노란 블럭 피벗이 있으면 그 위치를 따로 기록합니다 (영점 조절용)
        Vector3 currentPivotPos = (simulationPivot != null) ? simulationPivot.position : Vector3.zero;
        string pivotString = $"[{currentPivotPos.x:F2}, {currentPivotPos.y:F2}, {currentPivotPos.z:F2}]";

        ActionLog newLog = new ActionLog
        {
            time = DateTime.Now.ToString("HH:mm:ss"),
            tool = tool,
            sizeXZH = $"[{sizeX:F1}, {sizeZ:F1}, {height}]", // 👈 [핵심] 십장님 특허 기술 적용!
            centerXYZ = centerXYZ, // 👈 [수정 완료] 피벗이 아니라 진짜 블록 좌표를 적습니다!
            action = action,
            status = status,
            pivotXYZ = pivotString // 👈 기준점은 보너스로 따로 저장
        };

        currentAttempt.Actions.Add(newLog);
        SaveRawLog();

        if (action == "Key_G" || status == "Build_Complete")
        {
            tempLogData.Current_Blocks.Add(newLog);
            SaveTempLog();
        }
    }

    public void OnPressRKey()
    {
        string nowTime = DateTime.Now.ToString("HH:mm:ss");
        currentAttempt.End_Time = nowTime;
        currentAttempt.Status = "Reset";
        rawDailyLog.Reset_Timestamps.Add($"Attempt {currentAttempt.Attempt}: {nowTime} (Reset)");
        SaveRawLog();
        StartNewAttempt();
        tempLogData.Current_Blocks.Clear();
        SaveTempLog();
    }

    public void SaveToMaster()
    {
        if (tempLogData.Current_Blocks.Count == 0) return;
        string nowTime = DateTime.Now.ToString("HH:mm:ss");
        masterLogData.Total_Masterpieces++;
        Blueprint newBlueprint = new Blueprint { Blueprint_ID = masterLogData.Total_Masterpieces, Saved_Time = nowTime, Blocks = new List<ActionLog>(tempLogData.Current_Blocks) };
        masterLogData.Blueprints.Add(newBlueprint);
        SaveMasterLog();
        currentAttempt.End_Time = nowTime;
        currentAttempt.Status = "Success";
        rawDailyLog.Reset_Timestamps.Add($"Attempt {currentAttempt.Attempt}: {nowTime} (Success)");
        SaveRawLog();
        StartNewAttempt();
        Debug.Log("🎉 마스터 도면집에 십장님 특허 장부 도장 쾅!");
    }

    private void SaveRawLog() { File.WriteAllText(rawFilePath, JsonUtility.ToJson(rawDailyLog, true)); }
    private void SaveTempLog() { File.WriteAllText(tempFilePath, JsonUtility.ToJson(tempLogData, true)); }
    private void SaveMasterLog() { File.WriteAllText(masterFilePath, JsonUtility.ToJson(masterLogData, true)); }
}