﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Rendering;
using UnityEngine;
using System.IO;
using System;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;

// ⭐ 스트레스 초기화를 위한 초경량 Job
[BurstCompile]
public partial struct ResetStressJob : IJobEntity
{
    public void Execute(ref BlockStress stress)
    {
        stress.TargetStress = 0f;
    }
}

// ⭐ 조인트 응력을 멀티코어로 미친듯이 빠르게 계산하는 Job
[BurstCompile]
public partial struct CalculateJointStressJob : IJobEntity
{
    [ReadOnly] public ComponentLookup<LocalTransform> TransformLookup;
    public ComponentLookup<BlockStress> StressLookup;
    public bool IsWeightScanMode;

    public void Execute(in PhysicsConstrainedBodyPair pair, in PhysicsJoint joint)
    {
        Entity entityA = pair.EntityA;
        Entity entityB = pair.EntityB;

        if (TransformLookup.HasComponent(entityA) && TransformLookup.HasComponent(entityB))
        {
            var transA = TransformLookup[entityA];
            var transB = TransformLookup[entityB];

            float3 pivotA = math.transform(new RigidTransform(transA.Rotation, transA.Position), joint.BodyAFromJoint.Position);
            float3 pivotB = math.transform(new RigidTransform(transB.Rotation, transB.Position), joint.BodyBFromJoint.Position);
            float3 deltaDisplacement = pivotA - pivotB;

            float jointStressResult = 0f;

            if (IsWeightScanMode)
            {
                float axialStiffness = 15.0f;
                jointStressResult = math.abs(deltaDisplacement.y) * axialStiffness;
            }
            else
            {
                float shearStiffness = 10.0f;
                float bendingStiffness = 15.0f;
                float dotProduct = math.abs(math.dot(transA.Rotation.value, transB.Rotation.value));
                float angleDiff = 2.0f * math.acos(math.clamp(dotProduct, -1f, 1f));
                float bendingStress = angleDiff * bendingStiffness;
                float shearStress = math.length(new float2(deltaDisplacement.x, deltaDisplacement.z)) * shearStiffness;

                jointStressResult = bendingStress + shearStress;
            }

            // ⭐ Job 안에서는 여러 스레드가 동시에 같은 BlockStress에 접근할 수 있으므로, 원자적(Atomic) 연산은 피하고 각 엔티티에 직접 적용 (최적화를 위해 단순 덮어쓰기 허용)
            // 완벽한 스레드 안전성을 원하면 NativeStream을 써야 하지만, 시각화 용도이므로 이 정도 병목은 허용합니다.
            if (StressLookup.HasComponent(entityA))
            {
                var stressA = StressLookup[entityA];
                stressA.TargetStress += jointStressResult;
                StressLookup[entityA] = stressA;
            }
            if (StressLookup.HasComponent(entityB))
            {
                var stressB = StressLookup[entityB];
                stressB.TargetStress += jointStressResult;
                StressLookup[entityB] = stressB;
            }
        }
    }
}

// ⭐ 외부 하중 및 지진을 멀티코어로 적용하는 Job
[BurstCompile]
public partial struct ApplyExternalLoadJob : IJobEntity
{
    public bool IsWeightScanMode;
    public float DeltaTime;
    public float QuakeX;
    public float QuakeZ;
    public float BaseWeight;
    public float DynamicSensitivity;

    public void Execute(in LocalTransform transform, ref BlockStress stress, ref PhysicsVelocity velRW)
    {
        float additionalStress = 0f;

        if (IsWeightScanMode)
        {
            additionalStress = BaseWeight;
        }
        else
        {
            velRW.Linear += new float3(QuakeX, 0, QuakeZ) * DeltaTime;
            additionalStress = math.lengthsq(velRW.Linear) * DynamicSensitivity;
        }
        stress.TargetStress += additionalStress;
    }
}

// ⭐ 평균치 계산을 위한 Job
[BurstCompile]
public partial struct SmoothStressJob : IJobEntity
{
    public float DeltaTime;
    public float SmoothSpeed;

    public void Execute(ref BlockStress stress)
    {
        stress.SmoothedStress = math.lerp(stress.SmoothedStress, stress.TargetStress, DeltaTime * SmoothSpeed);
    }
}


[UpdateInGroup(typeof(SimulationSystemGroup))]
[UpdateAfter(typeof(FixedStepSimulationSystemGroup))]
public partial struct StressVisualizationSystem : ISystem
{
    private float scanTimer;
    private bool isScanning;
    private bool needsColorUpdate;
    private bool isWeightScanMode;

    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<BlockStress>();
    }

    public void OnUpdate(ref SystemState state)
    {
        // 1. 입력 감지부 (V / B)
        if (Input.GetKeyDown(KeyCode.V))
        {
            scanTimer = 5.0f;
            isScanning = true;
            isWeightScanMode = true;
            needsColorUpdate = false;

            // 색깔 초기화 (Job으로 안 빼고 메인 스레드에서 한 번만 돌려도 무방함)
            foreach (var color in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>>())
                color.ValueRW.Value = new float4(1f, 1f, 1f, 1f);

            Debug.Log("⚖️ [무게 진단 (리얼 모드)] 5초간 실제 관절의 수직 압축량을 정밀 분석합니다...");
        }

        if (Input.GetKeyDown(KeyCode.B))
        {
            scanTimer = 5.0f;
            isScanning = true;
            isWeightScanMode = false;
            needsColorUpdate = false;

            foreach (var color in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>>())
                color.ValueRW.Value = new float4(1f, 1f, 1f, 1f);

            Debug.Log("🌪️ [진동대 시험] 5초간 인공 지진을 발생시켜 구조물의 비틀림을 분석합니다...");
        }

        // 2. 타이머 체크
        if (isScanning)
        {
            scanTimer -= SystemAPI.Time.DeltaTime;
            if (scanTimer <= 0f)
            {
                isScanning = false;
                needsColorUpdate = true;
                Debug.Log("✅ [스캔 완료] 데이터를 엑셀로 추출하고 색상을 렌더링합니다!");
            }
        }

        // ⭐ 3. 셔터 내리기! (계산 중도 아니고 색칠할 타이밍도 아니면 시스템 올 스톱!)
        if (!isScanning && !needsColorUpdate) return;


        // =========================================================
        // ⚙️ [정밀 해석 모드] 멀티코어 Job System 가동!
        // =========================================================
        if (isScanning)
        {
            // 1. 스트레스 초기화 Job
            state.Dependency = new ResetStressJob().ScheduleParallel(state.Dependency);

            // 2. 조인트 스트레스 계산 Job
            var transformLookup = SystemAPI.GetComponentLookup<LocalTransform>(true);
            var stressLookup = SystemAPI.GetComponentLookup<BlockStress>(false); // 덮어쓰기를 위해 RW 권한 필요

            var jointJob = new CalculateJointStressJob
            {
                TransformLookup = transformLookup,
                StressLookup = stressLookup,
                IsWeightScanMode = isWeightScanMode
            };
            // ⚠️ 조인트 Job은 ComponentLookup 동시 접근 때문에 ScheduleParallel 대신 Schedule 로 단일 스레드 비동기 처리합니다. (그래도 기존보다 훨씬 빠름)
            state.Dependency = jointJob.Schedule(state.Dependency);

            // 3. 외부 하중 / 지진 Job
            float time = (float)SystemAPI.Time.ElapsedTime;
            float quakePower = 5.0f;

            var externalLoadJob = new ApplyExternalLoadJob
            {
                IsWeightScanMode = isWeightScanMode,
                DeltaTime = SystemAPI.Time.DeltaTime,
                QuakeX = !isWeightScanMode ? math.sin(time * 35f) * quakePower : 0f,
                QuakeZ = !isWeightScanMode ? math.cos(time * 28f) * quakePower : 0f,
                BaseWeight = 1.0f,
                DynamicSensitivity = 0.5f
            };
            state.Dependency = externalLoadJob.ScheduleParallel(state.Dependency);

            // 4. 평균화 Job
            var smoothJob = new SmoothStressJob
            {
                DeltaTime = SystemAPI.Time.DeltaTime,
                SmoothSpeed = 3f
            };
            state.Dependency = smoothJob.ScheduleParallel(state.Dependency);
        }

        // =========================================================
        // 🎨 [진단 완료] 렌더링 & CSV 리포트 출력
        // =========================================================
        if (needsColorUpdate)
        {
            // 이 부분은 5초에 딱 한 번만 도는 코드이므로 메인 스레드에서 돌아도 무방합니다.
            state.Dependency.Complete(); // Job 연산이 완전히 끝날 때까지 대기

            float yieldLimit = isWeightScanMode ? 5.0f : 8.0f;
            string reportType = isWeightScanMode ? "WEIGHT" : "SHAKE";
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string filePath = Path.Combine(Application.dataPath, $"{reportType}_Report_{timestamp}.csv");

            // ⭐ 파일 I/O는 여전히 뚝 끊김을 유발할 수 있습니다. 나중에 이 부분만 비동기(Async)로 뺄 수 있습니다.
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine($"BlockID,PosX,PosY,PosZ,{reportType}_Stress,RiskLevel");

                int blockCount = 0;
                foreach (var (stress, color, transform) in SystemAPI.Query<RefRO<BlockStress>, RefRW<URPMaterialPropertyBaseColor>, RefRO<LocalTransform>>())
                {
                    float currentStress = stress.ValueRO.SmoothedStress;
                    float3 pos = transform.ValueRO.Position;

                    float t = math.clamp(currentStress / yieldLimit, 0f, 1f);

                    if (isWeightScanMode)
                    {
                        color.ValueRW.Value = new float4(1f, 1f - t, 1f - t, 1f);
                    }
                    else
                    {
                        color.ValueRW.Value = new float4(1f, 1f - t, 1f, 1f);
                    }

                    string risk = t >= 0.8f ? "DANGER" : (t >= 0.5f ? "WARNING" : "SAFE");
                    writer.WriteLine($"{blockCount},{pos.x:F2},{pos.y:F2},{pos.z:F2},{currentStress:F2},{risk}");

                    blockCount++;
                }
            }

            Debug.Log($"📁 리포트 저장 완료: {filePath}");
            needsColorUpdate = false;
            // 셔터 완벽히 내려감!
        }
    }
}