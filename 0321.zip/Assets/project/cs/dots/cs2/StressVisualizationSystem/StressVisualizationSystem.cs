﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Rendering;
using UnityEngine;
using System.IO;
using System;

[UpdateInGroup(typeof(SimulationSystemGroup))]
[UpdateAfter(typeof(FixedStepSimulationSystemGroup))]
public partial struct StressVisualizationSystem : ISystem
{
    private float scanTimer;
    private bool isScanning;
    private bool needsColorUpdate;
    private bool isWeightScanMode;

    public void OnUpdate(ref SystemState state)
    {
        if (Input.GetKeyDown(KeyCode.V))
        {
            scanTimer = 5.0f;
            isScanning = true;
            isWeightScanMode = true;
            needsColorUpdate = false;
            foreach (var color in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>>())
                color.ValueRW.Value = new float4(1f, 1f, 1f, 1f);
            Debug.Log("⚖️ [무게 진단 (리얼 모드)] 5초간 실제 관절의 수직 압축량을 정밀 분석합니다...");
        }

        if (Input.GetKeyDown(KeyCode.B))
        {
            scanTimer = 5.0f;
            isScanning = true;
            isWeightScanMode = false;
            needsColorUpdate = false;
            foreach (var color in SystemAPI.Query<RefRW<URPMaterialPropertyBaseColor>>())
                color.ValueRW.Value = new float4(1f, 1f, 1f, 1f);
            Debug.Log("🌪️ [진동대 시험] 5초간 인공 지진을 발생시켜 구조물의 비틀림을 분석합니다...");
        }

        if (isScanning)
        {
            scanTimer -= SystemAPI.Time.DeltaTime;
            if (scanTimer <= 0f)
            {
                isScanning = false;
                needsColorUpdate = true;
                Debug.Log("✅ [스캔 완료] 데이터를 엑셀로 추출하고 색상을 렌더링합니다!");
            }
        }

        if (!isScanning && !needsColorUpdate) return;

        state.Dependency.Complete();

        // =========================================================
        // ⚙️ [정밀 해석 모드] V/B 모드 연산 (MSG 제거 완료!)
        // =========================================================
        if (isScanning)
        {
            var transformLookup = SystemAPI.GetComponentLookup<LocalTransform>(true);
            var stressLookup = SystemAPI.GetComponentLookup<BlockStress>(false);

            foreach (var stress in SystemAPI.Query<RefRW<BlockStress>>())
            {
                stress.ValueRW.TargetStress = 0f;
            }

            // ⭐ MSG 관련 변수(FlowRate) 완전 삭제!

            // 1. 조인트 응력 계산 (순수 물리적 찢어짐만 계산)
            foreach (var (pair, joint) in SystemAPI.Query<RefRO<PhysicsConstrainedBodyPair>, RefRO<PhysicsJoint>>())
            {
                Entity entityA = pair.ValueRO.EntityA;
                Entity entityB = pair.ValueRO.EntityB;

                if (transformLookup.HasComponent(entityA) && transformLookup.HasComponent(entityB))
                {
                    var transA = transformLookup[entityA];
                    var transB = transformLookup[entityB];

                    float3 pivotA = math.transform(new RigidTransform(transA.Rotation, transA.Position), joint.ValueRO.BodyAFromJoint.Position);
                    float3 pivotB = math.transform(new RigidTransform(transB.Rotation, transB.Position), joint.ValueRO.BodyBFromJoint.Position);
                    float3 deltaDisplacement = pivotA - pivotB;

                    float jointStressResult = 0f;

                    if (isWeightScanMode)
                    {
                        // ⚖️ 리얼리티를 위해 민감도를 15로 대폭 상승!
                        float axialStiffness = 15.0f;
                        jointStressResult = math.abs(deltaDisplacement.y) * axialStiffness;
                    }
                    else
                    {
                        // 🌪️ 흔들림 감지도 예민하게 조정!
                        float shearStiffness = 10.0f;
                        float bendingStiffness = 15.0f;

                        float dotProduct = math.abs(math.dot(transA.Rotation.value, transB.Rotation.value));
                        float angleDiff = 2.0f * math.acos(math.clamp(dotProduct, -1f, 1f));
                        float bendingStress = angleDiff * bendingStiffness;
                        float shearStress = math.length(new float2(deltaDisplacement.x, deltaDisplacement.z)) * shearStiffness;

                        jointStressResult = bendingStress + shearStress;
                    }

                    // ⭐ 가짜 하중 전파(복사) 로직 완전 삭제! 정직하게 자기 데미지만 먹습니다.

                    if (stressLookup.HasComponent(entityA))
                    {
                        var stressA = stressLookup[entityA];
                        stressA.TargetStress += jointStressResult;
                        stressLookup[entityA] = stressA;
                    }
                    if (stressLookup.HasComponent(entityB))
                    {
                        var stressB = stressLookup[entityB];
                        stressB.TargetStress += jointStressResult;
                        stressLookup[entityB] = stressB;
                    }
                }
            }

            // 2. 외부 하중 및 인공 지진(진동대) 발생기
            float baseWeight = 1.0f;
            float dynamicSensitivity = 0.5f;

            float quakeX = 0f;
            float quakeZ = 0f;

            if (!isWeightScanMode)
            {
                float time = (float)SystemAPI.Time.ElapsedTime;
                float quakePower = 5.0f;
                quakeX = math.sin(time * 35f) * quakePower;
                quakeZ = math.cos(time * 28f) * quakePower;
            }

            foreach (var (transform, stress, velRW, entity) in SystemAPI.Query<RefRO<LocalTransform>, RefRW<BlockStress>, RefRW<PhysicsVelocity>>().WithAll<BlockTag>().WithEntityAccess())
            {
                float additionalStress = 0f;

                if (isWeightScanMode)
                {
                    additionalStress = baseWeight;
                }
                else
                {
                    velRW.ValueRW.Linear += new float3(quakeX, 0, quakeZ) * SystemAPI.Time.DeltaTime;
                    additionalStress = math.lengthsq(velRW.ValueRO.Linear) * dynamicSensitivity;
                }
                stress.ValueRW.TargetStress += additionalStress;
            }

            // 3. 데이터 평균화 
            float dt = SystemAPI.Time.DeltaTime;
            float smoothSpeed = 3f;
            foreach (var stress in SystemAPI.Query<RefRW<BlockStress>>())
            {
                stress.ValueRW.SmoothedStress = math.lerp(stress.ValueRO.SmoothedStress, stress.ValueRO.TargetStress, dt * smoothSpeed);
            }
        }

        // =========================================================
        // 🎨 [진단 완료] 렌더링 & CSV 리포트 출력
        // =========================================================
        if (needsColorUpdate)
        {
            // 리얼 모드에 맞춰 게이지 통(한계치)을 조정
            float yieldLimit = isWeightScanMode ? 5.0f : 8.0f;
            string reportType = isWeightScanMode ? "WEIGHT" : "SHAKE";

            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string filePath = Path.Combine(Application.dataPath, $"{reportType}_Report_{timestamp}.csv");

            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine($"BlockID,PosX,PosY,PosZ,{reportType}_Stress,RiskLevel");

                int blockCount = 0;
                foreach (var (stress, color, transform) in SystemAPI.Query<RefRO<BlockStress>, RefRW<URPMaterialPropertyBaseColor>, RefRO<LocalTransform>>())
                {
                    float currentStress = stress.ValueRO.SmoothedStress;
                    float3 pos = transform.ValueRO.Position;

                    float t = math.clamp(currentStress / yieldLimit, 0f, 1f);

                    if (isWeightScanMode)
                    {
                        color.ValueRW.Value = new float4(1f, 1f - t, 1f - t, 1f);
                    }
                    else
                    {
                        color.ValueRW.Value = new float4(1f, 1f - t, 1f, 1f);
                    }

                    string risk = t >= 0.8f ? "DANGER" : (t >= 0.5f ? "WARNING" : "SAFE");
                    writer.WriteLine($"{blockCount},{pos.x:F2},{pos.y:F2},{pos.z:F2},{currentStress:F2},{risk}");

                    blockCount++;
                }
            }

            needsColorUpdate = false;
        }
    }
}