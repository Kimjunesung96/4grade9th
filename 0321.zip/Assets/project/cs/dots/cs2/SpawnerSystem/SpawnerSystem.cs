﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Collections;
using Unity.Rendering;

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct SpawnerSystem : ISystem
{
    private float3 dragStartPos;
    private float3 dragEndPos;
    private int currentBuildMode;
    private float guideHeight;
    private bool isGuideActive;
    private int nextStructureID;

    private NativeList<BlobAssetReference<Unity.Physics.Collider>> _createdColliders;

    public void OnCreate(ref SystemState state)
    {
        currentBuildMode = 1;
        guideHeight = 1f;
        isGuideActive = false;
        nextStructureID = 1;
        _createdColliders = new NativeList<BlobAssetReference<Unity.Physics.Collider>>(Allocator.Persistent);
    }

    public void OnDestroy(ref SystemState state)
    {
        if (_createdColliders.IsCreated)
        {
            foreach (var col in _createdColliders) { if (col.IsCreated) col.Dispose(); }
            _createdColliders.Dispose();
        }
    }

    public void OnUpdate(ref SystemState state)
    {
        if (!UnityEngine.Application.isPlaying || Camera.main == null) return;

        // ⭐ 설계도 데이터를 쓰기 가능(RW)하게 가져옵니다.
        if (!SystemAPI.HasSingleton<BuilderStateData>()) return;
        var builderState = SystemAPI.GetSingletonRW<BuilderStateData>();

        if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsSingleton)) return;

        SpawnerData spawnerData = default;
        bool hasSpawner = false;
        foreach (var data in SystemAPI.Query<RefRO<SpawnerData>>())
        {
            spawnerData = data.ValueRO;
            hasSpawner = true;
            break;
        }
        if (!hasSpawner) return;

        PhysicsWorld physicsWorld = physicsSingleton.PhysicsWorld;

        // ⭐ 1. 휠 조작 및 층수 조절 로그 복구
        if (Input.mouseScrollDelta.y != 0)
        {
            builderState.ValueRW.GuideHeight += Input.mouseScrollDelta.y;
            if (builderState.ValueRW.GuideHeight < 1f) builderState.ValueRW.GuideHeight = 1f;
            Debug.Log($"[층수 조절] 현재 층수: {builderState.ValueRW.GuideHeight}층 (모드: {builderState.ValueRW.CurrentMode}번)");
        }

        // ⭐ 2. 모드 변경 조작 및 로그 복구
        if (Input.GetKeyDown(KeyCode.Alpha1)) { builderState.ValueRW.CurrentMode = 1; Debug.Log("[모드 변경] 1번: 수직 벽"); }
        if (Input.GetKeyDown(KeyCode.Alpha2)) { builderState.ValueRW.CurrentMode = 2; Debug.Log("[모드 변경] 2번: 수평 프레임"); }
        if (Input.GetKeyDown(KeyCode.Alpha3)) { builderState.ValueRW.CurrentMode = 3; Debug.Log("[모드 변경] 3번: 수평 원형"); }
        if (Input.GetKeyDown(KeyCode.Alpha4)) { builderState.ValueRW.CurrentMode = 4; Debug.Log("[모드 변경] 4번: 피라미드"); }
        if (Input.GetKeyDown(KeyCode.Alpha5)) { builderState.ValueRW.CurrentMode = 5; Debug.Log("[모드 변경] 5번: 원뿔"); }
        if (Input.GetKeyDown(KeyCode.Alpha6)) { builderState.ValueRW.CurrentMode = 6; Debug.Log("[모드 변경] 6번: 모터"); }

        // 로컬 변수에 설계도 값 동기화
        currentBuildMode = builderState.ValueRO.CurrentMode;
        guideHeight = builderState.ValueRO.GuideHeight;
        dragStartPos = builderState.ValueRO.GuideStartPos;
        dragEndPos = builderState.ValueRO.GuideEndPos;

        isGuideActive = math.lengthsq(dragStartPos) > 0.001f || math.lengthsq(dragEndPos) > 0.001f;

        if (isGuideActive) DrawGuideWireframe(dragStartPos, dragEndPos, guideHeight, currentBuildMode);

        // 건설 확정 (F키)
        if (isGuideActive && Input.GetKeyDown(KeyCode.F))
        {
            float highestY = -9999f;
            Entity hitEntity = Entity.Null;
            bool hitAnything = false;
            float blockSize = 3.0f;

            float3 startXZ = new float3(dragStartPos.x, 0, dragStartPos.z);
            float3 endXZ = new float3(dragEndPos.x, 0, dragEndPos.z);
            float distance = math.distance(startXZ, endXZ);

            if (currentBuildMode == 1)
            {
                float3 dir = distance < 0.1f ? new float3(1, 0, 0) : math.normalize(endXZ - startXZ);
                int steps = (int)math.max(1, math.round(distance / (blockSize * 0.5f)));
                for (int i = 0; i <= steps; i++)
                {
                    float3 p = startXZ + dir * (i * (distance / math.max(1, steps)));
                    CheckRay(physicsWorld, p.x, p.z, ref highestY, ref hitEntity, ref hitAnything);
                }
            }
            // ... (나머지 모드별 CheckRay 로직은 동일) ...
            else if (currentBuildMode == 2 || currentBuildMode == 4)
            {
                float minX = math.min(startXZ.x, endXZ.x); float maxX = math.max(startXZ.x, endXZ.x);
                float minZ = math.min(startXZ.z, endXZ.z); float maxZ = math.max(startXZ.z, endXZ.z);
                for (float x = minX; x <= maxX + 0.1f; x += 1.0f)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += 1.0f)
                    {
                        if (currentBuildMode == 2) { if (x > minX + 1.5f && x < maxX - 1.5f && z > minZ + 1.5f && z < maxZ - 1.5f) continue; }
                        CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                    }
                }
            }
            else if (currentBuildMode == 3 || currentBuildMode == 5)
            {
                float radius = distance / 2.0f;
                float3 center = (startXZ + endXZ) / 2.0f;
                float minX = center.x - radius; float maxX = center.x + radius;
                float minZ = center.z - radius; float maxZ = center.z + radius;
                for (float x = minX; x <= maxX + 0.1f; x += 1.0f)
                {
                    for (float z = minZ; z <= maxZ + 0.1f; z += 1.0f)
                    {
                        float distSq = math.distancesq(new float3(x, 0, z), center);
                        if (distSq <= radius * radius)
                        {
                            if (currentBuildMode == 3 && distSq < (radius - 1.5f) * (radius - 1.5f)) continue;
                            CheckRay(physicsWorld, x, z, ref highestY, ref hitEntity, ref hitAnything);
                        }
                    }
                }
            }
            else if (currentBuildMode == 6) CheckRay(physicsWorld, startXZ.x, startXZ.z, ref highestY, ref hitEntity, ref hitAnything);

            if (hitAnything)
            {
                float finalBuildY = math.max(highestY, dragStartPos.y);
                ExecuteBuild(ref state, spawnerData, finalBuildY, hitEntity);
                isGuideActive = false;
            }
        }
    }
    private void ExecuteBuild(ref SystemState state, SpawnerData data, float targetY, Entity hitEntity)
    {
        bool hitExistingBlock = SystemAPI.HasComponent<BlockTag>(hitEntity);
        float3 hitEntityPos = hitExistingBlock ? SystemAPI.GetComponent<LocalTransform>(hitEntity).Position : float3.zero;

        switch (currentBuildMode)
        {
            case 1: BuildSolidWall(ref state, data, dragStartPos, dragEndPos, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID); break;
            case 2: BuildEmptyFrame(ref state, data, dragStartPos, dragEndPos, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID); break;
            case 3: BuildCircularPattern(ref state, data, dragStartPos, dragEndPos, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID); break;
            case 4: BuildPyramid(ref state, data, dragStartPos, dragEndPos, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID); break;
            case 5: BuildCone(ref state, data, dragStartPos, dragEndPos, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID); break;
            case 6: BuildMotorPlate(ref state, data, dragStartPos, targetY, hitExistingBlock ? hitEntity : Entity.Null, hitEntityPos, nextStructureID); break;
        }
        nextStructureID++;
    }

    private void CheckRay(PhysicsWorld physicsWorld, float x, float z, ref float highestY, ref Entity hitEntity, ref bool hitAnything)
    {
        float3 rayPos = new float3(x, 100f, z);
        RaycastInput rayInput = new RaycastInput { Start = rayPos, End = rayPos + new float3(0, -200f, 0), Filter = CollisionFilter.Default };
        if (physicsWorld.CastRay(rayInput, out Unity.Physics.RaycastHit hit))
        {
            hitAnything = true;
            if (hit.Position.y > highestY) { highestY = hit.Position.y; hitEntity = hit.Entity; }
        }
    }

    private void DrawGuideWireframe(float3 start, float3 end, float heightParam, int mode)
    {
        Color color = Color.green; float blockSize = 3.0f; float h = heightParam * blockSize;
        if (mode == 1 || mode == 2)
        {
            Vector3 p1 = new Vector3(start.x, start.y, start.z); Vector3 p2 = new Vector3(end.x, start.y, start.z);
            Vector3 p3 = new Vector3(end.x, start.y, end.z); Vector3 p4 = new Vector3(start.x, start.y, end.z);
            Debug.DrawLine(p1, p2, color); Debug.DrawLine(p2, p3, color); Debug.DrawLine(p3, p4, color); Debug.DrawLine(p4, p1, color);
            if (heightParam > 1)
            {
                Vector3 t1 = p1 + Vector3.up * h; Vector3 t2 = p2 + Vector3.up * h; Vector3 t3 = p3 + Vector3.up * h; Vector3 t4 = p4 + Vector3.up * h;
                Debug.DrawLine(t1, t2, color); Debug.DrawLine(t2, t3, color); Debug.DrawLine(t3, t4, color); Debug.DrawLine(t4, t1, color);
                Debug.DrawLine(p1, t1, color); Debug.DrawLine(p2, t2, color); Debug.DrawLine(p3, t3, color); Debug.DrawLine(p4, t4, color);
            }
        }
        else if (mode == 3 || mode == 4 || mode == 5)
        {
            float3 center = (start + end) / 2f; float radius = math.distance(start, end) / 2f;
            int segments = 24; float angleStep = (2f * math.PI) / segments;
            Vector3 prev = center + new float3(radius, 0, 0);
            for (int i = 1; i <= segments; i++)
            {
                Vector3 next = center + new float3(math.cos(i * angleStep) * radius, 0, math.sin(i * angleStep) * radius);
                Debug.DrawLine(prev, next, color); prev = next;
            }
            if (heightParam > 1) Debug.DrawLine(center, center + new float3(0, h, 0), color);
        }
        else if (mode == 6) Debug.DrawRay(start, Vector3.up * blockSize, color);
    }

    private void CreateIndestructibleJoint(ref EntityCommandBuffer ecb, Entity entityA, Entity entityB, float3 offsetToB)
    {
        Entity jointEntity = ecb.CreateEntity();
        ecb.AddSharedComponent(jointEntity, new PhysicsWorldIndex());
        ecb.AddComponent<JointTag>(jointEntity);
        ecb.AddComponent(jointEntity, new PhysicsConstrainedBodyPair(entityA, entityB, true));
        ecb.AddComponent(jointEntity, PhysicsJoint.CreateFixed(new RigidTransform(quaternion.identity, offsetToB * 0.5f), new RigidTransform(quaternion.identity, -offsetToB * 0.5f)));
    }
}