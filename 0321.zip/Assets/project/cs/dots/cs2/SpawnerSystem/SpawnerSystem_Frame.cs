﻿using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Unity.Collections;
using Unity.Rendering;
using Unity.Physics;

public partial struct SpawnerSystem
{
    private Entity CreateGiantPlate(ref EntityCommandBuffer ecb, SpawnerData data, float3 pos, float width, float depth, int structureID, bool isFoundation)
    {
        var instance = ecb.Instantiate(data.Prefab);
        float height = 1.0f;
        ecb.SetComponent(instance, LocalTransform.FromPosition(pos));
        ecb.AddComponent(instance, new PostTransformMatrix { Value = float4x4.Scale(width, height, depth) });
        BlobAssetReference<Unity.Physics.Collider> plateCollider = Unity.Physics.BoxCollider.Create(new BoxGeometry { Center = float3.zero, Orientation = quaternion.identity, Size = new float3(width, height, depth), BevelRadius = 0.05f });
        ecb.SetComponent(instance, new PhysicsCollider { Value = plateCollider });

        if (isFoundation) ecb.SetComponent(instance, Unity.Physics.PhysicsMass.CreateKinematic(plateCollider.Value.MassProperties));
        else ecb.SetComponent(instance, Unity.Physics.PhysicsMass.CreateDynamic(plateCollider.Value.MassProperties, 1.0f));

        ecb.AddComponent<BlockTag>(instance);
        ecb.AddComponent<BlockStress>(instance);
        ecb.AddComponent(instance, new StructureID { Value = structureID });
        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = new float4(0.2f, 0.2f, 0.2f, 1) });
        return instance;
    }

    private void BuildEmptyFrame(ref SystemState state, SpawnerData data, float3 start, float3 end, float targetY, Entity hitEntity, float3 hitEntityPos, int structureID)
    {
        var ecb = SystemAPI.GetSingleton<BeginSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
        float blockSize = 3.0f;
        float halfSize = blockSize / 2.0f;
        float margin = 0.05f;

        int widthCount = (int)math.max(1, math.round(math.abs(end.x - start.x) / blockSize));
        int depthCount = (int)math.max(1, math.round(math.abs(end.z - start.z) / blockSize));
        int heightCount = (int)math.max(1, math.round(guideHeight));
        float3 startCorner = new float3(math.min(start.x, end.x), 0f, math.min(start.z, end.z));

        // ⭐ 1. 레이캐스트 융단폭격 및 최고점 추출
        var physicsWorld = SystemAPI.GetSingleton<Unity.Physics.PhysicsWorldSingleton>().PhysicsWorld;
        float highestHitY = -9999f;
        NativeArray<Unity.Physics.RaycastHit> floorHits = new NativeArray<Unity.Physics.RaycastHit>(widthCount * depthCount, Allocator.Temp);

        for (int x = 0; x < widthCount; x++)
        {
            for (int z = 0; z < depthCount; z++)
            {
                float3 rayStart = new float3(startCorner.x + (x * blockSize) + halfSize, targetY + 100f, startCorner.z + (z * blockSize) + halfSize);
                Unity.Physics.RaycastInput input = new Unity.Physics.RaycastInput { Start = rayStart, End = rayStart - new float3(0, 200f, 0), Filter = Unity.Physics.CollisionFilter.Default };
                if (physicsWorld.CastRay(input, out Unity.Physics.RaycastHit hit))
                {
                    floorHits[x + (z * widthCount)] = hit;
                    if (hit.Position.y > highestHitY) highestHitY = hit.Position.y;
                }
                else
                {
                    floorHits[x + (z * widthCount)] = new Unity.Physics.RaycastHit { Entity = Entity.Null, Position = new float3(0, -9999f, 0) };
                }
            }
        }
        if (highestHitY > -9999f) targetY = highestHitY;

        NativeArray<Entity> grid = new NativeArray<Entity>(widthCount * heightCount * depthCount, Allocator.Temp);
        for (int i = 0; i < grid.Length; i++) grid[i] = Entity.Null;
        int GetIndex(int x, int h, int z) => x + (h * widthCount * depthCount) + (z * widthCount);

        for (int h = 0; h < heightCount; h++)
        {
            for (int x = 0; x < widthCount; x++)
            {
                for (int z = 0; z < depthCount; z++)
                {
                    bool isWall = (x == 0 || x == widthCount - 1 || z == 0 || z == depthCount - 1);
                    bool isFloor = (h == 0);
                    bool isCeiling = (h == heightCount - 1);

                    if (isWall || isFloor || isCeiling)
                    {
                        float3 pos = new float3(startCorner.x + (x * blockSize) + halfSize, targetY + halfSize + (h * blockSize), startCorner.z + (z * blockSize) + halfSize);
                        var instance = ecb.Instantiate(data.Prefab);
                        ecb.SetComponent(instance, LocalTransform.FromPositionRotationScale(pos, quaternion.identity, blockSize - margin));
                        ecb.AddComponent<BlockTag>(instance);
                        ecb.AddComponent<BlockStress>(instance);
                        ecb.AddComponent(instance, new StructureID { Value = structureID });
                        ecb.AddComponent(instance, new URPMaterialPropertyBaseColor { Value = new float4(1, 1, 1, 1) });
                        grid[GetIndex(x, h, z)] = instance;

                        // ⭐ 2. 최고점 기준 선택적 조인트 & 무적 바닥 설정 (NaN 폭발 방지!)
                        if (isFloor)
                        {
                            var hit = floorHits[x + (z * widthCount)];
                            // Terrain(맨땅)처럼 물리 컴포넌트가 없는 엔티티에 조인트 걸면 폭발하므로 검사 추가!
                            if (hit.Entity != Entity.Null && math.abs(hit.Position.y - highestHitY) < 0.1f && SystemAPI.HasComponent<PhysicsVelocity>(hit.Entity))
                            {
                                CreateIndestructibleJoint(ref ecb, hit.Entity, instance, pos - hit.Position);
                            }
                            else
                            {
                                PhysicsMass prefabMass = SystemAPI.GetComponent<PhysicsMass>(data.Prefab);
                                prefabMass.InverseMass = 0; prefabMass.InverseInertia = float3.zero;
                                ecb.SetComponent(instance, prefabMass);
                            }
                        }
                    }
                }
            }
        }

        for (int h = 0; h < heightCount; h++)
        {
            for (int x = 0; x < widthCount; x++)
            {
                for (int z = 0; z < depthCount; z++)
                {
                    Entity current = grid[GetIndex(x, h, z)];
                    if (current == Entity.Null) continue;
                    if (x < widthCount - 1 && grid[GetIndex(x + 1, h, z)] != Entity.Null) CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x + 1, h, z)], new float3(blockSize, 0, 0));
                    if (z < depthCount - 1 && grid[GetIndex(x, h, z + 1)] != Entity.Null) CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x, h, z + 1)], new float3(0, 0, blockSize));
                    if (h < heightCount - 1 && grid[GetIndex(x, h + 1, z)] != Entity.Null) CreateIndestructibleJoint(ref ecb, current, grid[GetIndex(x, h + 1, z)], new float3(0, blockSize, 0));
                }
            }
        }
        grid.Dispose();
        floorHits.Dispose();
    }
}