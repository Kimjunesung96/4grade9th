﻿using UnityEngine;
using Unity.Mathematics;
using Unity.Entities; // ⭐ 핵심: DOTS 세계와 통신하기 위한 장비 장착!

public class SimulationDragController : MonoBehaviour
{
    [Header("건축 규격 설정")]
    public float blockSize = 3.0f;
    public LayerMask groundLayer = ~0;

    [Header("매테리얼 세팅")]
    public Material coreMaterial;
    public Material previewMaterial;

    private Transform simulationPivot;
    private Transform yellowCore;
    private Transform previewContainer;

    private bool isSimulationActive = false;
    private float3 definedStart;
    private float3 definedEnd;
    private int sizeX;
    private int sizeZ;

    void Start()
    {
        simulationPivot = new GameObject("SimulationPivot").transform;
        simulationPivot.gameObject.SetActive(false);

        GameObject coreObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Destroy(coreObj.GetComponent<Collider>());
        if (coreMaterial != null) coreObj.GetComponent<Renderer>().material = coreMaterial;

        yellowCore = coreObj.transform;
        yellowCore.SetParent(simulationPivot);

        GameObject containerObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Destroy(containerObj.GetComponent<Collider>());
        if (previewMaterial != null) containerObj.GetComponent<Renderer>().material = previewMaterial;

        previewContainer = containerObj.transform;
        previewContainer.SetParent(simulationPivot);
    }

    void Update()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (!Physics.Raycast(ray, out RaycastHit hit, 1000f, groundLayer)) return;

        float3 hitPoint = hit.point;

        // 🔴 좌클릭: 가건물 구역 설정
        if (Input.GetMouseButtonDown(0))
        {
            definedStart = SnapToGrid(hitPoint);
            definedEnd = definedStart;
            isSimulationActive = true;
            simulationPivot.gameObject.SetActive(true);
            UpdateSimulationArea();
            SyncWithDOTS(); // ⭐ 좌클릭 시작할 때도 DOTS 초록선 동기화!
        }

        if (Input.GetMouseButton(0) && isSimulationActive)
        {
            definedEnd = SnapToGrid(hitPoint);
            UpdateSimulationArea();
            SyncWithDOTS(); // ⭐ 좌클릭 드래그 중에도 초록선 동기화!
        }

        // 🔘 좌클릭 떼기: 드래그 안 하고 그냥 딸깍! 떼면 취소
        if (Input.GetMouseButtonUp(0))
        {
            if (math.distance(definedStart, definedEnd) < 0.1f)
            {
                isSimulationActive = false;
                simulationPivot.gameObject.SetActive(false);
            }
        }

        // 🟡 우클릭: 노란 코어 멱살 잡고 통째로 이동
        if (Input.GetMouseButton(1) && isSimulationActive)
        {
            MoveSimulationByCore(hitPoint);
        }
    }

    float3 SnapToGrid(float3 pos)
    {
        return math.floor(pos / blockSize) * blockSize;
    }

    void UpdateSimulationArea()
    {
        float3 min = math.min(definedStart, definedEnd);
        float3 max = math.max(definedStart, definedEnd);

        sizeX = (int)math.round((max.x - min.x) / blockSize) + 1;
        sizeZ = (int)math.round((max.z - min.z) / blockSize) + 1;

        float3 center = (min + max) / 2.0f;
        center += new float3(blockSize / 2f, 0, blockSize / 2f);
        center.y = min.y + (blockSize / 2f);
        simulationPivot.position = center;

        previewContainer.localScale = new Vector3(sizeX * blockSize, blockSize, sizeZ * blockSize);
        previewContainer.localPosition = Vector3.zero;

        yellowCore.localScale = new Vector3(blockSize, blockSize * 1.1f, blockSize);
        yellowCore.localPosition = Vector3.zero;
    }

    void MoveSimulationByCore(float3 hitPoint)
    {
        float snapX = (sizeX % 2 != 0) ?
            math.floor(hitPoint.x / blockSize) * blockSize + (blockSize / 2f) :
            math.round(hitPoint.x / blockSize) * blockSize;

        float snapZ = (sizeZ % 2 != 0) ?
            math.floor(hitPoint.z / blockSize) * blockSize + (blockSize / 2f) :
            math.round(hitPoint.z / blockSize) * blockSize;

        float snapY = math.floor(hitPoint.y / blockSize) * blockSize + (blockSize / 2f);

        float3 newCenter = new float3(snapX, snapY, snapZ);
        float3 oldCenter = simulationPivot.position;
        float3 offset = newCenter - oldCenter;

        // ⭐ 진짜 핵심: 우클릭으로 중심이 이동한 만큼, 좌클릭 원본 좌표(Start/End)도 같이 이동시킵니다!
        if (math.lengthsq(offset) > 0.001f)
        {
            definedStart += offset;
            definedEnd += offset;

            UpdateSimulationArea();
            SyncWithDOTS(); // ⭐ DOTS 시스템한테 "도면 위치 옮겼다!"고 좌표 통보
        }
    }

    // 📡 DOTS 세계관(BuilderStateData)에 강제로 좌표를 덮어씌우는 통신망 로직!
    void SyncWithDOTS()
    {
        if (World.DefaultGameObjectInjectionWorld == null) return;
        var em = World.DefaultGameObjectInjectionWorld.EntityManager;
        var query = em.CreateEntityQuery(typeof(BuilderStateData));

        if (query.HasSingleton<BuilderStateData>())
        {
            var data = query.GetSingleton<BuilderStateData>();

            // 우리가 계산한 새 좌표를 설계도에 덮어씌워버림!
            data.GuideStartPos = definedStart;
            data.GuideEndPos = definedEnd;

            query.SetSingleton(data);
        }
    }
}